import Sidebar from "./Sidebar";
import Topbar from "./Topbar";

export default function MainLayout({ children }) {
  return (
    <div className="t23-shell">
      <Sidebar />

      <main className="t23-main">
        <Topbar />
        <div className="t23-content">{children}</div>
      </main>
    </div>
  );
}