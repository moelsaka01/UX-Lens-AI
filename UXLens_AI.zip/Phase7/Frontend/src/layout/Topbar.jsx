import { Bell, Search, Sparkles, Zap } from "lucide-react";

export default function Topbar() {
  return (
    <div className="t23-topbar">
      <div className="t23-search">
        <Search size={14} />
        <span>Search analysis, reports, domains...</span>
      </div>

      <div className="t23-topbar-actions">
        <div className="t23-status-pill">
          <Zap size={13} />
          Live
        </div>

        <button className="t23-icon-button" type="button">
          <Bell size={14} />
        </button>

        <button
          className="t23-primary-mini"
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        >
          <Sparkles size={14} />
          New Analysis
        </button>
      </div>
    </div>
  );
}