import {
  Activity,
  BarChart3,
  Brain,
  Gauge,
  LayoutDashboard,
  MonitorSmartphone,
  Sparkles,
} from "lucide-react";

const navItems = [
  { label: "Dashboard", icon: LayoutDashboard, active: true },
  { label: "Analysis", icon: Gauge },
  { label: "Redesign", icon: Sparkles },
  { label: "Captures", icon: MonitorSmartphone },
  { label: "Learning", icon: Brain },
  { label: "Metrics", icon: BarChart3 },
  { label: "Observability", icon: Activity },
];

export default function Sidebar() {
  return (
    <aside className="t23-sidebar">
      <div className="t23-brand">
        <div className="t23-brand-mark">
          <Sparkles size={17} />
        </div>

        <div>
          <div className="t23-brand-name">UXLens AI</div>
          <div className="t23-brand-sub">Visual intelligence</div>
        </div>
      </div>

      <nav className="t23-nav" aria-label="Main navigation">
        {navItems.map((item) => {
          const Icon = item.icon;

          return (
            <button
              key={item.label}
              type="button"
              className={`t23-nav-item ${item.active ? "is-active" : ""}`}
              onClick={() => {
                const targetMap = {
                  Dashboard: "scores",
                  Analysis: "insights",
                  Redesign: "redesign",
                  Captures: "captures",
                  Learning: "learning",
                  Metrics: "intelligence",
                  Observability: "intelligence",
                };

                const target = document.getElementById(targetMap[item.label]);

                if (target) {
                  target.scrollIntoView({ behavior: "smooth", block: "start" });
                }
              }}
            >
              <Icon size={15} />
              <span>{item.label}</span>
            </button>          );
        })}
      </nav>
    </aside>
  );
}

