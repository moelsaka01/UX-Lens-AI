export default function OverlayInsightPanel({ overlayData, activeRegion = "nav", onRegionChange }) {
  if (!overlayData) return null;

  const safeNumber = (value, fallback = 0) => {
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  };

  const beforeNav = safeNumber(overlayData.nav_before);
  const afterNav = safeNumber(overlayData.nav_after);
  const beforeNodes = safeNumber(overlayData.nodes_before);
  const afterNodes = safeNumber(overlayData.nodes_after);
  const realism = safeNumber(overlayData.realism);

  const regions = [
    {
      id: "nav",
      index: "01",
      label: "Navigation density",
      metric: beforeNav && afterNav ? `${beforeNav} to ${afterNav}` : "Improved",
      desc: "High navigation density can increase decision friction and weaken first-screen clarity.",
    },
    {
      id: "hero",
      index: "02",
      label: "Hero focus",
      metric: `+${safeNumber(overlayData.focus_delta)}`,
      desc: "The redesign improves the first impression by making the primary message easier to scan.",
    },
    {
      id: "cta",
      index: "03",
      label: "CTA path",
      metric: `+${safeNumber(overlayData.cta_delta)}`,
      desc: "CTA visibility directly affects conversion by making the next action easier to recognize.",
    },
  ];

  const selected = regions.find((item) => item.id === activeRegion) || regions[0];

  return (
    <aside className="overlay-insights">
      <div className="overlay-insight-kicker">Redesign intelligence</div>

      <div>
        <h3>Transformation evidence</h3>
        <p>
          Clean, readable signals generated from the analysis pipeline. Select a region to sync the
          explanation with the visual overlay.
        </p>
      </div>

      <div className="overlay-metrics-grid">
        <div className="overlay-metric">
          <span>Focus delta</span>
          <strong>+{safeNumber(overlayData.focus_delta)}</strong>
        </div>

        <div className="overlay-metric">
          <span>CTA delta</span>
          <strong>+{safeNumber(overlayData.cta_delta)}</strong>
        </div>

        <div className="overlay-metric">
          <span>Navigation</span>
          <strong>{beforeNav && afterNav ? `${beforeNav} to ${afterNav}` : "-"}</strong>
        </div>

        <div className="overlay-metric">
          <span>Nodes</span>
          <strong>{beforeNodes && afterNodes ? `${beforeNodes} to ${afterNodes}` : "-"}</strong>
        </div>

        <div className="overlay-metric wide">
          <span>Realism confidence</span>
          <strong>{realism ? `${Math.round(realism * 100)}%` : "-"}</strong>
        </div>
      </div>

      <div className="overlay-selected-card">
        <span>{selected.index}</span>
        <div>
          <strong>{selected.label}</strong>
          <p>{selected.desc}</p>
        </div>
      </div>

      <div className="overlay-region-list">
        {regions.map((region) => (
          <button
            key={region.id}
            type="button"
            className={activeRegion === region.id ? "is-active" : ""}
            onClick={() => onRegionChange?.(region.id)}
          >
            <span>{region.index} {region.label}</span>
            <strong>{region.metric}</strong>
          </button>
        ))}
      </div>
    </aside>
  );
}