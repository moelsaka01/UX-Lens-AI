import React, { useMemo } from "react";
import { Activity, Hash, TimerReset } from "lucide-react";

function safeNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function formatDuration(secondsValue) {
  const seconds = Number(secondsValue);
  if (!Number.isFinite(seconds) || seconds < 0) return "0s";

  if (seconds >= 60) return `${(seconds / 60).toFixed(1)}m`;
  if (seconds >= 1) return `${seconds.toFixed(2)}s`;
  return `${seconds.toFixed(2)}s`;
}

function titleizeKey(value) {
  return String(value || "")
    .replace(/_/g, " ")
    .replace(/\b\w/g, (char) => char.toUpperCase());
}

function normalizeMetrics(report) {
  const raw = report?.pipeline_metrics;

  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return [];

  return Object.entries(raw)
    .map(([key, value]) => ({
      key,
      label: titleizeKey(key),
      seconds: safeNumber(value, 0),
    }))
    .filter((item) => item.label);
}

export default function ObservabilityPanel({ report }) {
  const metrics = useMemo(() => normalizeMetrics(report), [report]);

  if (!metrics.length) return null;

  const totalSeconds =
    metrics.find((item) => item.key === "total_analysis")?.seconds ?? 0;

  const slowestStep =
    metrics
      .filter((item) => item.key !== "total_analysis")
      .sort((a, b) => b.seconds - a.seconds)[0] || null;

  const traceId = report?.trace_id || "-";
  const generatedAt = report?.generated_at || "-";

  return (
    <section className="t23-panel">
      <div className="t23-section-head">
        <div>
          <h2>Pipeline Observability</h2>
          <p>Backend execution timings, trace metadata, and slowest pipeline stages.</p>
        </div>
      </div>

      <div className="t23-stat-grid">
        <div className="t23-stat">
          <span>Total runtime</span>
          <strong>{formatDuration(totalSeconds)}</strong>
        </div>

        <div className="t23-stat">
          <span>Tracked steps</span>
          <strong>{metrics.length}</strong>
        </div>

        <div className="t23-stat">
          <span>Slowest step</span>
          <strong>{slowestStep ? slowestStep.label : "-"}</strong>
        </div>

        <div className="t23-stat">
          <span>Slowest duration</span>
          <strong>{slowestStep ? formatDuration(slowestStep.seconds) : "0s"}</strong>
        </div>
      </div>

      <div className="t23-two align-start">
        <div className="t23-list-panel">
          <h3>
            <Activity size={14} /> Step timings
          </h3>

          {metrics.slice(0, 8).map((item) => (
            <div className="t23-list-row" key={item.key}>
              <span>
                <Hash size={12} /> {item.label}
              </span>
              <strong>{formatDuration(item.seconds)}</strong>
            </div>
          ))}
        </div>

        <div className="t23-list-panel">
          <h3>
            <TimerReset size={14} /> Trace metadata
          </h3>

          <div className="t23-list-row">
            <span>Trace ID</span>
            <em>{traceId}</em>
          </div>

          <div className="t23-list-row">
            <span>Generated</span>
            <em>{generatedAt}</em>
          </div>

          <div className="t23-list-row">
            <span>Readable units</span>
            <strong>enabled</strong>
          </div>
        </div>
      </div>
    </section>
  );
}