import React, { useMemo, useState } from "react";
import { ImageIcon, Loader2, RefreshCcw, Sparkles, Wand2 } from "lucide-react";
import "./redesign-preview.css";

const API_BASE = (import.meta.env.VITE_API_BASE_URL || "http://localhost:8000").replace(/\/$/, "");
const MOCKUP_START_ENDPOINT = `${API_BASE}/api/mockups/start`;
const MOCKUP_STATUS_ENDPOINT = `${API_BASE}/api/mockups/status`;

function safeArray(value) {
  return Array.isArray(value) ? value : [];
}

function safeText(value, fallback = "-") {
  if (value === undefined || value === null || value === "") return fallback;
  return String(value);
}

function toAssetUrl(value) {
  if (!value) return "";
  if (/^https?:\/\//i.test(value)) return value;
  if (value.startsWith("/")) return `${API_BASE}${value}`;
  return `${API_BASE}/${value}`;
}

function getMockupImageUrl(mockup) {
  return toAssetUrl(
    mockup?.image_url ||
      mockup?.image ||
      mockup?.url ||
      mockup?.preview_url ||
      mockup?.asset_url ||
      mockup?.path ||
      mockup?.mockup_url ||
      ""
  );
}

function getBeforeImageUrl(report) {
  return toAssetUrl(
    report?.screenshots?.desktop ||
      report?.screenshots?.desktop_full ||
      report?.screenshots?.mobile ||
      report?.screenshots?.mobile_full ||
      ""
  );
}


function impactClass(value) {
  const text = String(value || "").toLowerCase();
  if (text.includes("high")) return "impact-high";
  if (text.includes("medium")) return "impact-medium";
  return "impact-low";
}

function getPrimarySuggestion(report) {
  const redesignSuggestions = safeArray(report?.redesign_suggestions);
  const suggestions = safeArray(report?.suggestions);

  return (
    redesignSuggestions[0] ||
    suggestions[0] || {
      title: "AI redesign direction",
      impact: "High",
      description: "Run analysis to generate redesign recommendations.",
    }
  );
}

function getMockupForSuggestion(report, localMockups, title) {
  const mockups = [...safeArray(localMockups), ...safeArray(report?.redesign_mockups)];
  return mockups.find((m) => m?.title === title) || mockups[0] || null;
}

function sleep(ms) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function generationLabel(mode) {
  if (mode === "image") return "Generating AI image";
  return "Rendering redesign preview";
}

export default function RedesignPreviewSection({ report }) {
  const [previewMode, setPreviewMode] = useState("after");
  const [localMockups, setLocalMockups] = useState([]);
  const [jobStatus, setJobStatus] = useState("idle");
  const [jobMessage, setJobMessage] = useState("");
  const [jobProgress, setJobProgress] = useState(0);
  const [activeMode, setActiveMode] = useState("renderer");

  const suggestion = useMemo(() => getPrimarySuggestion(report), [report]);

  const mockup = useMemo(
    () => getMockupForSuggestion(report, localMockups, suggestion?.title),
    [report, localMockups, suggestion?.title]
  );

  const loading = jobStatus === "running" || jobStatus === "pending";

  const generatedImageUrl = getMockupImageUrl(mockup);
  const beforeImageUrl = getBeforeImageUrl(report);

  const afterImageUrl = generatedImageUrl;
  const visibleImageUrl = previewMode === "before" ? beforeImageUrl : afterImageUrl;

  const title = safeText(mockup?.title || suggestion?.title, "AI redesign direction");
  const description = safeText(
    mockup?.description || suggestion?.description || suggestion?.proposed,
    "Recommendations will appear after analysis."
  );
  const impact = safeText(suggestion?.impact || mockup?.impact, "High");

  async function pollMockupJob(jobId) {
    for (let attempt = 0; attempt < 100; attempt += 1) {
      await sleep(1200);

      const res = await fetch(`${MOCKUP_STATUS_ENDPOINT}/${jobId}`);
      if (!res.ok) throw new Error(`Preview status failed: ${res.status}`);

      const data = await res.json();
      const status = data?.status || "unknown";

      setJobStatus(status);
      setJobProgress(Math.min(100, Math.max(0, Number(data?.progress || 0))));
      setJobMessage(data?.message || "");

      if (status === "done") {
        const result = safeArray(data?.result || data?.mockups);

        if (result.length > 0) {
          setLocalMockups((previous) => [...result, ...previous]);
          setPreviewMode("after");
          setJobMessage(activeMode === "image" ? "AI image generated." : "Redesign preview generated.");
        } else {
          setJobMessage("Job completed, but no image URL was returned.");
        }

        setJobProgress(100);
        setJobStatus("done");
        return;
      }

      if (status === "failed" || status === "error") {
        setJobProgress(100);
        setJobStatus("error");
        setJobMessage(data?.error || "Generation failed.");
        return;
      }

      if (status === "not_found") {
        setJobProgress(0);
        setJobStatus("error");
        setJobMessage("Preview job was not found.");
        return;
      }
    }

    setJobStatus("error");
    setJobProgress(100);
    setJobMessage("Generation timed out.");
  }

  async function handleGenerateVariation(mode = "renderer") {
    if (!report || !suggestion?.title || loading) return;

    setActiveMode(mode);
    setJobStatus("pending");
    setJobProgress(0);
    setJobMessage(mode === "image" ? "Starting AI image generation..." : "Starting redesign preview...");

    try {
      const response = await fetch(MOCKUP_START_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          report,
          suggestion_title: suggestion.title,
          variation_index: safeArray(localMockups).length + 1,
          mode,
        }),
      });

      if (!response.ok) throw new Error(`Preview job start failed: ${response.status}`);

      const data = await response.json();

      if (!data.job_id) {
        setJobStatus("error");
        setJobMessage("Failed to start generation job.");
        return;
      }

      setJobStatus("running");
      await pollMockupJob(data.job_id);
    } catch (error) {
      setJobStatus("error");
      setJobProgress(100);
      setJobMessage(error?.message || "Generation failed.");
    }
  }

  return (
    <section className="rp-section">
      <div className="rp-sectionhead">
        <div>
          <h2>Redesign Review</h2>
          <p>Compare the current page with a deterministic preview or an AI-generated visual direction.</p>
        </div>

        <span className="rp-sectionchip">
          {loading ? <Loader2 size={13} className="spin" /> : <Sparkles size={13} />}
          {loading ? generationLabel(activeMode) : "Ready"}
        </span>
      </div>

      <div className="rp-card">
        <div className="rp-cardhead">
          <div>
            <h3>{title}</h3>
            <p>{description}</p>
          </div>

          <div className="rp-cardactions">
            <span className={`rp-impact ${impactClass(impact)}`}>{impact}</span>

            <button
              type="button"
              className="rp-toggle"
              onClick={() => setPreviewMode((p) => (p === "after" ? "before" : "after"))}
              disabled={!beforeImageUrl && !afterImageUrl}
            >
              <Wand2 size={13} />
              {previewMode === "after" ? "After" : "Before"}
            </button>

            <button
              type="button"
              className="rp-toggle"
              onClick={() => handleGenerateVariation("renderer")}
              disabled={loading}
            >
              {loading && activeMode === "renderer" ? (
                <Loader2 className="spin" size={13} />
              ) : (
                <RefreshCcw size={13} />
              )}
              Render preview
            </button>

            <button
              type="button"
              className="rp-toggle rp-ai-btn"
              onClick={() => handleGenerateVariation("image")}
              disabled={loading}
            >
              {loading && activeMode === "image" ? (
                <Loader2 className="spin" size={13} />
              ) : (
                <Sparkles size={13} />
              )}
              Generate AI image
            </button>
          </div>
        </div>

        {jobMessage ? <div className="t23-feedback-note">{jobMessage}</div> : null}

        {loading || jobStatus === "done" || jobStatus === "error" ? (
          <div className="rp-progress-wrap">
            <div className="rp-progress-top">
              <span>{activeMode === "image" ? "AI image generation" : "Preview rendering"}</span>
              <strong>{jobProgress}%</strong>
            </div>

            <div className="rp-progress-track">
              <span style={{ width: `${jobProgress}%` }} />
            </div>
          </div>
        ) : null}

        <div className="rp-compare-tabs">
          <button
            type="button"
            className={previewMode === "before" ? "active" : ""}
            onClick={() => setPreviewMode("before")}
            disabled={!beforeImageUrl}
          >
            Before
          </button>
          <button
            type="button"
            className={previewMode === "after" ? "active" : ""}
            onClick={() => setPreviewMode("after")}
            disabled={!afterImageUrl}
          >
            After
          </button>
        </div>

        <div className="rp-frame">
          {visibleImageUrl ? (
            <img
              src={visibleImageUrl}
              alt={previewMode === "before" ? "Current analyzed website screenshot" : "Redesign preview"}
            />
          ) : (
            <div className="t23-empty">
              <ImageIcon size={22} />
              <span>
                {previewMode === "before"
                  ? "Run an analysis to capture the current website screenshot."
                  : "Render a preview or generate an AI image to see the redesigned direction."}
              </span>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}