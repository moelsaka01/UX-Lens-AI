import MainLayout from "./layout/MainLayout";
import AnalysisPage from "./pages/AnalysisPage";

import "./styles.css";
import "./components/redesign-preview.css";
import "./theme-tier23.css";

export default function App() {
  return (
    <MainLayout>
      <AnalysisPage />
    </MainLayout>
  );
}