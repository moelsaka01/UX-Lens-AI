import React, { useEffect, useMemo, useState } from "react";
import {
  Activity,
  ArrowLeftRight,
  Bot,
  Brain,
  CheckCircle2,
  Cpu,
  LayoutPanelTop,
  Loader2,
  MonitorSmartphone,
  Radar,
  RefreshCcw,
  ServerCog,
  SlidersHorizontal,
  Sparkles,
  Target,
  ThumbsDown,
  ThumbsUp,
  Trophy,
  Wand2,
  XCircle,
} from "lucide-react";
import RedesignPreviewSection from "../components/RedesignPreviewSection";
import ObservabilityPanel from "../components/ObservabilityPanel";
import OverlayInsightPanel from "../components/OverlayInsightPanel";

const API_BASE = (import.meta.env.VITE_API_BASE_URL || "http://localhost:8000").replace(/\/$/, "");

const ANALYZE_ENDPOINT = `${API_BASE}/api/analyze`;
const COMPARE_ENDPOINT = `${API_BASE}/api/compare`;
const GENERATE_MOCKUPS_ENDPOINT = `${API_BASE}/api/generate-mockups`;
const FEEDBACK_ENDPOINT = `${API_BASE}/api/feedback`;
const LEARNING_STATUS_ENDPOINT = `${API_BASE}/api/learning/status`;
const LEARNING_RETRAIN_ENDPOINT = `${API_BASE}/api/learning/retrain`;
const LEARNING_RESET_ENDPOINT = `${API_BASE}/api/learning/reset`;
const ML_RANKER_STATUS_ENDPOINT = `${API_BASE}/api/ml-ranker/status`;
const ML_RANKER_TRAIN_ENDPOINT = `${API_BASE}/api/ml-ranker/train`;
const ARCHITECTURE_STATUS_ENDPOINT = `${API_BASE}/api/architecture/status`;
const ML_RANKER_ROLLBACK_ENDPOINT = `${API_BASE}/api/ml-ranker/rollback`;
const ML_RANKER_SIMULATE_ENDPOINT = `${API_BASE}/api/ml-ranker/simulate-production`;

function safeNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function compactPercent(value) {
  const n = safeNumber(value, 0);
  return `${Math.round(n <= 1 ? n * 100 : n)}%`;
}

function titleizeKey(value) {
  return String(value || "")
    .replace(/_/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}

function severityClass(value) {
  const t = String(value || "").toLowerCase();
  if (t === "high") return "severity-high";
  if (t === "medium") return "severity-medium";
  return "severity-low";
}

function makeAssetUrl(path) {
  if (!path || typeof path !== "string") return "";
  if (/^https?:\/\//i.test(path)) return path;
  if (path.startsWith("//")) return `${window.location.protocol}${path}`;
  if (path.startsWith("/")) return `${API_BASE}${path}`;
  return `${API_BASE}/${path}`;
}

function getDomainFromUrl(value) {
  try {
    const text = String(value || "").trim();
    const normalized = /^https?:\/\//i.test(text) ? text : `https://${text}`;
    return new URL(normalized).hostname.replace(/^www\./i, "");
  } catch {
    return "";
  }
}

function getReportId(report) {
  return report?.report_id ?? report?.id ?? null;
}

function getTargetId(item) {
  return String(item?.dedupe_key || item?.variant_group || item?.title || `target_${Date.now()}`)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "");
}

function normalizeReport(payload) {
  if (!payload) return null;
  if (payload.report) return payload.report;
  if (payload.data?.report) return payload.data.report;
  return payload;
}

function normalizeCompare(payload) {
  if (!payload) return null;
  if (payload.your_report && payload.competitor_report) return payload;
  if (payload.data?.your_report && payload.data?.competitor_report) return payload.data;
  return payload;
}

function mockupsAvailable(report) {
  if (!report?.mockup_status) return true;
  return Boolean(report.mockup_status.available);
}

function mockupsReason(report) {
  return String(report?.mockup_status?.reason || "").trim();
}

function normalizeMockupStatusFromGenerateResponse(response, previousReport) {
  const prev = previousReport?.mockup_status || {};
  const available =
    typeof response?.available === "boolean"
      ? response.available
      : typeof prev?.available === "boolean"
        ? prev.available
        : true;

  return {
    available,
    enabled: typeof prev?.enabled === "boolean" ? prev.enabled : available,
    mode: available ? "visual_previews" : prev?.mode || "concepts",
    ui_mode: available ? "visual_previews" : prev?.ui_mode || "concepts",
    reason: String(response?.reason || prev?.reason || ""),
  };
}

function createPlaceholderAnalyzeReport(inputUrl) {
  return {
    input_url: inputUrl || "https://www.apple.com/",
    detected_type: "marketing",
    scores: {
      ux_score: 0,
      attention_focus: 0,
      cta_visibility: 0,
      readability: 0,
      cognitive_load: 0,
    },
    findings: [
      {
        title: "Run an analysis to populate findings",
        severity: "Low",
        description: "Prioritized UX issues will appear here after analysis.",
      },
    ],
    suggestions: [
      {
        title: "AI-backed recommendations will appear here",
        impact: "Low",
        description: "Recommendations will appear after analysis.",
        evidence: [],
        rank_score: 0,
        rank_reasons: [],
        dedupe_key: "placeholder",
      },
    ],
    screenshots: {
      desktop: "",
      desktop_full: "",
      mobile: "",
      mobile_full: "",
    },
    ai_summary: "Run an analysis to generate a full website intelligence report.",
    redesign_suggestions: [],
    redesign_mockups: [],
    mockup_loading_titles: {},
    mockup_variations: {},
    mockup_status: { available: false, reason: "" },
    feedback_summary: {
      total_events: 0,
      positive_signals: 0,
      negative_signals: 0,
      accepted_suggestions: 0,
      rejected_suggestions: 0,
      top_positive_themes: [],
      top_negative_themes: [],
    },
  };
}

function MetricCard({ icon: Icon, label, value, note }) {
  const score = Math.max(0, Math.min(100, safeNumber(value, 0)));

  return (
    <div className="t23-metric-card" style={{ "--metric-score": `${score}%` }}>
      <div className="t23-metric-top">
        <span className="t23-icon-badge">
          <Icon size={17} />
        </span>
        <span>{label}</span>
      </div>

      <div className="t23-metric-value">
        {score}
        <small>/100</small>
      </div>

      <div className="t23-muted">{note}</div>

      <div className="t23-score-track">
        <span />
      </div>
    </div>
  );
}

function HeroPanel({
  mode,
  setMode,
  url,
  setUrl,
  competitorUrl,
  setCompetitorUrl,
  loading,
  runAnalysis,
  runCompare,
  report,
}) {
  return (
    <section className="t23-hero t23-panel">
      <div className="t23-hero-grid">
        <div>
          <div className="t23-kicker">
            <Radar size={16} />
            Website intelligence command center
          </div>

          <h1>Production-grade website analysis, compare mode, and AI-guided redesign previews</h1>

          <p>
            Render live pages, score UX credibility, compare competitors, track learning signals,
            and operate the full local ML ranking loop.
          </p>
        </div>
      </div>

      <div className="t23-mode-switch">
        <button
          type="button"
          className={mode === "analyze" ? "is-active" : ""}
          onClick={() => setMode("analyze")}
        >
          Analyze
        </button>

        <button
          type="button"
          className={mode === "compare" ? "is-active" : ""}
          onClick={() => setMode("compare")}
        >
          Compare
        </button>
      </div>

      {mode === "analyze" ? (
        <div className="t23-input-row">
          <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="Enter a public URL" />

          <button type="button" onClick={runAnalysis} disabled={loading}>
            {loading ? <Loader2 size={18} className="spin" /> : <Sparkles size={18} />}
            Analyze
          </button>
        </div>
      ) : (
        <div className="t23-input-row t23-compare-row">
          <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="Your page URL" />

          <input
            value={competitorUrl}
            onChange={(e) => setCompetitorUrl(e.target.value)}
            placeholder="Competitor URL"
          />

          <button type="button" onClick={runCompare} disabled={loading}>
            {loading ? <Loader2 size={18} className="spin" /> : <ArrowLeftRight size={18} />}
            Compare
          </button>
        </div>
      )}

      <div className="t23-chip-row">
        <span>
          <MonitorSmartphone size={15} />
          Desktop + mobile capture
        </span>
        <span>
          <Target size={15} />
          UX scoring
        </span>
        <span>
          <LayoutPanelTop size={15} />
          Layout intelligence
        </span>
        <span>
          <Brain size={15} />
          Learning loop
        </span>
        <span>
          <Wand2 size={15} />
          Redesign preview
        </span>
      </div>

      <div className="t23-endpoint-line">
        Connected endpoints: {ANALYZE_ENDPOINT}, {COMPARE_ENDPOINT}, {GENERATE_MOCKUPS_ENDPOINT}
      </div>

      {report && !mockupsAvailable(report) && mockupsReason(report) ? (
        <div className="t23-endpoint-line">Mockups status: {mockupsReason(report)}</div>
      ) : null}
    </section>
  );
}

function LearningControlPanel({
  learningStatus,
  mlStatus,
  architectureStatus,
  reportFeedbackSummary,
  loading,
  onRefresh,
  onRetrain,
  onReset,
  onTrainMl,
  onRollbackMl,
  onSimulateProduction,
  simulationStatus,
}) {
  const weights = learningStatus?.weights || learningStatus?.diagnostics?.weights || {};
  const coverage = learningStatus?.coverage || {};
  const feedback =
    reportFeedbackSummary && safeNumber(reportFeedbackSummary.total_events, 0) > 0
      ? reportFeedbackSummary
      : learningStatus?.feedback_summary || {};
  const checks = Array.isArray(architectureStatus?.checks) ? architectureStatus.checks : [];

  const trained = Boolean(mlStatus?.trained);
  const trainingMode = mlStatus?.training_mode || "none";
  const activeVersion = mlStatus?.active_version || "-";
  const realSamples = safeNumber(mlStatus?.real_sample_count, 0);
  const sampleCount = safeNumber(mlStatus?.sample_count, 0);
  const mae = mlStatus?.mae === null || mlStatus?.mae === undefined ? "-" : mlStatus.mae;
  const productionState = mlStatus?.production_state || (trained ? "active" : "waiting");
  const canRollback = Boolean(mlStatus?.can_rollback);
  const versions = Array.isArray(mlStatus?.versions) ? mlStatus.versions.slice().reverse().slice(0, 5) : [];

  return (
    <section className="t23-panel t23-control-plane">
      <div className="t23-section-head">
        <div>
          <h2>Learning Control Plane</h2>
          <p>Auto-training, live feedback learning, model versions, rollback, and production simulation.</p>
        </div>

        <button className="t23-ghost-button" type="button" onClick={onRefresh} disabled={loading}>
          <RefreshCcw size={15} />
          Refresh
        </button>
      </div>

      <div className="t23-control-grid">
        <div className="t23-control-card">
          <div className="t23-card-kicker">
            <SlidersHorizontal size={15} />
            Auto-learning weights
          </div>

          <strong>{coverage?.label || "none"}</strong>

          <p>
            Coverage score {safeNumber(coverage?.score, 0)} from {safeNumber(coverage?.signal_count, 0)} local signal(s).
          </p>

          <div className="t23-button-row">
            <button type="button" onClick={onRetrain} disabled={loading}>
              {loading ? <Loader2 className="spin" size={15} /> : <Brain size={15} />}
              {loading ? "Learning..." : "Learn now"}
            </button>

            <button type="button" onClick={onReset} disabled={loading}>
              Reset
            </button>
          </div>
        </div>

        <div className="t23-control-card ml-live-card">
          <div className="t23-card-kicker">
            <Cpu size={15} />
            ML ranker
          </div>

          <strong>{trained ? "trained" : "not trained"}</strong>

          <p>{mlStatus?.message || "Auto-training runs after feedback. Manual training is still available."}</p>

          <div className="ml-live-grid">
            <span>State <strong>{productionState}</strong></span>
            <span>Mode <strong>{trainingMode}</strong></span>
            <span>Samples <strong>{sampleCount}</strong></span>
            <span>Real <strong>{realSamples}</strong></span>
            <span>MAE <strong>{mae}</strong></span>
            <span>Version{" "} <strong title={activeVersion}>{activeVersion.replace("ranker_", "").slice(0, 15)}</strong></span>
          </div>

          <div className="t23-button-row">
            <button type="button" onClick={onTrainMl} disabled={loading}>
              {loading ? <Loader2 className="spin" size={15} /> : <Sparkles size={15} />}
              Train
            </button>

            <button type="button" onClick={onRollbackMl} disabled={loading || !canRollback}>
              {loading ? "Working..." : "Rollback"}
            </button>

            <button type="button" onClick={onSimulateProduction} disabled={loading}>
              {loading ? "Working..." : "Simulate"}
            </button>
          </div>

          {simulationStatus ? <p className="t23-feedback-note">Production simulation completed.</p> : null}
        </div>

        <div className="t23-control-card">
          <div className="t23-card-kicker">
            <ServerCog size={15} />
            Readiness
          </div>

          <strong>{safeNumber(architectureStatus?.readiness_score, 0)}%</strong>

          <p>
            {checks.filter((item) => item?.ok).length}/{checks.length || 0} backend checks passing.
          </p>

          <div className="t23-mini-checks">
            {checks.slice(0, 4).map((item) => (
              <span key={item.key}>
                {item.ok ? <CheckCircle2 size={13} /> : <XCircle size={13} />}
                {titleizeKey(item.key)}
              </span>
            ))}
          </div>
        </div>
      </div>

      {trained ? (
        <div className="ml-active-summary">
          <div><span>Active model</span><strong title={activeVersion}>{activeVersion.replace("ranker_", "")}</strong></div>
          <div><span>Mode</span><strong>{trainingMode}</strong></div>
          <div><span>Real samples</span><strong>{realSamples}</strong></div>
          <div><span>MAE</span><strong>{mae}</strong></div>
          <div><span>State</span><strong>{productionState}</strong></div>
        </div>
      ) : null}

      {versions.length ? (
        <div className="ml-version-history">
          <div className="t23-card-kicker">Model version history</div>

          <div className="ml-version-table">
            <div className="ml-version-row head">
              <span>Version</span>
              <span>Mode</span>
              <span>Samples</span>
              <span>MAE</span>
              <span>State</span>
            </div>

            {versions.map((item) => {
              const metadata = item?.metadata || {};
              const versionId = item?.version_id || metadata?.version_id || "-";
              const isActive = item?.active || versionId === activeVersion;

              return (
                <div className="ml-version-row" key={versionId}>
                  <span title={versionId}>{versionId}</span>
                  <span>{metadata?.training_mode || "-"}</span>
                  <span>
                    {safeNumber(metadata?.real_sample_count, 0)} / {safeNumber(metadata?.synthetic_sample_count, 0)}
                  </span>
                  <span>{metadata?.mae ?? "-"}</span>
                  <span className={isActive ? "version-pill active" : "version-pill shadow"}>
                    {isActive ? "active" : "shadow"}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      ) : null}

      <div className="t23-weights-grid">
        {Object.entries(weights)
          .filter(([key, value]) => key.endsWith("_weight") && typeof value === "number")
          .slice(0, 4)
          .map(([key, value]) => (
            <div className="t23-weight-chip" key={key}>
              <span>{titleizeKey(key.replace("_weight", ""))}</span>
              <strong>{compactPercent(value)}</strong>
            </div>
          ))}
      </div>

      <div className="learning-live-strip">
        <span>Feedback events: {safeNumber(feedback?.total_events, realSamples)}</span>
        <span>Positive: {safeNumber(feedback?.positive_signals, 0)}</span>
        <span>Negative: {safeNumber(feedback?.negative_signals, 0)}</span>
        <span>Auto-training: enabled</span>
      </div>
    </section>
  );
}

function SuggestionCard({ item, onSubmitFeedback, feedbackState }) {
  const rankReasons = Array.isArray(item?.rank_reasons) ? item.rank_reasons : [];
  const targetId = getTargetId(item);
  const state = feedbackState?.[targetId] || "idle";
  const disabled = state === "saving";

  return (
    <div className="t23-card t23-suggestion">
      <div className="t23-card-head">
        <strong>{item?.title || "Untitled suggestion"}</strong>
        <span className={`t23-severity ${severityClass(item?.impact)}`}>
          {item?.impact || "Low"}
        </span>
      </div>

      <p>{item?.description || "-"}</p>

      <div className="t23-suggestion-body">
        <div className="t23-feedback-stack">
          <button
            disabled={disabled}
            onClick={() =>
              onSubmitFeedback?.({
                item,
                verdict: "positive",
                score: 1,
                reason: "Helpful suggestion",
              })
            }
          >
            <ThumbsUp size={15} />
            Helpful
          </button>

          <button
            disabled={disabled}
            onClick={() =>
              onSubmitFeedback?.({
                item,
                verdict: "negative",
                score: -1,
                reason: "Not useful",
              })
            }
          >
            <ThumbsDown size={15} />
            Not useful
          </button>
        </div>

        {rankReasons.length > 0 ? (
          <div className="t23-rank-box">
            {rankReasons.slice(0, 2).map((reason, index) => (
              <div className="t23-list-row" key={`${item?.title || "suggestion"}-reason-${index}`}>
                <span>Reason {index + 1}</span>
                <em>{reason}</em>
              </div>
            ))}
          </div>
        ) : null}
      </div>

      {state !== "idle" && state !== "saving" ? (
        <div className="t23-feedback-note">Feedback saved as {state}.</div>
      ) : null}

      {state === "saving" ? <div className="t23-feedback-note">Saving feedback...</div> : null}
    </div>
  );
}

function ScreenshotCard({ title, aboveFoldSrc, fullSrc, altAbove, altFull }) {
  const [view, setView] = useState("above");
  const currentSrc = view === "above" ? aboveFoldSrc : fullSrc;

  return (
    <div className="t23-browser">
      <div className="t23-browser-bar">
        <span />
        <span />
        <span />
        <strong>{title}</strong>

        <div className="t23-segments">
          <button className={view === "above" ? "active" : ""} onClick={() => setView("above")}>
            Above
          </button>
          <button className={view === "full" ? "active" : ""} onClick={() => setView("full")}>
            Full
          </button>
        </div>
      </div>

      <div className={`t23-browser-body ${view === "full" ? "scrollable" : ""}`}>
        {currentSrc ? (
          <img src={currentSrc} alt={view === "above" ? altAbove : altFull} />
        ) : (
          <div className="t23-empty">No screenshot returned yet.</div>
        )}
      </div>
    </div>
  );
}

function FindingCard({ item }) {
  return (
    <div className="t23-card">
      <div className="t23-card-head">
        <strong>{item?.title || "Untitled finding"}</strong>
        <span className={`t23-severity ${severityClass(item?.severity)}`}>
          {item?.severity || "Low"}
        </span>
      </div>
      <p>{item?.description || "-"}</p>
    </div>
  );
}

function OverlayPreviewSection({ report }) {
  const overlayPreview = report?.overlay_preview;

  if (!overlayPreview) return null;

  return (
    <section className="t23-card ux-overlay-preview">
      <div className="t23-section-head compact">
        <div>
          <h2>AI Visual Redesign</h2>
          <p>Structural overlay preview generated from the analysis engine.</p>
        </div>
      </div>

      <div className="t23-browser">
        <div className="t23-browser-bar">
          <span />
          <span />
          <span />
          <strong>Overlay redesign preview</strong>
        </div>

        <div className="t23-browser-body ux-overlay-body">
          <img src={makeAssetUrl(overlayPreview)} alt="AI visual redesign overlay" />
        </div>
      </div>
    </section>
  );
}

function IntelligenceTabs({ report }) {
  const [activeTab, setActiveTab] = useState("benchmarks");

  const tabs = [
    { id: "benchmarks", label: "Benchmarks" },
    { id: "observability", label: "Observability" },
    { id: "ranking", label: "Ranking Diagnostics" },
    { id: "feedback", label: "Feedback" },
  ];

  return (
    <section className="t23-panel ux-tabs-panel">
      <div className="ux-tabs">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            className={activeTab === tab.id ? "is-active" : ""}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === "benchmarks" ? <BenchmarkTab report={report} /> : null}
      {activeTab === "observability" ? <ObservabilityPanel report={report} /> : null}
      {activeTab === "ranking" ? <RankingTab report={report} /> : null}
      {activeTab === "feedback" ? <FeedbackTab report={report} /> : null}
    </section>
  );
}

function BenchmarkTab({ report }) {
  const layout = report?.layout_similarity || {};
  const matches = Array.isArray(layout?.top_matches) ? layout.top_matches : [];

  return (
    <div className="t23-two align-start">
      <div className="t23-card ux-benchmark-score">
        <span>CLIP similarity match</span>
        <div className="ux-ring" style={{ "--ring-value": `${safeNumber(layout?.similarity, 0) * 3.6}deg` }}>
          <strong>{safeNumber(layout?.similarity, 0)}%</strong>
          <span>Similarity</span>
        </div>
        <p>{layout?.profile || "Awaiting layout similarity."}</p>
      </div>

      <div className="t23-card">
        <h3>Top patterns</h3>
        <div className="t23-stack">
          {matches.slice(0, 3).map((item, index) => (
            <div className="t23-list-row" key={index}>
              <span>{item?.profile || item?.label || "-"}</span>
              <strong>{safeNumber(item?.similarity, 0)}%</strong>
            </div>
          ))}

          {!matches.length ? (
            <p className="t23-muted">Benchmark matches will appear after analysis.</p>
          ) : null}
        </div>
      </div>
    </div>
  );
}

function RankingTab({ report }) {
  const diagnostics = report?.ranking_diagnostics || {};

  return (
    <div className="t23-stat-grid five">
      {[
        ["Model", diagnostics?.model_name || "-"],
        ["Type", diagnostics?.model_type || "-"],
        ["Samples", safeNumber(diagnostics?.training_samples, 0)],
        ["Feedback", diagnostics?.learned_from_feedback ? "Yes" : "No"],
        ["Source", diagnostics?.weights?.source || "-"],
      ].map(([label, value]) => (
        <div className="t23-stat" key={label}>
          <span>{label}</span>
          <strong>{String(value)}</strong>
        </div>
      ))}
    </div>
  );
}

function FeedbackTab({ report }) {
  const feedback = report?.feedback_summary || {};

  return (
    <div className="t23-stat-grid five">
      {[
        ["Total", feedback?.total_events],
        ["Positive", feedback?.positive_signals],
        ["Negative", feedback?.negative_signals],
        ["Accepted", feedback?.accepted_suggestions],
        ["Rejected", feedback?.rejected_suggestions],
      ].map(([label, value]) => (
        <div className="t23-stat" key={label}>
          <span>{label}</span>
          <strong>{safeNumber(value, 0)}</strong>
        </div>
      ))}
    </div>
  );
}

function SingleReportView(props) {
  const {
    report,
    onGenerateVariation,
    onSubmitFeedback,
    feedbackState,
    learningStatus,
    mlStatus,
    architectureStatus,
    controlLoading,
    onRefreshControlPlane,
    onRetrainLearning,
    onResetLearning,
    onTrainMlRanker,
    onSimulateProduction,
    onRollbackMlRanker,
    simulationStatus,
  } = props;

  const screenshots = report?.screenshots || {};
  const suggestions = Array.isArray(report?.suggestions) ? report.suggestions : [];
  const findings = Array.isArray(report?.findings) ? report.findings : [];
  const scores = report?.scores || {};
  const [activeRegion, setActiveRegion] = useState("nav");

  return (
    <>
      <section id="scores" className="t23-metric-grid">
        <MetricCard label="UX score" value={scores.ux_score} note="Overall UX" icon={Sparkles} />
        <MetricCard label="Attention" value={scores.attention_focus} note="Focus quality" icon={Target} />
        <MetricCard label="CTA" value={scores.cta_visibility} note="CTA strength" icon={Bot} />
        <MetricCard label="Readability" value={scores.readability} note="Text clarity" icon={Activity} />
      </section>

      <section id="redesign" className="t23-panel ux-system-panel">
        <div className="t23-section-head">
          <div>
            <h2>AI Redesign System</h2>
            <p>Recommendations, redesign preview, visual overlay, and transformation evidence.</p>
          </div>
        </div>

        <div className="ux-redesign-layout">
          <div>
            <div className="t23-section-head compact">
              <div>
                <h2>Top Recommendations</h2>
                <p>High-impact improvements ranked by expected value.</p>
              </div>
            </div>

            <div className="t23-stack">
              {suggestions.slice(0, 4).map((item, index) => (
                <SuggestionCard
                  key={`${item?.title || "suggestion"}-${index}`}
                  item={item}
                  onSubmitFeedback={onSubmitFeedback}
                  feedbackState={feedbackState}
                />
              ))}
            </div>
          </div>

          <div className="ux-redesign-stack">
            <RedesignPreviewSection report={report} />
          </div>

          {report?.overlay_preview && report?.redesign_transformation ? (
            <div className="ux-overlay-wide">
              <div className="overlay-layout">
                <OverlayPreviewSection report={report} />

                <OverlayInsightPanel
                  overlayData={{
                    focus_delta: report?.redesign_transformation?.deltas?.attention_focus,
                    cta_delta: report?.redesign_transformation?.deltas?.cta_visibility,
                    nav_before: report?.redesign_transformation?.before?.nav_items,
                    nav_after: report?.redesign_transformation?.after?.nav_items,
                    nodes_before: report?.redesign_transformation?.before?.above_fold_nodes,
                    nodes_after: report?.redesign_transformation?.after?.above_fold_nodes,
                    realism: report?.redesign_transformation?.realism_confidence,
                  }}
                  activeRegion={activeRegion}
                  onRegionChange={setActiveRegion}
                />
              </div>
            </div>
          ) : null}
        </div>
      </section>

      <section id="captures" className="t23-panel">
        <div className="t23-section-head">
          <div>
            <h2>Visual Capture</h2>
            <p>Desktop and mobile rendering used by the analysis engine.</p>
          </div>
        </div>

        <div className="ux-capture-grid">
          <ScreenshotCard
            title="Desktop"
            aboveFoldSrc={makeAssetUrl(screenshots.desktop || "")}
            fullSrc={makeAssetUrl(screenshots.desktop_full || screenshots.desktop || "")}
            altAbove="Desktop above-fold screenshot"
            altFull="Desktop full-page screenshot"
          />

          <ScreenshotCard
            title="Mobile"
            aboveFoldSrc={makeAssetUrl(screenshots.mobile || "")}
            fullSrc={makeAssetUrl(screenshots.mobile_full || screenshots.mobile || "")}
            altAbove="Mobile above-fold screenshot"
            altFull="Mobile full-page screenshot"
          />
        </div>
      </section>

      <section id="insights" className="t23-two align-start">
        <div className="t23-panel">
          <div className="t23-section-head">
            <div>
              <h2>Findings</h2>
              <p>Prioritized issues detected from page structure.</p>
            </div>
          </div>

          <div className="t23-stack">
            {findings.slice(0, 3).map((item, index) => (
              <FindingCard key={`${item?.title || "finding"}-${index}`} item={item} />
            ))}
          </div>
        </div>

        <div className="t23-panel">
          <div className="t23-section-head">
            <div>
              <h2>AI Summary</h2>
              <p>High-level UX assessment synthesized from the pipeline.</p>
            </div>
          </div>

          <div className="t23-note large">{report?.ai_summary || "-"}</div>
        </div>
      </section>

      <section id="intelligence">
        <IntelligenceTabs report={report} />
      </section>

      <section id="learning">
        <LearningControlPanel
          learningStatus={learningStatus}
          mlStatus={mlStatus}
          architectureStatus={architectureStatus}
          reportFeedbackSummary={report?.feedback_summary}
          loading={controlLoading}
          onRefresh={onRefreshControlPlane}
          onRetrain={onRetrainLearning}
          onReset={onResetLearning}
          onTrainMl={onTrainMlRanker}
          onRollbackMl={onRollbackMlRanker}
          onSimulateProduction={onSimulateProduction}
          simulationStatus={simulationStatus}
        />
      </section>
    </>
  );
}

function CompareView({ comparison }) {
  const your = comparison?.your_report || createPlaceholderAnalyzeReport("https://www.apple.com/");
  const competitor = comparison?.competitor_report || createPlaceholderAnalyzeReport("https://www.samsung.com/");

  return (
    <>
      <section className="t23-panel">
        <div className="t23-section-head">
          <div>
            <h2>
              <Trophy size={20} />
              Winner: {String(comparison?.winner || "tie")}
            </h2>
            <p>{comparison?.reasoning || "Run compare mode to generate competitive reasoning."}</p>
          </div>
        </div>
      </section>

      <section className="t23-two">
        <CompareSide title="Your page" report={your} />
        <CompareSide title="Competitor page" report={competitor} />
      </section>
    </>
  );
}

function CompareSide({ title, report }) {
  const s = report?.scores || {};

  return (
    <div className="t23-panel">
      <div className="t23-section-head">
        <div>
          <h2>{title}</h2>
          <p>{report?.input_url || "-"}</p>
        </div>
      </div>

      <div className="t23-stat-grid">
        {[
          ["UX", s.ux_score],
          ["Focus", s.attention_focus],
          ["CTA", s.cta_visibility],
          ["Readability", s.readability],
        ].map(([label, value]) => (
          <div className="t23-stat" key={label}>
            <span>{label}</span>
            <strong>{safeNumber(value, 0)}</strong>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function AnalysisPage() {
  const [mode, setMode] = useState("analyze");
  const [url, setUrl] = useState("https://www.apple.com/");
  const [competitorUrl, setCompetitorUrl] = useState("https://www.samsung.com/");
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState(null);
  const [comparison, setComparison] = useState(null);
  const [error, setError] = useState("");
  const [feedbackState, setFeedbackState] = useState({});
  const [learningStatus, setLearningStatus] = useState(null);
  const [mlStatus, setMlStatus] = useState(null);
  const [architectureStatus, setArchitectureStatus] = useState(null);
  const [controlLoading, setControlLoading] = useState(false);
  const [simulationStatus, setSimulationStatus] = useState(null);

  const currentAnalyzeReport = useMemo(() => report || createPlaceholderAnalyzeReport(url), [report, url]);

  async function refreshControlPlane() {
    try {
      const domain = getDomainFromUrl(report?.input_url || url);
      const suffix = domain ? `?domain=${encodeURIComponent(domain)}` : "";

      const [lr, mr, ar] = await Promise.allSettled([
        fetch(`${LEARNING_STATUS_ENDPOINT}${suffix}`),
        fetch(ML_RANKER_STATUS_ENDPOINT),
        fetch(ARCHITECTURE_STATUS_ENDPOINT),
      ]);

      if (lr.status === "fulfilled" && lr.value.ok) setLearningStatus(await lr.value.json());
      if (mr.status === "fulfilled" && mr.value.ok) setMlStatus(await mr.value.json());
      if (ar.status === "fulfilled" && ar.value.ok) setArchitectureStatus(await ar.value.json());
    } catch (e) {
      console.warn("Control plane refresh failed", e);
    }
  }

  useEffect(() => {
    void refreshControlPlane();
  }, []);

  async function handleRetrainLearning() {
    setControlLoading(true);
    try {
      const res = await fetch(LEARNING_RETRAIN_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          domain: getDomainFromUrl(report?.input_url || url),
          persist: true,
        }),
      });

      if (!res.ok) throw new Error(`Learning retrain failed ${res.status}`);
      await refreshControlPlane();
    } catch (e) {
      console.warn(e);
      setError("Learning refresh failed.");
    } finally {
      setControlLoading(false);
    }
  }

  async function handleResetLearning() {
    setControlLoading(true);
    try {
      const res = await fetch(LEARNING_RESET_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      if (!res.ok) throw new Error(`Learning reset failed ${res.status}`);
      await refreshControlPlane();
    } catch (e) {
      console.warn(e);
      setError("Learning reset failed.");
    } finally {
      setControlLoading(false);
    }
  }

  async function handleTrainMlRanker() {
    setControlLoading(true);
    try {
      const res = await fetch(ML_RANKER_TRAIN_ENDPOINT, { method: "POST" });
      if (!res.ok) throw new Error(`ML ranker training failed ${res.status}`);

      const data = await res.json();
      setMlStatus(data?.result || data);
      await refreshControlPlane();
    } catch (e) {
      console.warn(e);
      setError("ML ranker training failed.");
    } finally {
      setControlLoading(false);
    }
  }

  async function handleRollbackMlRanker() {
    if (controlLoading) return;

    setControlLoading(true);
    setError("");

    try {
      const res = await fetch(ML_RANKER_ROLLBACK_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      if (!res.ok) throw new Error(`ML rollback failed ${res.status}`);

      const data = await res.json();
      setMlStatus(data?.status || data);
      await refreshControlPlane();
    } catch (e) {
      console.warn(e);
      setError("ML ranker rollback failed.");
    } finally {
      setControlLoading(false);
    }
  }

  async function handleSimulateProduction() {
    setControlLoading(true);
    setError("");

    try {
      const res = await fetch(ML_RANKER_SIMULATE_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      if (!res.ok) throw new Error(`Production simulation failed ${res.status}`);

      const data = await res.json();
      setSimulationStatus(data);
      await refreshControlPlane();
    } catch (e) {
      console.warn(e);
      setError("Production simulation failed.");
    } finally {
      setControlLoading(false);
    }
  }

  async function handleSubmitFeedback({ item, verdict, score, reason }) {
    if (!item) return;

    const targetId = getTargetId(item);
    const previous = feedbackState[targetId] || "idle";

    setFeedbackState((p) => ({ ...p, [targetId]: "saving" }));

    const payload = {
      workspace_id: report?.workspace_id ?? null,
      report_id: getReportId(report),
      feedback: {
        feedback_id: `fb_${Date.now()}_${Math.random().toString(16).slice(2)}`,
        user_id: "local-ui",
        workspace_id: report?.workspace_id ?? null,
        report_id: getReportId(report),
        created_at: new Date().toISOString(),
        free_text: reason || "UI feedback",
        labels: [
          {
            target_id: targetId,
            target_type: "suggestion",
            verdict,
            score,
            reason,
            metadata: {
              title: item?.title || "",
              impact: item?.impact || "",
              input_url: report?.input_url || url,
            },
          },
        ],
      },
    };

    try {
      const res = await fetch(FEEDBACK_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error(`Feedback failed ${res.status}`);

      const data = await res.json();

      setFeedbackState((p) => ({ ...p, [targetId]: verdict }));
      setReport((p) =>
        p
          ? {
              ...p,
              feedback_summary: data?.updated_feedback_summary || p.feedback_summary,
            }
          : p
      );

      await refreshControlPlane();
      window.setTimeout(() => {
        void refreshControlPlane();
      }, 1200);
    } catch (e) {
      console.warn(e);
      setFeedbackState((p) => ({ ...p, [targetId]: previous }));
      setError("Feedback could not be saved.");
    }
  }

  async function requestMockups(baseReport, suggestionTitle = null, variationIndex = 0) {
    const response = await fetch(GENERATE_MOCKUPS_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        report: baseReport,
        suggestion_title: suggestionTitle,
        variation_index: variationIndex,
      }),
    });

    if (!response.ok) throw new Error(`Mockup generation failed ${response.status}`);

    const data = await response.json();

    return {
      mockups: Array.isArray(data?.mockups) ? data.mockups : [],
      mockup_status: normalizeMockupStatusFromGenerateResponse(data, baseReport),
    };
  }

  async function generateInitialMockups(baseReport) {
    if (!baseReport?.redesign_suggestions?.length || !mockupsAvailable(baseReport)) return;

    setReport((p) => (p ? { ...p, mockups_loading: true } : p));

    try {
      const result = await requestMockups(baseReport, null, 0);

      setReport((p) =>
        p
          ? {
              ...p,
              redesign_mockups: result.mockups,
              mockups_loading: false,
              mockup_status: result.mockup_status || p.mockup_status,
            }
          : p
      );
    } catch (e) {
      console.warn(e);
      setReport((p) => (p ? { ...p, redesign_mockups: [], mockups_loading: false } : p));
    }
  }

  async function handleGenerateVariation(suggestionTitle) {
    if (!suggestionTitle || !report || !mockupsAvailable(report)) return;

    const nextVariation = safeNumber(report?.mockup_variations?.[suggestionTitle], 0) + 1;

    setReport((p) =>
      p
        ? {
            ...p,
            mockup_loading_titles: {
              ...(p.mockup_loading_titles || {}),
              [suggestionTitle]: true,
            },
            mockup_variations: {
              ...(p.mockup_variations || {}),
              [suggestionTitle]: nextVariation,
            },
          }
        : p
    );

    try {
      const result = await requestMockups(report, suggestionTitle, nextVariation);
      const returned = result.mockups[0] || null;

      setReport((p) => {
        if (!p) return p;

        const next = Array.isArray(p.redesign_mockups) ? p.redesign_mockups.slice() : [];

        if (returned) {
          const idx = next.findIndex((x) => x?.title === suggestionTitle);
          if (idx >= 0) next[idx] = returned;
          else next.push(returned);
        }

        return {
          ...p,
          redesign_mockups: next,
          mockup_loading_titles: {
            ...(p.mockup_loading_titles || {}),
            [suggestionTitle]: false,
          },
          mockup_status: result.mockup_status || p.mockup_status,
        };
      });
    } catch (e) {
      console.warn(e);
      setReport((p) =>
        p
          ? {
              ...p,
              mockup_loading_titles: {
                ...(p.mockup_loading_titles || {}),
                [suggestionTitle]: false,
              },
            }
          : p
      );
    }
  }

  async function runAnalysis() {
    setLoading(true);
    setError("");

    try {
      const normalizedUrl = /^https?:\/\//i.test(url) ? url : `https://${url}`;

      const res = await fetch(ANALYZE_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: normalizedUrl }),
      });

      if (!res.ok) throw new Error(`Analyze failed ${res.status}`);

      const normalized = normalizeReport(await res.json());

      if (!normalized) {
        setReport(null);
        return;
      }

      const canGenerateMockups = mockupsAvailable(normalized);

      const nextReport = {
        ...normalized,
        redesign_mockups: Array.isArray(normalized?.redesign_mockups) ? normalized.redesign_mockups : [],
        mockups_loading:
          canGenerateMockups &&
          Array.isArray(normalized?.redesign_suggestions) &&
          normalized.redesign_suggestions.length > 0 &&
          (!Array.isArray(normalized?.redesign_mockups) || normalized.redesign_mockups.length === 0),
        mockup_loading_titles: {},
        mockup_variations: {},
      };

      setReport(nextReport);
      void refreshControlPlane();

    
    } catch (e) {
      console.error(e);
      setError("Analysis failed.");
      setReport(null);
    } finally {
      setLoading(false);
    }
  }

  async function runCompare() {
    setLoading(true);
    setError("");

    try {
      const res = await fetch(COMPARE_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ your_url: url, competitor_url: competitorUrl }),
      });

      if (!res.ok) throw new Error(`Compare failed ${res.status}`);

      setComparison(normalizeCompare(await res.json()) || null);
      void refreshControlPlane();
    } catch (e) {
      console.error(e);
      setError("Compare failed.");
      setComparison(null);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <HeroPanel
        mode={mode}
        setMode={setMode}
        url={url}
        setUrl={setUrl}
        competitorUrl={competitorUrl}
        setCompetitorUrl={setCompetitorUrl}
        loading={loading}
        runAnalysis={runAnalysis}
        runCompare={runCompare}
        report={report}
      />

      {error ? (
        <section className="t23-panel error">
          <h2>Error</h2>
          <p>{error}</p>
        </section>
      ) : null}

      {mode === "analyze" ? (
        <SingleReportView
          report={currentAnalyzeReport}
          onGenerateVariation={handleGenerateVariation}
          onSubmitFeedback={handleSubmitFeedback}
          feedbackState={feedbackState}
          learningStatus={learningStatus}
          mlStatus={mlStatus}
          architectureStatus={architectureStatus}
          controlLoading={controlLoading}
          onRefreshControlPlane={refreshControlPlane}
          onRetrainLearning={handleRetrainLearning}
          onResetLearning={handleResetLearning}
          onTrainMlRanker={handleTrainMlRanker}
          onSimulateProduction={handleSimulateProduction}
          onRollbackMlRanker={handleRollbackMlRanker}
          simulationStatus={simulationStatus}
        />
      ) : (
        <CompareView comparison={comparison} />
      )}
    </>
  );
}