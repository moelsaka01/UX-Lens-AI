# Backend upgrade pack: all 3 phases together

This pack applies the backend part of the upgrade without login and without paid/subscription services.

## What changed

### Phase 1 - Live feedback loop
- Keeps `/api/feedback`, `/api/feedback/summary`, `/api/feedback/themes`.
- Feedback is stored locally in SQLite through `storage_service.py`.
- Supports thumbs-up, thumbs-down, accepted, rejected, preferred variant, and free-text feedback.

### Phase 2 - Auto-learning weights
- Adds local/free `learning_pipeline_service.py`.
- Adds endpoints:
  - `GET /api/learning/status`
  - `GET /api/learning/weights/recommend`
  - `POST /api/learning/retrain`
  - `POST /api/learning/reset`
  - `POST /api/learning/weights`
- Uses existing local feedback and A/B results. No paid model training.

### Phase 3 - Production architecture foundation
- Adds local/free `production_architecture_service.py`.
- Adds endpoints:
  - `GET /api/architecture/status`
  - `GET /api/architecture/roadmap`
- Reports local readiness, SQLite health, generated file counts, capabilities, and free deployment notes.

## How to apply

Copy these files into your backend project:

```text
app/config.py
app/main.py
app/schemas.py
app/services/analysis_engine.py
app/services/evaluation_engine.py
app/services/feedback_service.py
app/services/ranking_service.py
app/services/redesign_engine.py
app/services/redesign_service.py
app/services/storage_service.py
app/services/learning_pipeline_service.py
app/services/production_architecture_service.py
requirements.txt
docker-compose.yml
```

Do not delete existing service files that are not included here, such as `local_image_service.py`, `clip_service.py`, `embedding_service.py`, `visual_analysis_service.py`, `visual_overlay_service.py`, `design_pattern_service.py`, and `capability_service.py`.

## Rebuild

```bash
docker compose up --build
```

## Quick endpoint checks

```bash
curl http://localhost:8000/api/health
curl http://localhost:8000/api/learning/status
curl http://localhost:8000/api/architecture/status
```
