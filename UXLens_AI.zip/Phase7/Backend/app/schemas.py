from __future__ import annotations

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, HttpUrl


class AnalyzeUrlRequest(BaseModel):
    url: HttpUrl
    include_mobile: bool = True
    include_desktop: bool = True
    include_benchmarking: bool = True
    include_comparison: bool = False
    include_design_pattern_classification: bool = True
    include_learning_ranker: bool = True
    include_feedback_context: bool = True
    include_ab_scoring: bool = True


class CompareRequest(BaseModel):
    your_url: HttpUrl
    competitor_url: HttpUrl


class Finding(BaseModel):
    title: str
    severity: Literal["Low", "Medium", "High"]
    description: str


class SuggestionEvidence(BaseModel):
    evidence_id: str = ""
    label: str = ""
    source: Literal[
        "signals",
        "scores",
        "findings",
        "layout_similarity",
        "benchmark_match",
        "visual_analysis",
        "historical",
        "evaluation",
        "feedback",
        "ab_test",
    ] = "signals"
    metric_key: str = ""
    value: Any = None
    operator: str = ""
    rationale: str = ""


class Suggestion(BaseModel):
    title: str
    impact: Literal["Low", "Medium", "High"]
    description: str
    evidence: list[SuggestionEvidence] = Field(default_factory=list)
    rank_score: float = 0.0
    rank_reasons: list[str] = Field(default_factory=list)
    dedupe_key: str = ""


class RedesignSuggestion(BaseModel):
    title: str
    current: str
    proposed: str
    impact: Literal["Low", "Medium", "High"]
    suggestion_type: Literal["cta", "navigation", "hero", "content", "layout"] = "layout"
    expected_outcomes: list[str] = Field(default_factory=list)
    evidence: list[SuggestionEvidence] = Field(default_factory=list)
    rank_score: float = 0.0
    rank_reasons: list[str] = Field(default_factory=list)
    confidence: float = 0.0
    variant_group: str = ""


class RedesignMockup(BaseModel):
    title: str
    prompt: str
    image_url: Optional[str] = None
    rationale: str = ""
    mode: Literal["visual_preview", "concept"] = "concept"
    variation_index: int = 0


class ScoreBlock(BaseModel):
    ux_score: int
    attention_focus: int
    cta_visibility: int
    readability: int
    cognitive_load: int


class BenchmarkRow(BaseModel):
    label: str
    current: int
    benchmark: int


class BenchmarkMatch(BaseModel):
    label: str = ""
    category: str = "-"
    similarity: int = 0
    description: str = ""


class LayoutMatch(BaseModel):
    title: str
    category: str
    score: int
    rationale: str


class CLIPMatch(BaseModel):
    profile: str
    category: str
    similarity: int
    rationale: str


class LayoutSimilarity(BaseModel):
    profile: str = ""
    similarity: int = 0
    summary: str = ""
    rationale: str = ""
    top_matches: list[CLIPMatch] = Field(default_factory=list)


class DesignPatternPrediction(BaseModel):
    label: str
    family: str = ""
    confidence: float = 0.0
    rationale: str = ""
    source: Literal["heuristic", "small_model", "llm", "hybrid"] = "heuristic"


class DesignPatternClassifierOutput(BaseModel):
    primary_pattern: str = ""
    primary_family: str = ""
    confidence: float = 0.0
    rationale: str = ""
    model_name: str = ""
    model_type: Literal["heuristic", "small_model", "llm", "hybrid"] = "heuristic"
    candidates: list[DesignPatternPrediction] = Field(default_factory=list)


class HistoricalPoint(BaseModel):
    label: str = "-"
    ux: int = 0
    focus: int = 0
    cta: int = 0
    readability: int = 0
    cognitive: int = 0
    timestamp: Optional[str] = None

    ux_score: Optional[int] = None
    attention_focus: Optional[int] = None
    cta_visibility: Optional[int] = None
    cognitive_load: Optional[int] = None


class HistoricalBenchmark(BaseModel):
    domain: str
    run_count: int
    latest_ux_score: int
    average_ux_score: float
    trend: str
    points: list[HistoricalPoint] = Field(default_factory=list)


class HeatmapSet(BaseModel):
    desktop: Optional[str] = None
    mobile: Optional[str] = None


class ExtractedSignals(BaseModel):
    title: str
    h1: str
    word_count: int
    heading_count: int
    paragraph_count: int
    image_count: int
    link_count: int
    button_count: int

    nav_items: int = 0
    hero_text_length: int
    primary_cta: str = ""
    sections: int = 0
    category_hint: str = "marketing"

    detected_type: Optional[str] = None
    nav_item_count: Optional[int] = None
    forms: int = 0
    cookie_banner: str = "No"

    has_cookie_banner: Optional[bool] = None
    page_category_hint: str = "marketing"
    primary_cta_label: str = ""
    meta_description: str = ""
    above_fold_words: int = 0
    above_fold_nodes: int = 0
    above_fold_buttons: int = 0
    cta_count: int = 0
    cta_above_fold_count: int = 0
    strong_cta_above_fold_count: int = 0
    weighted_cta_above_fold: float = 0.0
    largest_heading_px: int = 0
    avg_paragraph_words: float = 0.0
    form_count: int = 0
    section_count: int = 0
    extra: dict[str, Any] = Field(default_factory=dict)


class ScreenshotSet(BaseModel):
    desktop: Optional[str] = None
    desktop_full: Optional[str] = None
    mobile: Optional[str] = None
    mobile_full: Optional[str] = None


class HistoricalSummary(BaseModel):
    domain: str = "not-analyzed-yet"
    runs: int = 0
    latest_ux: int = 0
    average_ux: int = 0
    trend: str = "flat"


class WorkspaceMember(BaseModel):
    id: int | str = 0
    workspace_id: Optional[int | str] = None
    user_id: int | str = 0
    role: str = "member"
    name: str = ""
    email: Optional[str] = None
    joined_at: Optional[str] = None


class Workspace(BaseModel):
    id: int | str = 0
    name: str = ""
    brand_name: str = ""
    primary_color: str = ""
    secondary_color: str = ""
    logo_text: str = ""
    description: str = ""
    owner_id: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    members: list[WorkspaceMember] = Field(default_factory=list)


class WatchlistItem(BaseModel):
    watch_id: int | str = 0
    workspace_id: Optional[int | str] = None
    name: str = ""
    url: str
    notes: str = ""
    enabled: bool = True
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    last_checked_at: Optional[str] = None
    last_report_id: Optional[int] = None
    last_score: Optional[int] = None


class HistoryItem(BaseModel):
    report_id: int | str = 0
    workspace_id: Optional[int | str] = None
    input_url: str = ""
    detected_type: str = ""
    ux_score: int = 0
    generated_at: Optional[str] = None
    status: str = "completed"


class EvaluationMetric(BaseModel):
    score: int
    reason: str
    pressure_score: Optional[int] = None


class EvaluationIssueItem(BaseModel):
    key: str
    score: int
    pressure_score: int
    reason: str


class EvaluationBlock(BaseModel):
    confidence: float = 0.0
    score_breakdown: dict[str, EvaluationMetric | dict[str, Any]] = Field(default_factory=dict)
    priority_issue: str = ""
    priority_score: int = 0
    priority_reason: str = ""
    reasoning: str = ""
    issue_breakdown: list[EvaluationIssueItem | dict[str, Any]] = Field(default_factory=list)


class RankingWeightSet(BaseModel):
    version: str = "v1"
    source: Literal["static", "learned", "hybrid"] = "static"
    ux_weight: float = 0.0
    attention_focus_weight: float = 0.0
    cta_visibility_weight: float = 0.0
    readability_weight: float = 0.0
    cognitive_load_weight: float = 0.0
    novelty_weight: float = 0.0
    confidence_weight: float = 0.0
    business_alignment_weight: float = 0.0
    evidence_strength_weight: float = 0.0
    updated_at: Optional[str] = None


class RankingFeatureSnapshot(BaseModel):
    suggestion_title: str = ""
    features: dict[str, float] = Field(default_factory=dict)
    weighted_score: float = 0.0
    chosen: bool = False


class RankingDiagnostics(BaseModel):
    model_name: str = ""
    model_type: Literal["rule_based", "linear", "tree", "bandit", "ml", "hybrid"] = "rule_based"
    weights: Optional[RankingWeightSet] = None
    feature_snapshots: list[RankingFeatureSnapshot] = Field(default_factory=list)
    training_samples: int = 0
    learned_from_feedback: bool = False


class FeedbackLabel(BaseModel):
    target_id: str = ""
    target_type: Literal["report", "suggestion", "mockup", "variant", "ab_test"] = "suggestion"
    verdict: Literal["positive", "negative", "neutral", "accepted", "rejected", "preferred"] = "neutral"
    score: Optional[float] = None
    reason: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class UserFeedbackEvent(BaseModel):
    feedback_id: str = ""
    user_id: Optional[str] = None
    workspace_id: Optional[int | str] = None
    report_id: Optional[str] = None
    created_at: Optional[str] = None
    labels: list[FeedbackLabel] = Field(default_factory=list)
    free_text: str = ""


class FeedbackSummary(BaseModel):
    total_events: int = 0
    positive_signals: int = 0
    negative_signals: int = 0
    accepted_suggestions: int = 0
    rejected_suggestions: int = 0
    preferred_variants: dict[str, int] = Field(default_factory=dict)
    top_positive_themes: list[str] = Field(default_factory=list)
    top_negative_themes: list[str] = Field(default_factory=list)


class FeedbackLabelInput(BaseModel):
    target_id: str
    target_type: Literal["report", "suggestion", "mockup", "variant", "ab_test"] = "suggestion"
    verdict: Literal["positive", "negative", "neutral", "accepted", "rejected", "preferred"] = "neutral"
    score: float | None = None
    reason: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class UserFeedbackEventInput(BaseModel):
    feedback_id: str | None = None
    user_id: str | None = None
    free_text: str = ""
    labels: list[FeedbackLabelInput] = Field(default_factory=list)


class FeedbackRequest(BaseModel):
    report_id: str | None = None
    workspace_id: int | None = None
    input_url: str = ""
    feedback: UserFeedbackEventInput


class FeedbackResponse(BaseModel):
    ok: bool = True
    updated_feedback_summary: FeedbackSummary | dict[str, Any] | None = None


class ABVariantScore(BaseModel):
    variant_id: str
    label: str
    predicted_ux: float = 0.0
    predicted_ctr: float = 0.0
    predicted_conversion: float = 0.0
    predicted_bounce_reduction: float = 0.0
    confidence: float = 0.0
    rationale: str = ""


class ABTestScoring(BaseModel):
    available: bool = False
    scoring_type: Literal["heuristic", "offline_model", "online_experiment", "hybrid"] = "heuristic"
    winner_variant_id: str = ""
    baseline_variant_id: str = ""
    variants: list[ABVariantScore] = Field(default_factory=list)
    primary_metric: str = "predicted_conversion"
    summary: str = ""


class RedesignTransformation(BaseModel):
    before: dict[str, Any] = Field(default_factory=dict)
    after: dict[str, Any] = Field(default_factory=dict)
    deltas: dict[str, Any] = Field(default_factory=dict)
    assumptions: list[str] = Field(default_factory=list)
    realism_confidence: float = 0.0


class PipelineMetrics(BaseModel):
    steps: dict[str, float] = Field(default_factory=dict)


class MockupStatus(BaseModel):
    available: bool = False
    enabled: bool = False
    mode: str = "disabled"
    ui_mode: str = "concepts"
    reason: str = ""


class CapabilityProfile(BaseModel):
    redesign_ui_mode: Literal["concepts", "visual_previews"] = "concepts"
    mockups_available: bool = False
    design_pattern_classifier_available: bool = False
    learning_ranker_available: bool = False
    feedback_loop_available: bool = False
    ab_scoring_available: bool = False
    notes: list[str] = Field(default_factory=list)


class ReportResponse(BaseModel):
    report_id: int | None = None
    input_url: str
    detected_type: str
    scores: ScoreBlock
    findings: list[Finding]
    suggestions: list[Suggestion]
    redesign_suggestions: list[RedesignSuggestion] = Field(default_factory=list)

    benchmark: list[BenchmarkRow] = Field(default_factory=list)
    layout_matches: list[LayoutMatch] = Field(default_factory=list)

    screenshots: ScreenshotSet
    extracted_signals: ExtractedSignals
    history: list[HistoricalPoint] = Field(default_factory=list)

    ai_summary: str
    generated_at: str

    clip_matches: list[BenchmarkMatch] = Field(default_factory=list)
    top_matches: list[BenchmarkMatch] = Field(default_factory=list)
    historical: HistoricalSummary = Field(default_factory=HistoricalSummary)
    historical_runs: list[HistoricalPoint] = Field(default_factory=list)
    benchmark_profile: Optional[str] = None
    benchmark_profile_score: int = 0
    benchmark_profile_summary: str = ""

    heatmaps: Optional[HeatmapSet] = None
    visual_signals: Optional[dict[str, Any]] = None
    benchmark_match: Optional[BenchmarkMatch] = None
    retrieval_examples: Optional[list[Any]] = None
    layout_similarity: Optional[LayoutSimilarity] = None
    historical_benchmark: Optional[HistoricalBenchmark] = None
    redesign_mockups: list[RedesignMockup] = Field(default_factory=list)
    workspace_id: Optional[int] = None

    evaluation: Optional[EvaluationBlock | dict[str, Any]] = None
    redesign_transformation: Optional[RedesignTransformation | dict[str, Any]] = None
    overlay_preview: Optional[str] = None
    overlay_data: dict[str, Any] | None = None
    pipeline_metrics: Optional[dict[str, float] | PipelineMetrics] = None
    trace_id: Optional[str] = None
    mockup_status: Optional[MockupStatus | dict[str, Any]] = None

    capability_profile: Optional[CapabilityProfile | dict[str, Any]] = None
    design_pattern_classifier: Optional[DesignPatternClassifierOutput | dict[str, Any]] = None
    ranking_diagnostics: Optional[RankingDiagnostics | dict[str, Any]] = None
    feedback_summary: Optional[FeedbackSummary | dict[str, Any]] = None
    ab_test_scoring: Optional[ABTestScoring | dict[str, Any]] = None


class CompareDeltaBlock(BaseModel):
    ux_score_delta: int = 0
    attention_focus_delta: int = 0
    cta_visibility_delta: int = 0
    readability_delta: int = 0


class CompareResponse(BaseModel):
    your_report: ReportResponse
    competitor_report: ReportResponse
    winner: Literal["your_page", "competitor_page", "tie"]
    reasoning: str
    deltas: CompareDeltaBlock | dict[str, Any] | None = None


class GenerateMockupsRequest(BaseModel):
    report: ReportResponse
    suggestion_title: Optional[str] = None
    variation_index: int = 0
    mode: str | None = "renderer"


class GenerateMockupsResponse(BaseModel):
    mockups: list[RedesignMockup] = Field(default_factory=list)
    available: bool = True
    reason: str = ""
    mockup_status: Optional[MockupStatus | dict[str, Any]] = None


class RankingFeedbackIngestRequest(BaseModel):
    workspace_id: Optional[int | str] = None
    report_id: Optional[str] = None
    feedback: UserFeedbackEvent


class RankingFeedbackIngestResponse(BaseModel):
    success: bool = True
    message: str = ""
    updated_feedback_summary: Optional[FeedbackSummary] = None


class RankingWeightsPayload(BaseModel):
    ux_weight: float = 0.28
    attention_focus_weight: float = 0.22
    cta_visibility_weight: float = 0.22
    readability_weight: float = 0.10
    cognitive_load_weight: float = 0.10
    novelty_weight: float = 0.02
    confidence_weight: float = 0.03
    business_alignment_weight: float = 0.02
    evidence_strength_weight: float = 0.01


class RankingWeightsUpsertRequest(BaseModel):
    version: str = "v1"
    source: Literal["static", "learned", "hybrid"] = "hybrid"
    workspace_id: int | None = None
    weights: RankingWeightsPayload


class RankingWeightsResponse(BaseModel):
    ok: bool = True
    workspace_id: int | None = None
    version: str = "v1"
    weights: dict[str, float] = Field(default_factory=dict)
    source: Literal["static", "learned", "hybrid"] = "static"
    updated_at: str = ""


    class MLRankerStatus(BaseModel):
        available: bool = False
        trained: bool = False
        model_name: str = "local_sklearn_ranker"
        model_path: str = ""
        feature_count: int = 0
        training_samples: int = 0
        last_trained_at: Optional[str] = None
        metrics: dict[str, Any] = Field(default_factory=dict)
        reason: str = ""


class MLRankerTrainResponse(BaseModel):
    ok: bool = True
    trained: bool = False
    model_path: str = ""
    training_samples: int = 0
    metrics: dict[str, Any] = Field(default_factory=dict)
    message: str = ""


class SystemStateResponse(BaseModel):
    architecture: dict[str, Any] = Field(default_factory=dict)
    learning: dict[str, Any] = Field(default_factory=dict)
    ml_ranker: dict[str, Any] = Field(default_factory=dict)
    health: dict[str, Any] = Field(default_factory=dict)

