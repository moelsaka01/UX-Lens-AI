from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore",
    )

    # =========================================
    # Core App
    # =========================================

    app_name: str = "AI Visual Intelligence Platform API"
    api_prefix: str = "/api"

    base_dir: Path = Path(__file__).resolve().parent.parent
    static_dir: Path = base_dir / "static"

    screenshot_dir: Path = static_dir / "generated"
    mockup_dir: Path = static_dir / "generated" / "mockups"

    frontend_origin: str = "http://localhost:5173"

    # =========================================
    # CLIP / Embeddings
    # =========================================

    clip_model_name: str = "openai/clip-vit-base-patch32"
    clip_device: str = "cpu"
    clip_top_k: int = 3

    # =========================================
    # Visual Preview System
    # =========================================

    enable_mockup_generation: bool = True
    enable_async_mockups: bool = True
    enable_cpu_mockups: bool = False

    mockup_count: int = 1

    local_image_model: str = "runwayml/stable-diffusion-v1-5"

    use_safetensors: bool = True

    mockup_steps_cpu: int = 8
    mockup_steps_gpu: int = 18

    mockup_guidance_cpu: float = 5.8
    mockup_guidance_gpu: float = 7.0

    mockup_prompt_max_words: int = 42

    mockup_height: int = 900
    mockup_width: int = 1280

    mockup_fast_mode: bool = True
    mockup_fast_width: int = 704
    mockup_fast_height: int = 416

    mockup_base_seed: int = 1337

    # =========================================
    # Overlay System
    # =========================================

    enable_overlay_generation: bool = True
    overlay_dim_strength: float = 0.45
    overlay_highlight_color: tuple = (0, 255, 180)
    overlay_border_width: int = 4

    # =========================================
    # Evaluation System
    # =========================================

    enable_evaluation: bool = True
    evaluation_base_confidence: float = 0.6
    evaluation_signal_weight: float = 0.1

    # =========================================
    # Observability
    # =========================================

    enable_pipeline_metrics: bool = True
    log_pipeline_metrics: bool = True

    # =========================================
    # Learning System
    # =========================================

    enable_feedback_learning: bool = True
    enable_local_learning_pipeline: bool = True

    learning_min_signal_count: int = 1
    learning_default_version: str = "v1"

    # =========================================
    # Architecture
    # =========================================

    enable_architecture_status: bool = True
    architecture_mode: str = "local_free_no_login"

    max_recent_ab_results_for_learning: int = 200

    # =========================================
    # AI Image Provider
    # =========================================

    # Default production-safe mode
    # Renderer works locally without paid APIs
    image_provider: str = "renderer"

    # Optional external AI image provider
    replicate_api_token: str = ""
    replicate_model: str = "black-forest-labs/flux-schnell"


settings = Settings()

settings.screenshot_dir.mkdir(parents=True, exist_ok=True)
settings.mockup_dir.mkdir(parents=True, exist_ok=True)