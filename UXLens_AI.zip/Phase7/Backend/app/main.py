from __future__ import annotations

import asyncio
import uuid

from datetime import UTC, datetime
from typing import Any
from urllib.parse import urlparse

from fastapi import BackgroundTasks, FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.schemas import (
    AnalyzeUrlRequest,
    CompareRequest,
    CompareResponse,
    GenerateMockupsRequest,
    GenerateMockupsResponse,
    RankingFeedbackIngestRequest,
    RankingFeedbackIngestResponse,
    RankingWeightSet,
    ReportResponse,
)
from app.services.analysis_engine import analysis_engine
from app.services.local_image_service import local_image_service
from app.services.storage_service import storage_service
from app.services.learning_service import learning_service
from app.services.production_architecture_service import production_architecture_service
from app.services.learning_model_service import learning_model_service

app = FastAPI(title=settings.app_name)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin, "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory=settings.static_dir), name="static")

def _extract_domain(url: str | None) -> str | None:
    value = str(url or "").strip()
    if not value:
        return None
    try:
        parsed = urlparse(value)
        domain = (parsed.netloc or "").lower().strip()
        return domain or None
    except Exception:
        return None


def _normalize_mockup_health(raw: dict[str, Any] | None) -> dict[str, Any]:
    raw = raw or {}

    available = bool(raw.get("available", False))
    enabled = bool(raw.get("enabled", False))
    raw_mode = str(raw.get("mode", "") or "").strip().lower()
    raw_ui_mode = str(raw.get("ui_mode", "") or "").strip().lower()
    reason = str(raw.get("reason", "") or "")

    if available:
        mode = "visual_previews"
        ui_mode = "visual_previews"
    elif raw_mode in {"visual_previews", "visual-preview", "visual", "gpu"}:
        mode = "visual_previews"
        ui_mode = "visual_previews"
    elif raw_mode in {"concepts", "concept", "cpu", "disabled", "fallback", "cpu-disabled", "cpu_disabled"}:
        mode = raw_mode.replace("_", "-")
        ui_mode = "concepts"
    else:
        mode = "visual_previews" if available else "concepts"
        ui_mode = "visual_previews" if available else "concepts"

    if raw_ui_mode in {"concepts", "visual_previews"}:
        ui_mode = raw_ui_mode

    return {
        "available": available,
        "enabled": enabled,
        "mode": mode,
        "ui_mode": ui_mode,
        "reason": reason,
    }


def _default_ranking_weights() -> RankingWeightSet:
    return RankingWeightSet(
        version="v1",
        source="static",
        ux_weight=0.28,
        attention_focus_weight=0.22,
        cta_visibility_weight=0.22,
        readability_weight=0.10,
        cognitive_load_weight=0.10,
        novelty_weight=0.02,
        confidence_weight=0.03,
        business_alignment_weight=0.02,
        evidence_strength_weight=0.01,
        updated_at=datetime.now(UTC).isoformat(),
    )


def _get_workspace_id(workspace_id: int | str | None) -> int | None:
    if workspace_id is not None and str(workspace_id).isdigit():
        return int(workspace_id)
    return None

def _auto_train_ml_ranker(trigger: str = "feedback_auto_train") -> None:
    try:
        from app.scripts.train_ranker import train

        result = train(allow_bootstrap=True, trigger=trigger)
        print(f"[MLRanker] Auto-training result: {result}")
    except Exception as exc:
        print(f"[MLRanker] Auto-training failed: {exc}")

def _get_or_create_ranking_weights(
    workspace_id: int | str | None = None,
    version: str = "v1",
) -> RankingWeightSet:
    numeric_workspace_id = _get_workspace_id(workspace_id)

    weights = storage_service.get_ranking_weights(
        workspace_id=numeric_workspace_id,
        version=version,
    )
    if weights is not None:
        return weights

    default_weights = _default_ranking_weights()
    default_weights.version = version
    storage_service.upsert_ranking_weights(
        default_weights,
        workspace_id=numeric_workspace_id,
    )
    return default_weights


def _get_ranking_weights_no_create(
    workspace_id: int | str | None = None,
    version: str = "v1",
) -> RankingWeightSet:
    numeric_workspace_id = _get_workspace_id(workspace_id)

    weights = storage_service.get_ranking_weights(
        workspace_id=numeric_workspace_id,
        version=version,
    )
    if weights is not None:
        return weights

    default_weights = _default_ranking_weights()
    default_weights.version = version
    default_weights.updated_at = None
    return default_weights


def _validate_and_merge_weights(
    *,
    raw_weights: dict[str, Any],
    workspace_id: int | str | None = None,
    version: str = "v1",
    source: str = "learned",
) -> RankingWeightSet:
    current = _get_or_create_ranking_weights(
        workspace_id=workspace_id,
        version=version,
    )

    merged = current.model_dump()
    merged.update(
        {
            "version": version,
            "source": source,
            "updated_at": datetime.now(UTC).isoformat(),
        }
    )

    allowed_weight_keys = {
        "ux_weight",
        "attention_focus_weight",
        "cta_visibility_weight",
        "readability_weight",
        "cognitive_load_weight",
        "novelty_weight",
        "confidence_weight",
        "business_alignment_weight",
        "evidence_strength_weight",
    }

    unknown_keys = sorted([key for key in raw_weights.keys() if key not in allowed_weight_keys])
    if unknown_keys:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported ranking weight keys: {', '.join(unknown_keys)}",
        )

    for key, value in raw_weights.items():
        try:
            numeric = float(value)
        except (TypeError, ValueError) as exc:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid numeric weight for '{key}'.",
            ) from exc

        if numeric < 0:
            raise HTTPException(
                status_code=400,
                detail=f"Ranking weight '{key}' cannot be negative.",
            )

        merged[key] = numeric

    total = sum(float(merged[key]) for key in allowed_weight_keys)
    if total <= 0:
        raise HTTPException(
            status_code=400,
            detail="At least one ranking weight must be greater than zero.",
        )

    normalized = {}
    for key in allowed_weight_keys:
        normalized[key] = round(float(merged[key]) / total, 6)

    merged.update(normalized)
    return RankingWeightSet.model_validate(merged)


def _infer_learned_weights(
    *,
    workspace_id: int | str | None = None,
    version: str = "v1",
) -> tuple[RankingWeightSet, dict[str, Any]]:
    current = _get_or_create_ranking_weights(
        workspace_id=workspace_id,
        version=version,
    )
    feedback_summary = storage_service.get_feedback_summary(workspace_id=workspace_id)
    ab_results = storage_service.list_ab_test_results(workspace_id=workspace_id, limit=200)

    accepted = int(feedback_summary.accepted_suggestions or 0)
    rejected = int(feedback_summary.rejected_suggestions or 0)
    positive = int(feedback_summary.positive_signals or 0)
    negative = int(feedback_summary.negative_signals or 0)
    runs_recorded = len(ab_results)

    adjustments = {
        "ux_weight": 0.0,
        "attention_focus_weight": 0.0,
        "cta_visibility_weight": 0.0,
        "readability_weight": 0.0,
        "cognitive_load_weight": 0.0,
        "novelty_weight": 0.0,
        "confidence_weight": 0.0,
        "business_alignment_weight": 0.0,
        "evidence_strength_weight": 0.0,
    }

    if accepted > 0 or positive > 0:
        adjustments["business_alignment_weight"] += min(0.03, accepted * 0.003)
        adjustments["confidence_weight"] += min(0.03, positive * 0.002)
        adjustments["evidence_strength_weight"] += min(0.02, accepted * 0.002)

    if rejected > 0 or negative > 0:
        adjustments["novelty_weight"] += min(0.02, rejected * 0.002)
        adjustments["evidence_strength_weight"] += min(0.015, negative * 0.0015)

    if runs_recorded > 0:
        adjustments["cta_visibility_weight"] += min(0.03, runs_recorded * 0.0015)
        adjustments["attention_focus_weight"] += min(0.025, runs_recorded * 0.00125)

    proposed = {
        "ux_weight": float(current.ux_weight) + adjustments["ux_weight"],
        "attention_focus_weight": float(current.attention_focus_weight) + adjustments["attention_focus_weight"],
        "cta_visibility_weight": float(current.cta_visibility_weight) + adjustments["cta_visibility_weight"],
        "readability_weight": float(current.readability_weight) + adjustments["readability_weight"],
        "cognitive_load_weight": float(current.cognitive_load_weight) + adjustments["cognitive_load_weight"],
        "novelty_weight": float(current.novelty_weight) + adjustments["novelty_weight"],
        "confidence_weight": float(current.confidence_weight) + adjustments["confidence_weight"],
        "business_alignment_weight": float(current.business_alignment_weight) + adjustments["business_alignment_weight"],
        "evidence_strength_weight": float(current.evidence_strength_weight) + adjustments["evidence_strength_weight"],
    }

    learned = _validate_and_merge_weights(
        raw_weights=proposed,
        workspace_id=workspace_id,
        version=version,
        source="hybrid" if (accepted + rejected + runs_recorded) > 0 else "static",
    )

    diagnostics = {
        "feedback_summary": feedback_summary.model_dump(),
        "ab_runs_recorded": runs_recorded,
        "adjustments": adjustments,
        "base_weights": current.model_dump(),
    }
    return learned, diagnostics


def _capability_summary() -> dict[str, Any]:
    mockup_health = _normalize_mockup_health(local_image_service.health())
    feedback_summary = storage_service.get_feedback_summary()
    ranking_weights = _get_ranking_weights_no_create()
    ab_results = storage_service.list_ab_test_results(limit=200)

    return {
        "mockups": mockup_health,
        "redesign_ui_mode": str(mockup_health.get("ui_mode", "concepts")),
        "design_pattern_classifier": {
            "enabled": True,
            "mode": "analysis_engine",
            "notes": "Pattern and archetype classification is produced during analysis.",
        },
        "learning_ranking_weights": {
            "enabled": True,
            "version": ranking_weights.version,
            "source": ranking_weights.source,
            "weights": ranking_weights.model_dump(),
        },
        "user_feedback_loop": {
            "enabled": True,
            "summary": feedback_summary.model_dump(),
        },
        "ab_redesign_scoring": {
            "enabled": True,
            "runs_recorded": len(ab_results),
        },
    }


@app.get("/api/health")
def health() -> dict[str, Any]:
    capabilities = _capability_summary()
    mockup_health = capabilities["mockups"]

    return {
        "status": "ok",
        "app": settings.app_name,
        "mockups_enabled": bool(mockup_health.get("enabled", False)),
        "mockups_available": bool(mockup_health.get("available", False)),
        "mockup_mode": str(mockup_health.get("mode", "concepts")),
        "mockup_ui_mode": str(mockup_health.get("ui_mode", "concepts")),
        "redesign_ui_mode": str(capabilities.get("redesign_ui_mode", "concepts")),
        "capabilities": capabilities,
    }


@app.post("/api/analyze", response_model=ReportResponse)
async def analyze(request: AnalyzeUrlRequest) -> ReportResponse:
    return await analysis_engine.analyze_url(
        str(request.url),
        include_mobile=request.include_mobile,
        include_desktop=request.include_desktop,
        include_benchmarking=request.include_benchmarking,
        generate_mockups=False,
    )


@app.post("/api/compare", response_model=CompareResponse)
async def compare(request: CompareRequest) -> CompareResponse:
    return await analysis_engine.compare_urls(
        str(request.your_url),
        str(request.competitor_url),
        generate_mockups=False,
    )


@app.post("/api/generate-mockups", response_model=GenerateMockupsResponse)
async def generate_mockups(request: GenerateMockupsRequest) -> GenerateMockupsResponse:
    status = _normalize_mockup_health(local_image_service.health())

    if not bool(status["available"]) or str(status["ui_mode"]) != "visual_previews":
        payload = {
            "mockups": [],
            "available": False,
            "reason": str(status["reason"] or "Visual preview generation is unavailable."),
            "mockup_status": status,
        }
        return GenerateMockupsResponse.model_validate(payload)

    mockups = await analysis_engine.generate_mockups_for_report(
        request.report,
        suggestion_title=request.suggestion_title,
        variation_index=request.variation_index,
        mode=str(request.mode or "renderer"),
    )

    payload = {
        "mockups": mockups,
        "available": True,
        "reason": "",
        "mockup_status": status,
    }
    return GenerateMockupsResponse.model_validate(payload)


@app.get("/api/design-pattern-capabilities")
def design_pattern_capabilities() -> dict[str, Any]:
    return {
        "enabled": True,
        "classifier": {
            "available": True,
            "type": "hybrid",
            "description": (
                "Uses analysis-time signals plus benchmark and profile matching to classify page design patterns."
            ),
        },
        "supported_outputs": [
            "detected_type",
            "design_pattern_classifier",
            "benchmark_match",
            "layout_similarity",
            "redesign_suggestions",
        ],
    }


@app.get("/api/ranking-weights")
def get_ranking_weights(
    workspace_id: int | None = None,
    version: str = "v1",
) -> dict[str, Any]:
    weights = _get_or_create_ranking_weights(
        workspace_id=workspace_id,
        version=version,
    )
    feedback_summary = storage_service.get_feedback_summary(workspace_id=workspace_id)
    ab_results = storage_service.list_ab_test_results(workspace_id=workspace_id, limit=200)

    return {
        "weights": weights.model_dump(),
        "learning_enabled": True,
        "workspace_id": workspace_id,
        "version": version,
        "feedback_summary": feedback_summary.model_dump(),
        "ab_runs_recorded": len(ab_results),
    }


@app.post("/api/ranking-weights")
def update_ranking_weights(payload: dict[str, Any]) -> dict[str, Any]:
    raw_weights = payload.get("weights")
    if not isinstance(raw_weights, dict):
        raise HTTPException(status_code=400, detail="Payload must include a 'weights' object.")

    workspace_id_raw = payload.get("workspace_id")
    version = str(payload.get("version", "v1") or "v1")
    source = str(payload.get("source", "learned") or "learned")
    numeric_workspace_id = _get_workspace_id(workspace_id_raw)

    updated = _validate_and_merge_weights(
        raw_weights=raw_weights,
        workspace_id=numeric_workspace_id,
        version=version,
        source=source,
    )

    storage_service.upsert_ranking_weights(
        updated,
        workspace_id=numeric_workspace_id,
    )

    return {
        "ok": True,
        "weights": updated.model_dump(),
        "updated_keys": sorted(raw_weights.keys()),
        "normalized": True,
    }


@app.post("/api/ranking-weights/reset")
def reset_ranking_weights(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = payload or {}
    workspace_id_raw = payload.get("workspace_id")
    version = str(payload.get("version", "v1") or "v1")
    numeric_workspace_id = _get_workspace_id(workspace_id_raw)

    default_weights = _default_ranking_weights()
    default_weights.version = version
    default_weights.updated_at = datetime.now(UTC).isoformat()

    storage_service.upsert_ranking_weights(
        default_weights,
        workspace_id=numeric_workspace_id,
    )

    return {
        "ok": True,
        "weights": default_weights.model_dump(),
        "message": "Ranking weights reset to default profile.",
    }


@app.post("/api/ranking-weights/learn")
def learn_ranking_weights(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = payload or {}
    workspace_id_raw = payload.get("workspace_id")
    version = str(payload.get("version", "v1") or "v1")
    persist = bool(payload.get("persist", True))
    numeric_workspace_id = _get_workspace_id(workspace_id_raw)

    learned, diagnostics = _infer_learned_weights(
        workspace_id=numeric_workspace_id,
        version=version,
    )

    if persist:
        storage_service.upsert_ranking_weights(
            learned,
            workspace_id=numeric_workspace_id,
        )

    return {
        "ok": True,
        "persisted": persist,
        "weights": learned.model_dump(),
        "learning_enabled": True,
        "diagnostics": diagnostics,
    }


@app.post("/api/feedback", response_model=RankingFeedbackIngestResponse)
def submit_feedback(
    request: RankingFeedbackIngestRequest,
    background_tasks: BackgroundTasks,
) -> RankingFeedbackIngestResponse:
    input_url = ""

    if request.report_id and str(request.report_id).isdigit():
        existing_report = storage_service.get_report(int(str(request.report_id)))
        if existing_report is not None:
            input_url = existing_report.input_url

    if not input_url:
        try:
            for label in request.feedback.labels:
                metadata = label.metadata or {}
                candidate_url = str(metadata.get("input_url", "") or "").strip()
                if candidate_url:
                    input_url = candidate_url
                    break
        except Exception:
            input_url = ""

    storage_service.save_feedback_event(
        feedback=request.feedback,
        workspace_id=request.workspace_id,
        report_id=request.report_id,
        input_url=input_url,
    )

    background_tasks.add_task(_auto_train_ml_ranker, "feedback_auto_train")

    updated_feedback_summary = storage_service.get_feedback_summary(
        workspace_id=request.workspace_id,
        domain=_extract_domain(input_url),
    )

    payload = {
        "success": True,
        "message": "Feedback recorded successfully.",
        "updated_feedback_summary": updated_feedback_summary,
    }
    return RankingFeedbackIngestResponse.model_validate(payload)

@app.get("/api/feedback")
def list_feedback(
    workspace_id: int | None = None,
    domain: str | None = None,
    limit: int = 100,
) -> dict[str, Any]:
    events = storage_service.list_feedback_events(
        workspace_id=workspace_id,
        domain=domain,
        limit=limit,
    )
    summary = storage_service.get_feedback_summary(
        workspace_id=workspace_id,
        domain=domain,
    )

    return {
        "count": len(events),
        "summary": summary.model_dump(),
        "items": [item.model_dump() for item in events],
    }


@app.get("/api/feedback/summary")
def feedback_summary(
    workspace_id: int | None = None,
    domain: str | None = None,
) -> dict[str, Any]:
    summary = storage_service.get_feedback_summary(
        workspace_id=workspace_id,
        domain=domain,
    )
    return {
        "workspace_id": workspace_id,
        "domain": domain,
        "summary": summary.model_dump(),
    }


@app.get("/api/feedback/themes")
def feedback_themes(
    workspace_id: int | None = None,
    domain: str | None = None,
) -> dict[str, Any]:
    summary = storage_service.get_feedback_summary(
        workspace_id=workspace_id,
        domain=domain,
    )
    return {
        "workspace_id": workspace_id,
        "domain": domain,
        "top_positive_themes": list(summary.top_positive_themes or []),
        "top_negative_themes": list(summary.top_negative_themes or []),
        "preferred_variants": dict(summary.preferred_variants or {}),
    }


@app.post("/api/ab-score")
def score_ab_redesign(payload: dict[str, Any]) -> dict[str, Any]:
    baseline = payload.get("baseline", {}) if isinstance(payload.get("baseline", {}), dict) else {}
    variant = payload.get("variant", {}) if isinstance(payload.get("variant", {}), dict) else {}

    input_url = str(payload.get("input_url", "") or "")
    trace_id = str(payload.get("trace_id", "") or "") or None
    report_id = str(payload.get("report_id", "") or "") or None
    workspace_id_raw = payload.get("workspace_id")

    numeric_workspace_id = _get_workspace_id(workspace_id_raw)

    baseline_ux = float(baseline.get("ux_score", 0) or 0)
    variant_ux = float(variant.get("ux_score", 0) or 0)

    baseline_cta = float(baseline.get("cta_visibility", 0) or 0)
    variant_cta = float(variant.get("cta_visibility", 0) or 0)

    baseline_focus = float(baseline.get("attention_focus", 0) or 0)
    variant_focus = float(variant.get("attention_focus", 0) or 0)

    ux_delta = round(variant_ux - baseline_ux, 2)
    cta_delta = round(variant_cta - baseline_cta, 2)
    focus_delta = round(variant_focus - baseline_focus, 2)

    weighted_gain = round((ux_delta * 0.5) + (cta_delta * 0.3) + (focus_delta * 0.2), 2)

    if weighted_gain > 0:
        winner = "variant"
        winner_variant_id = "variant"
    elif weighted_gain < 0:
        winner = "baseline"
        winner_variant_id = "baseline"
    else:
        winner = "tie"
        winner_variant_id = ""

    result = {
        "id": f"ab_{datetime.now(UTC).timestamp()}",
        "input_url": input_url,
        "trace_id": trace_id,
        "winner": winner,
        "winner_variant_id": winner_variant_id,
        "weighted_gain": weighted_gain,
        "ux_delta": ux_delta,
        "cta_delta": cta_delta,
        "focus_delta": focus_delta,
        "baseline": baseline,
        "variant": variant,
    }

    variants_payload = [
        {
            "variant_id": "baseline",
            "label": "Current experience",
            "predicted_ux": baseline_ux,
            "predicted_ctr": round(max(0.01, baseline_cta / 200.0), 4),
            "predicted_conversion": round(max(0.01, baseline_ux / 250.0), 4),
            "predicted_bounce_reduction": 0.0,
            "confidence": 0.6,
            "rationale": "Baseline predicted from submitted baseline scores.",
        },
        {
            "variant_id": "variant",
            "label": "Submitted redesign variant",
            "predicted_ux": variant_ux,
            "predicted_ctr": round(max(0.01, variant_cta / 200.0), 4),
            "predicted_conversion": round(max(0.01, variant_ux / 250.0), 4),
            "predicted_bounce_reduction": round(max(0.0, weighted_gain / 100.0), 4),
            "confidence": 0.6,
            "rationale": "Variant predicted from submitted redesign scores.",
        },
    ]

    storage_service.save_ab_test_result(
        trace_id=trace_id,
        workspace_id=numeric_workspace_id,
        report_id=report_id,
        input_url=input_url,
        scoring_type="heuristic",
        baseline_variant_id="baseline",
        winner_variant_id=winner_variant_id,
        primary_metric="predicted_conversion",
        summary=f"Heuristic A/B scoring winner: {winner}. Weighted gain={weighted_gain}.",
        variants=variants_payload,
    )

    runs = storage_service.list_ab_test_results(
        workspace_id=numeric_workspace_id,
        domain=_extract_domain(input_url),
        limit=200,
    )

    return {
        "ok": True,
        "result": result,
        "runs_recorded": len(runs),
    }


@app.get("/api/ab-score")
def list_ab_scores(
    workspace_id: int | None = None,
    domain: str | None = None,
    limit: int = 100,
) -> dict[str, Any]:
    items = storage_service.list_ab_test_results(
        workspace_id=workspace_id,
        domain=domain,
        limit=limit,
    )
    return {
        "count": len(items),
        "items": items,
    }


@app.post("/api/upload-demo")
async def upload_demo(file: UploadFile = File(...)) -> dict[str, str | int]:
    content = await file.read()
    return {
        "filename": file.filename or "upload",
        "size": len(content),
        "message": "Upload received. In a production extension, this would run the same visual intelligence pipeline on private screenshots.",
    }

# -----------------------------------------------------------------------------
# Phase 1-3 complete local backend endpoints
# No login, no paid services, no hosted training dependency.
# -----------------------------------------------------------------------------

@app.get("/api/learning/status")
def learning_status(
    workspace_id: int | None = None,
    domain: str | None = None,
) -> dict[str, Any]:
    return learning_service.status(
        workspace_id=workspace_id,
        domain=domain,
    )


@app.get("/api/learning/weights/recommend")
def recommend_learning_weights(
    workspace_id: int | None = None,
    domain: str | None = None,
    version: str = "v1",
) -> dict[str, Any]:
    return learning_service.recommend_weights(
        workspace_id=workspace_id,
        domain=domain,
        version=version,
    )


@app.post("/api/learning/retrain")
def retrain_learning_weights(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = payload or {}
    workspace_id = _get_workspace_id(payload.get("workspace_id"))
    domain = payload.get("domain")
    version = str(payload.get("version", "v1") or "v1")
    persist = bool(payload.get("persist", True))

    return learning_service.learn(
        workspace_id=workspace_id,
        domain=str(domain) if domain else None,
        version=version,
        persist=persist,
    )


@app.post("/api/learning/reset")
def reset_learning_weights(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = payload or {}
    workspace_id = _get_workspace_id(payload.get("workspace_id"))
    version = str(payload.get("version", "v1") or "v1")
    return learning_service.reset(workspace_id=workspace_id, version=version)


@app.post("/api/learning/weights")
def upsert_learning_weights(payload: dict[str, Any]) -> dict[str, Any]:
    raw_weights = payload.get("weights")
    if not isinstance(raw_weights, dict):
        raise HTTPException(status_code=400, detail="Payload must include a weights object.")

    workspace_id = _get_workspace_id(payload.get("workspace_id"))
    version = str(payload.get("version", "v1") or "v1")
    source = str(payload.get("source", "hybrid") or "hybrid")

    try:
        weights = learning_service.upsert_weights(
            raw_weights=raw_weights,
            workspace_id=workspace_id,
            version=version,
            source=source,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "ok": True,
        "weights": weights.model_dump(),
        "normalized": True,
    }


@app.get("/api/architecture/status")
def architecture_status() -> dict[str, Any]:
    return production_architecture_service.snapshot()


@app.get("/api/architecture/roadmap")
def architecture_roadmap() -> dict[str, Any]:
    return production_architecture_service.roadmap()


@app.get("/api/system-state")
def system_state() -> dict[str, Any]:
    return {
        "architecture": production_architecture_service.snapshot(),
        "learning": learning_service.status(),
        "ml_ranker": learning_model_service.status(),
        "health": {
            "status": "ok",
            "app": settings.app_name,
        },
    }



@app.get("/api/ml-ranker/status")
def ml_ranker_status() -> dict[str, Any]:
    from app.scripts.train_ranker import status

    return status()


@app.post("/api/ml-ranker/train")
def train_ml_ranker(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    from app.scripts.train_ranker import train

    payload = payload or {}
    allow_bootstrap = bool(payload.get("allow_bootstrap", True))

    result = train(
        allow_bootstrap=allow_bootstrap,
        trigger=str(payload.get("trigger", "manual")),
    )

    return {
        "ok": bool(result.get("trained", False)),
        "result": result,
    }


@app.post("/api/ml-ranker/rollback")
def rollback_ml_ranker(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    from app.scripts.train_ranker import rollback

    payload = payload or {}
    return rollback(version_id=payload.get("version_id"))


@app.post("/api/ml-ranker/simulate-production")
def simulate_ml_ranker_production() -> dict[str, Any]:
    from app.scripts.train_ranker import simulate_production_batch

    return simulate_production_batch()

MOCKUP_JOBS: dict[str, dict[str, Any]] = {}


@app.post("/api/mockups/start")
async def start_mockup_job(
    request: GenerateMockupsRequest,
    background_tasks: BackgroundTasks,
) -> dict[str, Any]:
    job_id = f"preview_{uuid.uuid4().hex}"
    mode = str(getattr(request, "mode", "renderer") or "renderer")

    MOCKUP_JOBS[job_id] = {
        "job_id": job_id,
        "status": "pending",
        "progress": 0,
        "message": "Preview job queued.",
        "mockups": [],
        "result": [],
    }

    background_tasks.add_task(
        run_mockup_job,
        job_id,
        request.report,
        request.suggestion_title,
        request.variation_index,
        mode,
    )

    return {
        "job_id": job_id,
        "status": "pending",
        "progress": 0,
    }


@app.get("/api/mockups/status/{job_id}")
async def get_mockup_job_status(job_id: str) -> dict[str, Any]:
    return MOCKUP_JOBS.get(
        job_id,
        {
            "job_id": job_id,
            "status": "not_found",
            "progress": 0,
            "message": "Mockup job not found.",
            "mockups": [],
            "result": [],
        },
    )


async def run_mockup_job(
    job_id: str,
    report: ReportResponse,
    suggestion_title: str | None,
    variation_index: int,
    mode: str = "renderer",
) -> None:
    try:
        MOCKUP_JOBS[job_id].update(
            status="running",
            progress=15,
            message="Preparing redesign preview...",
        )

        await asyncio.sleep(0.2)

        MOCKUP_JOBS[job_id].update(
            progress=45,
            message="Rendering screenshot-aware redesign preview...",
        )

        mockups = await analysis_engine.generate_mockups_for_report(
            report=report,
            suggestion_title=suggestion_title,
            variation_index=variation_index,
            mode=mode,
        )
        
        serialized = [
            m.model_dump(mode="json") if hasattr(m, "model_dump") else m
            for m in mockups
        ]

        MOCKUP_JOBS[job_id].update(
            status="done",
            progress=100,
            message=(
                "Redesign preview generated."
                if serialized
                else "Preview job completed, but no image URL was returned."
            ),
            mockups=serialized,
            result=serialized,
        )

    except Exception as exc:
        MOCKUP_JOBS[job_id].update(
            status="failed",
            progress=100,
            message="Redesign preview generation failed.",
            error=str(exc),
            mockups=[],
            result=[],
        )