from __future__ import annotations

import json
import sqlite3
import sys
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import joblib
import numpy as np
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parents[2]
sys.path.append(str(ROOT))

from app.config import settings
from app.services.feature_store_service import FEATURE_KEYS
from app.services.model_registry_service import model_registry_service


MIN_REAL_SAMPLES = 5


def db_path() -> Path:
    return Path(settings.base_dir) / "app.db"


def model_dir() -> Path:
    path = Path(settings.base_dir) / "models" / "ranker"
    path.mkdir(parents=True, exist_ok=True)
    return path


def registry_path() -> Path:
    return model_dir() / "ranker_registry.json"


def label_from_verdict(verdict: str, score: float | None) -> float:
    verdict = str(verdict or "").lower().strip()

    if score is not None:
        numeric = float(score)
        if -1.0 <= numeric <= 1.0:
            return 92.0 if numeric > 0 else 18.0 if numeric < 0 else 55.0
        return max(0.0, min(100.0, numeric))

    if verdict in {"accepted", "preferred", "positive"}:
        return 92.0
    if verdict in {"rejected", "negative"}:
        return 18.0
    if verdict == "neutral":
        return 55.0
    return 50.0


def extract_features_from_label(row: sqlite3.Row) -> dict[str, float]:
    metadata: dict[str, Any] = {}
    try:
        metadata = json.loads(row["metadata_json"] or "{}")
    except Exception:
        metadata = {}

    title = str(row["target_id"] or metadata.get("title") or "").lower()
    target_type = str(row["target_type"] or "")

    return {
        "rank_score": float(metadata.get("rank_score", 0.0) or 0.0),
        "evidence_count": float(metadata.get("evidence_count", 0.0) or 0.0),
        "impact_high": 1.0 if str(metadata.get("impact", "")).lower() == "high" else 0.0,
        "impact_medium": 1.0 if str(metadata.get("impact", "")).lower() == "medium" else 0.0,
        "impact_low": 1.0 if str(metadata.get("impact", "")).lower() == "low" else 0.0,
        "title_cta": 1.0 if "cta" in title or "primary action" in title else 0.0,
        "title_nav": 1.0 if "nav" in title or "navigation" in title else 0.0,
        "title_copy": 1.0 if "copy" in title or "hero" in title or "messaging" in title else 0.0,
        "title_noise": 1.0 if "noise" in title or "clutter" in title or "competition" in title else 0.0,
        "target_suggestion": 1.0 if target_type == "suggestion" else 0.0,
    }


def load_training_rows() -> tuple[np.ndarray, np.ndarray, int]:
    path = db_path()
    if not path.exists():
        return np.empty((0, len(FEATURE_KEYS))), np.empty((0,)), 0

    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row

    try:
        rows = conn.execute(
            """
            SELECT target_id, target_type, verdict, score, metadata_json
            FROM feedback_labels
            WHERE target_type IN ('suggestion', 'variant', 'mockup')
            ORDER BY id ASC
            """
        ).fetchall()
    finally:
        conn.close()

    x_rows = []
    y_rows = []

    for row in rows:
        features = extract_features_from_label(row)
        x_rows.append([float(features.get(key, 0.0) or 0.0) for key in FEATURE_KEYS])
        y_rows.append(label_from_verdict(row["verdict"], row["score"]))

    return np.array(x_rows, dtype=float), np.array(y_rows, dtype=float), len(y_rows)


def synthetic_training_rows() -> tuple[np.ndarray, np.ndarray]:
    templates = [
        {"rank_score": 92, "evidence_count": 5, "impact_high": 1, "title_nav": 1, "target_suggestion": 1},
        {"rank_score": 88, "evidence_count": 4, "impact_high": 1, "title_cta": 1, "target_suggestion": 1},
        {"rank_score": 82, "evidence_count": 4, "impact_medium": 1, "title_copy": 1, "target_suggestion": 1},
        {"rank_score": 74, "evidence_count": 3, "impact_medium": 1, "title_noise": 1, "target_suggestion": 1},
        {"rank_score": 61, "evidence_count": 2, "impact_low": 1, "title_copy": 1, "target_suggestion": 1},
        {"rank_score": 42, "evidence_count": 1, "impact_low": 1, "target_suggestion": 1},
        {"rank_score": 30, "evidence_count": 1, "impact_low": 1, "title_noise": 1, "target_suggestion": 1},
        {"rank_score": 18, "evidence_count": 0, "impact_low": 1, "target_suggestion": 1},
    ]

    labels = [94, 91, 82, 76, 58, 42, 28, 18]

    x_rows = []
    for item in templates:
        x_rows.append([float(item.get(key, 0.0) or 0.0) for key in FEATURE_KEYS])

    return np.array(x_rows, dtype=float), np.array(labels, dtype=float)


def read_registry() -> dict[str, Any]:
    path = registry_path()
    if not path.exists():
        return {"active_version": "", "versions": []}

    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {"active_version": "", "versions": []}


def write_registry(data: dict[str, Any]) -> None:
    registry_path().write_text(json.dumps(data, indent=2), encoding="utf-8")


def register_version(model_path: Path, metadata: dict[str, Any]) -> dict[str, Any]:
    registry = read_registry()
    version_id = str(metadata.get("version_id") or model_path.stem)

    version = {
        "version_id": version_id,
        "model_path": str(model_path),
        "metadata": metadata,
        "created_at": datetime.now(UTC).isoformat(),
        "active": True,
    }

    versions = []
    for item in registry.get("versions", []):
        item["active"] = item.get("version_id") == version_id
        if item.get("version_id") != version_id:
            versions.append(item)

    versions.append(version)

    registry = {
        "active_version": version_id,
        "versions": versions[-10:],
    }
    write_registry(registry)

    model_registry_service.register_model(model_path=model_path, metadata=metadata)
    return version


def status() -> dict[str, Any]:
    registry = read_registry()
    active_version = str(registry.get("active_version") or "")
    versions = list(registry.get("versions") or [])
    active = next((item for item in versions if item.get("version_id") == active_version), None)

    _, _, real_samples = load_training_rows()

    return {
        "trained": bool(active),
        "active_version": active_version,
        "sample_count": int(active.get("metadata", {}).get("sample_count", 0)) if active else 0,
        "real_sample_count": real_samples,
        "training_mode": active.get("metadata", {}).get("training_mode", "none") if active else "none",
        "model_type": active.get("metadata", {}).get("model_type", "") if active else "",
        "mae": active.get("metadata", {}).get("mae") if active else None,
        "trained_at": active.get("metadata", {}).get("trained_at", "") if active else "",
        "production_state": active.get("metadata", {}).get("production_state", "active") if active else "waiting_for_training",
        "message": (
            "Production ML ranker is active."
            if active
            else f"Need {MIN_REAL_SAMPLES} feedback labels for real training. Bootstrap simulation is available."
        ),
        "versions": versions,
        "can_rollback": len(versions) >= 2,
    }


def train(*, allow_bootstrap: bool = True, trigger: str = "manual") -> dict[str, Any]:
    x, y, real_samples = load_training_rows()
    training_mode = "feedback"

    if len(y) < MIN_REAL_SAMPLES:
        if not allow_bootstrap:
            return {
                "trained": False,
                "reason": f"Need at least {MIN_REAL_SAMPLES} feedback labels to train the real ML ranker.",
                "sample_count": int(len(y)),
                "real_sample_count": real_samples,
                "required_samples": MIN_REAL_SAMPLES,
                "production_state": "waiting_for_feedback",
                "trained_at": datetime.now(UTC).isoformat(),
            }

        sx, sy = synthetic_training_rows()
        x = np.vstack([x, sx]) if len(y) else sx
        y = np.concatenate([y, sy]) if len(y) else sy
        training_mode = "bootstrap_simulation"

    if len(y) >= 10:
        x_train, x_test, y_train, y_test = train_test_split(
            x,
            y,
            test_size=0.25,
            random_state=42,
        )
    else:
        x_train, x_test, y_train, y_test = x, x, y, y

    model = RandomForestRegressor(
        n_estimators=160,
        max_depth=6,
        random_state=42,
        min_samples_leaf=1,
    )
    model.fit(x_train, y_train)

    preds = model.predict(x_test)
    mae = float(mean_absolute_error(y_test, preds))

    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S_%f")
    version_id = f"ranker_{stamp}"
    path = model_dir() / f"{version_id}.joblib"
    joblib.dump(model, path)

    metadata = {
        "trained": True,
        "version_id": version_id,
        "model_type": "RandomForestRegressor",
        "sample_count": int(len(y)),
        "real_sample_count": int(real_samples),
        "synthetic_sample_count": int(max(0, len(y) - real_samples)),
        "training_mode": training_mode,
        "trigger": trigger,
        "mae": round(mae, 4),
        "feature_keys": FEATURE_KEYS,
        "trained_at": datetime.now(UTC).isoformat(),
        "production_state": "shadow" if training_mode == "bootstrap_simulation" else "active",
    }

    register_version(path, metadata)

    return {
        **metadata,
        "model_path": str(path),
        "message": (
            "Bootstrap simulation model trained. Add real feedback to graduate to production-active mode."
            if training_mode == "bootstrap_simulation"
            else "Production ML ranker trained from real feedback."
        ),
    }


def rollback(version_id: str | None = None) -> dict[str, Any]:
    registry = read_registry()
    versions = list(registry.get("versions") or [])

    if not versions:
        return {"ok": False, "message": "No model versions exist yet."}

    active = str(registry.get("active_version") or "")

    if version_id:
        target = next((item for item in versions if item.get("version_id") == version_id), None)
    else:
        inactive = [item for item in versions if item.get("version_id") != active]
        target = inactive[-1] if inactive else None

    if not target:
        return {"ok": False, "message": "No rollback target found."}

    target_path = Path(str(target.get("model_path") or ""))
    if not target_path.exists():
        return {"ok": False, "message": f"Rollback model file is missing: {target_path}"}

    metadata = dict(target.get("metadata") or {})
    metadata["rollback_activated_at"] = datetime.now(UTC).isoformat()

    for item in versions:
        item["active"] = item.get("version_id") == target.get("version_id")

    write_registry({"active_version": target.get("version_id"), "versions": versions})
    model_registry_service.register_model(model_path=target_path, metadata=metadata)

    return {
        "ok": True,
        "active_version": target.get("version_id"),
        "message": f"Rolled back to {target.get('version_id')}.",
        "status": status(),
    }


def simulate_production_batch() -> dict[str, Any]:
    current = status()
    if not current.get("trained"):
        trained = train(allow_bootstrap=True, trigger="production_simulation")
        current = status()
    else:
        trained = None

    return {
        "ok": True,
        "mode": "production_simulation",
        "canary_percentage": 10,
        "shadow_predictions": 25,
        "fallback": "rule_based_ranker",
        "drift_status": "stable",
        "latency_budget_ms": 50,
        "active_version": current.get("active_version"),
        "training_result": trained,
        "message": "Simulated canary + shadow production behavior completed locally.",
    }


if __name__ == "__main__":
    print(json.dumps(train(allow_bootstrap=True, trigger="cli"), indent=2))