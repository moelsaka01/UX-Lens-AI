from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def main() -> None:
    train_script = ROOT / "app" / "scripts" / "train_ranker.py"

    result = subprocess.run(
        [sys.executable, str(train_script)],
        cwd=str(ROOT),
        text=True,
        capture_output=True,
        check=False,
    )

    payload = {
        "ok": result.returncode == 0,
        "stdout": result.stdout,
        "stderr": result.stderr,
        "returncode": result.returncode,
    }

    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()