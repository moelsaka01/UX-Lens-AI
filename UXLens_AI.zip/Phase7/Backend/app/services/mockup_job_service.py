from __future__ import annotations

import asyncio
import uuid
from datetime import UTC, datetime
from typing import Any

from app.schemas import ReportResponse


class MockupJobService:
    def __init__(self) -> None:
        self.jobs: dict[str, dict[str, Any]] = {}

    def _now(self) -> str:
        return datetime.now(UTC).isoformat()

    async def start_job(
        self,
        *,
        report: dict[str, Any],
        suggestion_title: str | None = None,
        variation_index: int = 0,
    ) -> dict[str, Any]:
        job_id = f"mockup_{uuid.uuid4().hex}"

        self.jobs[job_id] = {
            "job_id": job_id,
            "status": "queued",
            "progress": 0,
            "message": "Mockup job queued.",
            "mockups": [],
            "error": None,
            "created_at": self._now(),
            "updated_at": self._now(),
        }

        asyncio.create_task(
            self._run_job(
                job_id=job_id,
                report=report,
                suggestion_title=suggestion_title,
                variation_index=variation_index,
            )
        )

        return self.jobs[job_id]

    async def _run_job(
        self,
        *,
        job_id: str,
        report: dict[str, Any],
        suggestion_title: str | None,
        variation_index: int,
    ) -> None:
        try:
            self.jobs[job_id].update(
                {
                    "status": "running",
                    "progress": 15,
                    "message": "Preparing report payload.",
                    "updated_at": self._now(),
                }
            )

            parsed_report = ReportResponse.model_validate(report)

            self.jobs[job_id].update(
                {
                    "progress": 45,
                    "message": "Generating visual mockup assets.",
                    "updated_at": self._now(),
                }
            )

            from app.services.analysis_engine import analysis_engine

            mockups = await analysis_engine.generate_mockups_for_report(
                report=parsed_report,
                suggestion_title=suggestion_title,
                variation_index=variation_index,
            )

            self.jobs[job_id].update(
                {
                    "status": "done",
                    "progress": 100,
                    "message": "Mockup generation completed.",
                    "mockups": [m.model_dump(mode="json") for m in mockups],
                    "updated_at": self._now(),
                }
            )

        except Exception as exc:
            self.jobs[job_id].update(
                {
                    "status": "failed",
                    "progress": 100,
                    "message": "Mockup generation failed.",
                    "error": str(exc),
                    "updated_at": self._now(),
                }
            )

    def get_job(self, job_id: str) -> dict[str, Any] | None:
        return self.jobs.get(job_id)


mockup_job_service = MockupJobService()