from __future__ import annotations

from typing import Any

from app.schemas import Suggestion


FEATURE_KEYS = [
    "rank_score",
    "evidence_count",
    "impact_high",
    "impact_medium",
    "impact_low",
    "title_cta",
    "title_nav",
    "title_copy",
    "title_noise",
]


class FeatureStoreService:
    def features_from_suggestion(self, suggestion: Suggestion) -> dict[str, float]:
        title = str(suggestion.title or "").lower()
        impact = str(suggestion.impact or "").lower()

        return {
            "rank_score": float(suggestion.rank_score or 0.0),
            "evidence_count": float(len(suggestion.evidence or [])),
            "impact_high": 1.0 if impact == "high" else 0.0,
            "impact_medium": 1.0 if impact == "medium" else 0.0,
            "impact_low": 1.0 if impact == "low" else 0.0,
            "title_cta": 1.0 if "cta" in title or "primary action" in title else 0.0,
            "title_nav": 1.0 if "nav" in title or "navigation" in title else 0.0,
            "title_copy": 1.0 if "copy" in title or "hero" in title or "messaging" in title else 0.0,
            "title_noise": 1.0 if "noise" in title or "clutter" in title or "competition" in title else 0.0,
        }

    def vectorize(self, features: dict[str, Any]) -> list[float]:
        return [float(features.get(key, 0.0) or 0.0) for key in FEATURE_KEYS]


feature_store_service = FeatureStoreService()