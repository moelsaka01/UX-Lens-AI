from __future__ import annotations

from typing import Any

from app.schemas import (
    EvaluationBlock,
    EvaluationMetric,
    ExtractedSignals,
    FeedbackSummary,
    LayoutSimilarity,
    RankingWeightSet,
    ScoreBlock,
    Suggestion,
)


class EvaluationEngine:
    def evaluate(
        self,
        *,
        scores: ScoreBlock,
        signals: ExtractedSignals,
        metrics: dict[str, Any],
        findings: list[Any],
        suggestions: list[Suggestion],
        layout_similarity: LayoutSimilarity | None = None,
        feedback_summary: FeedbackSummary | None = None,
        ranking_weights: RankingWeightSet | None = None,
        capability_context: dict[str, Any] | None = None,
    ) -> EvaluationBlock:
        ranking_weights = ranking_weights or self._default_ranking_weights()
        capability_context = capability_context or {}

        score_breakdown = self._build_score_breakdown(
            scores=scores,
            signals=signals,
            metrics=metrics,
            findings=findings,
            suggestions=suggestions,
            layout_similarity=layout_similarity,
            feedback_summary=feedback_summary,
            ranking_weights=ranking_weights,
            capability_context=capability_context,
        )

        priority_issue = self._pick_priority_issue(score_breakdown)

        confidence = self._estimate_confidence(
            scores=scores,
            signals=signals,
            findings=findings,
            suggestions=suggestions,
            layout_similarity=layout_similarity,
            feedback_summary=feedback_summary,
            ranking_weights=ranking_weights,
            capability_context=capability_context,
        )

        return EvaluationBlock(
            confidence=confidence,
            score_breakdown=score_breakdown,
            priority_issue=priority_issue,
        )

    def _default_ranking_weights(self) -> RankingWeightSet:
        return RankingWeightSet(
            version="v1",
            source="static",
            ux_weight=0.28,
            attention_focus_weight=0.22,
            cta_visibility_weight=0.22,
            readability_weight=0.10,
            cognitive_load_weight=0.10,
            novelty_weight=0.02,
            confidence_weight=0.03,
            business_alignment_weight=0.02,
            evidence_strength_weight=0.01,
            updated_at=None,
        )

    def _build_score_breakdown(
        self,
        *,
        scores: ScoreBlock,
        signals: ExtractedSignals,
        metrics: dict[str, Any],
        findings: list[Any],
        suggestions: list[Suggestion],
        layout_similarity: LayoutSimilarity | None,
        feedback_summary: FeedbackSummary | None,
        ranking_weights: RankingWeightSet,
        capability_context: dict[str, Any],
    ) -> dict[str, EvaluationMetric]:
        nav_items = int(signals.nav_item_count or 0)
        cta_count = int(signals.cta_above_fold_count or 0)
        strong_cta_count = int(signals.strong_cta_above_fold_count or 0)
        above_fold_nodes = int(signals.above_fold_nodes or 0)
        hero_words = int(signals.hero_text_length or 0)
        weighted_cta = float(signals.weighted_cta_above_fold or 0.0)
        avg_paragraph_words = float(signals.avg_paragraph_words or 0.0)
        section_count = int(signals.section_count or 0)
        similarity = int(layout_similarity.similarity or 0) if layout_similarity else 0

        accepted_suggestions = int(feedback_summary.accepted_suggestions or 0) if feedback_summary else 0
        rejected_suggestions = int(feedback_summary.rejected_suggestions or 0) if feedback_summary else 0
        positive_signals = int(feedback_summary.positive_signals or 0) if feedback_summary else 0
        negative_signals = int(feedback_summary.negative_signals or 0) if feedback_summary else 0

        learned_ranker_available = bool(capability_context.get("learning_ranker_available", False))
        ab_scoring_available = bool(capability_context.get("ab_scoring_available", False))
        design_pattern_available = bool(capability_context.get("design_pattern_classifier_available", False))

        attention_penalty = max(0.0, 100.0 - float(scores.attention_focus))
        if above_fold_nodes > 260:
            attention_penalty += min(14.0, (above_fold_nodes - 260) / 8.0)
        if nav_items > 12:
            attention_penalty += min(10.0, nav_items - 12)
        if hero_words > 220:
            attention_penalty += min(6.0, (hero_words - 220) / 20.0)

        cta_penalty = max(0.0, 100.0 - float(scores.cta_visibility))
        if cta_count > 3:
            cta_penalty += min(10.0, cta_count - 3)
        if strong_cta_count > 3:
            cta_penalty += min(8.0, strong_cta_count - 3)
        if weighted_cta > 20:
            cta_penalty += 3.0
        if not str(signals.primary_cta_label or "").strip():
            cta_penalty += 5.0

        readability_penalty = max(0.0, 100.0 - float(scores.readability))
        if hero_words > 180:
            readability_penalty += min(10.0, (hero_words - 180) / 15.0)
        if avg_paragraph_words > 36:
            readability_penalty += 4.0
        if section_count > 10:
            readability_penalty += 2.0

        cognitive_penalty = max(0.0, 100.0 - float(scores.cognitive_load))
        if nav_items > 16:
            cognitive_penalty += min(10.0, nav_items - 16)
        if above_fold_nodes > 300:
            cognitive_penalty += min(10.0, (above_fold_nodes - 300) / 10.0)
        if hero_words > 220:
            cognitive_penalty += 4.0
        if cta_count >= 4:
            cognitive_penalty += 3.0

        visual_alignment_penalty = max(0.0, 100.0 - similarity) if similarity > 0 else 26.0

        evidence_strength_penalty = self._compute_evidence_strength_penalty(suggestions)
        feedback_risk_penalty = self._compute_feedback_risk_penalty(
            accepted_suggestions=accepted_suggestions,
            rejected_suggestions=rejected_suggestions,
            positive_signals=positive_signals,
            negative_signals=negative_signals,
        )

        experimentation_penalty = 10.0
        if ab_scoring_available:
            experimentation_penalty = 4.0
        if learned_ranker_available:
            experimentation_penalty -= 1.0
        experimentation_penalty = max(0.0, experimentation_penalty)

        pattern_confidence_penalty = 12.0
        if design_pattern_available:
            pattern_confidence_penalty = 5.0
        if similarity >= 80:
            pattern_confidence_penalty = max(0.0, pattern_confidence_penalty - 2.0)

        top_finding_text = " ".join(str(getattr(item, "title", "")).lower() for item in findings[:3])

        if "attention" in top_finding_text or "competing" in top_finding_text:
            attention_penalty += 6.0
        if "cta" in top_finding_text or "action" in top_finding_text:
            cta_penalty += 6.0
        if "readability" in top_finding_text or "hero message" in top_finding_text or "copy" in top_finding_text:
            readability_penalty += 5.0
        if "cognitive" in top_finding_text or "navigation" in top_finding_text:
            cognitive_penalty += 5.0

        weighted_ux_pressure = (
            (100.0 - float(scores.ux_score)) * float(ranking_weights.ux_weight)
            + attention_penalty * float(ranking_weights.attention_focus_weight)
            + cta_penalty * float(ranking_weights.cta_visibility_weight)
            + readability_penalty * float(ranking_weights.readability_weight)
            + cognitive_penalty * float(ranking_weights.cognitive_load_weight)
            + evidence_strength_penalty * float(ranking_weights.evidence_strength_weight) * 10.0
        )

        breakdown = {
            "attention_focus": EvaluationMetric(
                score=self._bounded_int(attention_penalty),
                reason=(
                    f"Attention focus is {scores.attention_focus}/100, with {above_fold_nodes} visible nodes, "
                    f"{nav_items} nav items, and about {hero_words} above-fold words affecting first-screen concentration."
                ),
            ),
            "cta_visibility": EvaluationMetric(
                score=self._bounded_int(cta_penalty),
                reason=(
                    f"CTA visibility is {scores.cta_visibility}/100, with {cta_count} CTA-like actions above the fold, "
                    f"{strong_cta_count} stronger CTA candidates, and weighted prominence {weighted_cta:.1f}."
                ),
            ),
            "readability": EvaluationMetric(
                score=self._bounded_int(readability_penalty),
                reason=(
                    f"Readability is {scores.readability}/100, with about {hero_words} above-fold words and "
                    f"average paragraph length of {avg_paragraph_words:.1f} words."
                ),
            ),
            "cognitive_load": EvaluationMetric(
                score=self._bounded_int(cognitive_penalty),
                reason=(
                    f"Cognitive load is {scores.cognitive_load}/100, shaped by {nav_items} nav items, "
                    f"{above_fold_nodes} visible nodes, {cta_count} CTA-like actions, and {hero_words} hero words."
                ),
            ),
            "visual_alignment": EvaluationMetric(
                score=self._bounded_int(visual_alignment_penalty),
                reason=(
                    f"Layout similarity is {similarity}/100 against benchmark patterns, indicating how closely "
                    f"the page aligns with strong reference structures."
                ),
            ),
            "evidence_strength": EvaluationMetric(
                score=self._bounded_int(evidence_strength_penalty),
                reason=(
                    f"Suggestion evidence quality is based on {self._average_evidence_count(suggestions):.1f} linked evidence items "
                    f"per suggestion across {len(suggestions)} ranked suggestions."
                ),
            ),
            "feedback_risk": EvaluationMetric(
                score=self._bounded_int(feedback_risk_penalty),
                reason=(
                    f"Feedback pressure reflects {accepted_suggestions} accepted suggestions, {rejected_suggestions} rejected suggestions, "
                    f"{positive_signals} positive signals, and {negative_signals} negative signals."
                ),
            ),
            "experimentation_readiness": EvaluationMetric(
                score=self._bounded_int(experimentation_penalty),
                reason=(
                    "Experimentation readiness reflects whether A/B scoring and learning-aware ranking are available "
                    "for redesign prioritization."
                ),
            ),
            "pattern_confidence": EvaluationMetric(
                score=self._bounded_int(pattern_confidence_penalty),
                reason=(
                    "Pattern confidence reflects whether design-pattern classification and benchmark similarity provide "
                    "stable structural context for redesign decisions."
                ),
            ),
            "overall_ux_pressure": EvaluationMetric(
                score=self._bounded_int(weighted_ux_pressure),
                reason=(
                    f"Weighted UX pressure combines UX score {scores.ux_score}/100 with attention, CTA, readability, "
                    f"cognitive, and evidence-strength pressure using the active ranking weights."
                ),
            ),
        }

        return breakdown

    def _pick_priority_issue(self, score_breakdown: dict[str, EvaluationMetric]) -> str:
        if not score_breakdown:
            return "overall_ux_pressure"

        ranked = sorted(
            score_breakdown.items(),
            key=lambda item: item[1].score,
            reverse=True,
        )
        return ranked[0][0]

    def _estimate_confidence(
        self,
        *,
        scores: ScoreBlock,
        signals: ExtractedSignals,
        findings: list[Any],
        suggestions: list[Suggestion],
        layout_similarity: LayoutSimilarity | None,
        feedback_summary: FeedbackSummary | None,
        ranking_weights: RankingWeightSet,
        capability_context: dict[str, Any],
    ) -> float:
        score_values = [
            int(scores.attention_focus),
            int(scores.cta_visibility),
            int(scores.readability),
            int(scores.cognitive_load),
        ]

        avg = sum(score_values) / max(1, len(score_values))
        variance_proxy = sum(abs(v - avg) for v in score_values) / max(1, len(score_values))

        signal_bonus = 0.0
        if int(signals.above_fold_nodes or 0) > 0:
            signal_bonus += 0.05
        if int(signals.cta_above_fold_count or 0) > 0:
            signal_bonus += 0.04
        if int(signals.hero_text_length or 0) > 0:
            signal_bonus += 0.04
        if int(signals.section_count or 0) > 0:
            signal_bonus += 0.02

        finding_bonus = min(0.12, len(findings) * 0.02)
        suggestion_bonus = min(0.10, len(suggestions) * 0.015)

        similarity_bonus = 0.0
        if layout_similarity and int(layout_similarity.similarity or 0) > 0:
            similarity_bonus = min(0.10, int(layout_similarity.similarity or 0) / 1000.0)

        consistency_bonus = max(0.0, 0.12 - min(0.12, variance_proxy / 100.0))

        evidence_bonus = min(0.10, self._average_evidence_count(suggestions) * 0.02)
        weight_bonus = 0.03 if str(ranking_weights.source or "static") in {"learned", "hybrid"} else 0.0

        capability_bonus = 0.0
        if capability_context.get("design_pattern_classifier_available"):
            capability_bonus += 0.03
        if capability_context.get("learning_ranker_available"):
            capability_bonus += 0.03
        if capability_context.get("ab_scoring_available"):
            capability_bonus += 0.02
        if capability_context.get("feedback_loop_available"):
            capability_bonus += 0.02

        feedback_bonus = 0.0
        if feedback_summary:
            positive = int(feedback_summary.positive_signals or 0)
            accepted = int(feedback_summary.accepted_suggestions or 0)
            rejected = int(feedback_summary.rejected_suggestions or 0)
            feedback_bonus += min(0.05, positive * 0.003)
            feedback_bonus += min(0.04, accepted * 0.004)
            feedback_bonus -= min(0.05, rejected * 0.004)

        confidence = (
            0.56
            + signal_bonus
            + finding_bonus
            + suggestion_bonus
            + similarity_bonus
            + consistency_bonus
            + evidence_bonus
            + weight_bonus
            + capability_bonus
            + feedback_bonus
        )

        return round(max(0.55, min(0.98, confidence)), 2)

    def _compute_evidence_strength_penalty(self, suggestions: list[Suggestion]) -> float:
        if not suggestions:
            return 30.0

        avg_evidence = self._average_evidence_count(suggestions)
        if avg_evidence >= 4.0:
            return 8.0
        if avg_evidence >= 3.0:
            return 12.0
        if avg_evidence >= 2.0:
            return 18.0
        if avg_evidence >= 1.0:
            return 24.0
        return 32.0

    def _average_evidence_count(self, suggestions: list[Suggestion]) -> float:
        if not suggestions:
            return 0.0
        total = sum(len(item.evidence or []) for item in suggestions)
        return total / max(1, len(suggestions))

    def _compute_feedback_risk_penalty(
        self,
        *,
        accepted_suggestions: int,
        rejected_suggestions: int,
        positive_signals: int,
        negative_signals: int,
    ) -> float:
        penalty = 18.0
        penalty -= min(8.0, accepted_suggestions * 1.0)
        penalty -= min(5.0, positive_signals * 0.4)
        penalty += min(10.0, rejected_suggestions * 1.2)
        penalty += min(8.0, negative_signals * 0.5)
        return max(0.0, min(100.0, penalty))

    def _bounded_int(self, value: float) -> int:
        return max(0, min(100, int(round(value))))


evaluation_engine = EvaluationEngine()