from __future__ import annotations

import asyncio
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from playwright.async_api import async_playwright

from app.config import settings
from app.schemas import (
    BenchmarkMatch,
    BenchmarkRow,
    CapabilityProfile,
    CompareResponse,
    EvaluationBlock,
    ExtractedSignals,
    Finding,
    HeatmapSet,
    HistoricalBenchmark,
    HistoricalPoint,
    LayoutMatch,
    LayoutSimilarity,
    MockupStatus,
    RedesignMockup,
    RedesignTransformation,
    ReportResponse,
    ScoreBlock,
    ScreenshotSet,
    Suggestion,
)
from app.services.capability_service import capability_service
from app.services.clip_service import clip_service
from app.services.design_pattern_service import design_pattern_service
from app.services.embedding_service import embedding_service
from app.services.evaluation_engine import evaluation_engine
from app.services.feedback_service import feedback_service
from app.services.local_image_service import local_image_service
from app.services.ranking_service import ranking_service
from app.services.redesign_engine import redesign_engine
from app.services.redesign_service import redesign_service
from app.services.storage_service import storage_service
from app.services.visual_analysis_service import visual_analysis_service
from app.services.visual_overlay_service import visual_overlay_service


class AnalysisEngine:
    def __init__(self) -> None:
        self.generated_dir = Path(settings.screenshot_dir)
        self.generated_dir.mkdir(parents=True, exist_ok=True)

    async def analyze_url(
        self,
        url: str,
        include_mobile: bool = True,
        include_desktop: bool = True,
        include_benchmarking: bool = True,
        workspace_id: int | None = None,
        generate_mockups: bool = False,
    ) -> ReportResponse:
        normalized_url = self._normalize_url(url)
        trace_id = uuid.uuid4().hex

        timings: dict[str, float] = {}
        observability: dict[str, Any] = {
            "trace_id": trace_id,
            "input_url": normalized_url,
            "started_at": datetime.now(timezone.utc).isoformat(),
        }

        analyze_start = time.perf_counter()

        async with async_playwright() as p:
            browser = await p.chromium.launch(
                headless=True,
                args=["--disable-dev-shm-usage", "--no-sandbox", "--disable-setuid-sandbox"],
            )

            try:
                desktop_metrics: dict[str, Any] = {}
                mobile_metrics: dict[str, Any] = {}
                desktop_above_path = ""
                desktop_full_path = ""
                mobile_above_path = ""
                mobile_full_path = ""

                screenshot_start = time.perf_counter()

                if include_desktop:
                    desktop_page = await browser.new_page(viewport={"width": 1440, "height": 1100})
                    try:
                        await self._prepare_page(desktop_page, normalized_url)
                        desktop_above_path, desktop_full_path = await self._capture_page_images(
                            desktop_page,
                            prefix="desktop",
                        )
                        desktop_metrics = await self._extract_page_metrics(desktop_page)
                    finally:
                        await desktop_page.close()

                if include_mobile:
                    mobile_context = await browser.new_context(
                        viewport={"width": 430, "height": 932},
                        device_scale_factor=2,
                        is_mobile=True,
                        has_touch=True,
                        user_agent=(
                            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) "
                            "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 "
                            "Mobile/15E148 Safari/604.1"
                        ),
                    )
                    try:
                        mobile_page = await mobile_context.new_page()
                        await self._prepare_page(mobile_page, normalized_url)
                        mobile_above_path, mobile_full_path = await self._capture_page_images(
                            mobile_page,
                            prefix="mobile",
                        )
                        mobile_metrics = await self._extract_page_metrics(mobile_page)
                    finally:
                        await mobile_context.close()

                timings["screenshot_and_extraction"] = round(time.perf_counter() - screenshot_start, 3)
                observability["screenshots"] = {
                    "desktop": desktop_above_path,
                    "desktop_full": desktop_full_path,
                    "mobile": mobile_above_path,
                    "mobile_full": mobile_full_path,
                }

                metrics_source = desktop_metrics or mobile_metrics or {}

                visual_start = time.perf_counter()

                visual_desktop = (
                    await asyncio.to_thread(visual_analysis_service.analyze, desktop_above_path, "desktop")
                    if desktop_above_path
                    else visual_analysis_service._empty()
                )
                visual_mobile = (
                    await asyncio.to_thread(visual_analysis_service.analyze, mobile_above_path, "mobile")
                    if mobile_above_path
                    else visual_analysis_service._empty()
                )

                timings["visual_analysis"] = round(time.perf_counter() - visual_start, 3)

                visual_source = visual_desktop or visual_mobile or {}

                metrics_source = {
                    **metrics_source,
                    "visual_entropy": visual_source.get("visual_entropy", 0),
                    "visual_clutter": visual_source.get("visual_clutter", 0),
                    "layout_busyness": visual_source.get("layout_busyness", 0),
                    "image_region_density": visual_source.get("image_region_density", 0),
                    "visual_complexity": visual_source.get("visual_complexity", 0),
                    "scan_intensity": visual_source.get("scan_intensity", 0),
                }

                scoring_start = time.perf_counter()

                signals = self._build_extracted_signals(
                    desktop_metrics=desktop_metrics,
                    mobile_metrics=mobile_metrics,
                )

                if signals.extra.get("blocked_by_protection"):
                    raise ValueError(
                        f"Protected page detected for {normalized_url}. "
                        "Cloudflare/CAPTCHA prevents reliable UX analysis."
                    )
                    
                page_archetype = self._infer_page_archetype(signals, metrics_source)

                design_pattern_classifier = design_pattern_service.classify(
                    normalized_url=normalized_url,
                    signals=signals,
                    metrics=metrics_source,
                    inferred_archetype=page_archetype,
                )

                scores = self._compute_scores(signals, metrics_source, page_archetype)

                findings = self._build_findings(
                    signals=signals,
                    metrics=metrics_source,
                    archetype=page_archetype,
                    scores=scores,
                )

                suggestions = self._build_suggestions(
                    signals=signals,
                    metrics=metrics_source,
                    findings=findings,
                    archetype=page_archetype,
                    scores=scores,
                )

                benchmark = self._build_benchmark_rows(scores, page_archetype) if include_benchmarking else []

                timings["scoring_and_rules"] = round(time.perf_counter() - scoring_start, 3)
                observability["archetype"] = page_archetype
                observability["scores"] = self._to_plain_data(scores)
                observability["design_pattern_classifier"] = self._to_plain_data(design_pattern_classifier)

                clip_start = time.perf_counter()

                clip_source_url = desktop_above_path or desktop_full_path or mobile_above_path or mobile_full_path
                clip_source_file = self._resolve_static_file(clip_source_url)

                layout_similarity: LayoutSimilarity = await asyncio.to_thread(
                    clip_service.compute_layout_similarity,
                    str(clip_source_file) if clip_source_file else None,
                    page_archetype,
                )

                layout_matches = self._build_layout_matches(layout_similarity)
                timings["clip_similarity"] = round(time.perf_counter() - clip_start, 3)

                retrieval_start = time.perf_counter()

                query_text = " ".join(
                    filter(
                        None,
                        [
                            normalized_url,
                            signals.title,
                            signals.h1,
                            signals.meta_description,
                            page_archetype,
                            signals.primary_cta_label,
                            design_pattern_classifier.primary_pattern,
                        ],
                    )
                )

                benchmark_match_dict, retrieval_examples = await asyncio.to_thread(
                    embedding_service.hybrid_profile_match,
                    query_text,
                    {
                        "ux_score": scores.ux_score,
                        "attention_focus": scores.attention_focus,
                        "cta_visibility": scores.cta_visibility,
                        "readability": scores.readability,
                        "cognitive_load": scores.cognitive_load,
                    },
                    5,
                )

                timings["benchmark_retrieval"] = round(time.perf_counter() - retrieval_start, 3)

                historical_benchmark = self._build_historical_benchmark(normalized_url, scores)

                raw_mockup_status = await asyncio.to_thread(local_image_service.health)
                mockup_status = self._normalize_mockup_mode(self._coerce_mockup_status(raw_mockup_status))

                feedback_summary = feedback_service.build_feedback_summary(
                    normalized_url=normalized_url,
                    workspace_id=workspace_id,
                )

                capability_profile = capability_service.build_capability_profile(
                    mockup_status=mockup_status,
                    design_pattern_classifier=design_pattern_classifier,
                    feedback_summary=feedback_summary,
                )

                redesign_start = time.perf_counter()

                redesign_suggestions, redesign_mockups = await asyncio.to_thread(
                    redesign_service.generate,
                    signals=signals,
                    scores=scores,
                    findings=findings,
                    archetype=page_archetype,
                    layout_similarity=layout_similarity,
                    input_url=normalized_url,
                    generate_mockups=generate_mockups,
                )

                evaluation: EvaluationBlock = await asyncio.to_thread(
                    evaluation_engine.evaluate,
                    scores=scores,
                    signals=signals,
                    metrics=metrics_source,
                    findings=findings,
                    suggestions=suggestions,
                    layout_similarity=layout_similarity,
                    feedback_summary=feedback_summary,
                )

                redesign_transformation_raw = await asyncio.to_thread(
                    redesign_engine.generate_transformation,
                    signals=signals,
                    scores=scores,
                    findings=findings,
                    suggestions=suggestions,
                    layout_similarity=layout_similarity,
                )

                redesign_transformation = self._enhance_transformation_realism(
                    redesign_transformation=redesign_transformation_raw,
                    signals=signals,
                    scores=scores,
                    suggestions=suggestions,
                )

                benchmark_match = self._build_benchmark_match(
                    benchmark_match_dict=benchmark_match_dict,
                    archetype=page_archetype,
                    scores=scores,
                )

                suggestions = ranking_service.rank_suggestions(
                    suggestions=suggestions,
                    signals=signals,
                    scores=scores,
                    findings=findings,
                    layout_similarity=layout_similarity,
                    benchmark_match=benchmark_match,
                    evaluation=evaluation,
                    feedback_summary=feedback_summary,
                    workspace_id=workspace_id,
                )

                ranking_diagnostics = ranking_service.build_ranking_diagnostics(
                    suggestions=suggestions,
                    workspace_id=workspace_id,
                )

                redesign_suggestions = ranking_service.enrich_redesign_suggestions(
                    redesign_suggestions=redesign_suggestions,
                    suggestions=suggestions,
                )

                ab_test_scoring = ranking_service.build_ab_test_scoring(
                    redesign_suggestions=redesign_suggestions,
                    scores=scores,
                    evaluation=evaluation,
                )

                overlay_preview = await asyncio.to_thread(
                    visual_overlay_service.generate_overlay,
                    desktop_above_path or mobile_above_path,
                    self._to_plain_data(redesign_transformation),
                )

                overlay_data = self._build_overlay_data(
                    signals=signals,
                    scores=scores,
                    redesign_transformation=redesign_transformation,
                )

                timings["evaluation_and_redesign"] = round(time.perf_counter() - redesign_start, 3)

                ai_summary = self._build_summary(
                    scores=scores,
                    findings=findings,
                    suggestions=suggestions,
                    metrics=metrics_source,
                    archetype=page_archetype,
                    layout_similarity=layout_similarity,
                    signals=signals,
                    historical_benchmark=historical_benchmark,
                    evaluation=evaluation,
                    redesign_transformation=redesign_transformation,
                    benchmark_match=benchmark_match,
                    design_pattern_classifier=design_pattern_classifier,
                    feedback_summary=feedback_summary,
                )

                timings["total_analysis"] = round(time.perf_counter() - analyze_start, 3)
                observability["finished_at"] = datetime.now(timezone.utc).isoformat()
                observability["pipeline_metrics"] = timings
                observability["evaluation_confidence"] = self._obj_get(evaluation, "confidence", None)
                observability["priority_issue"] = self._obj_get(evaluation, "priority_issue", "")
                observability["benchmark_label"] = getattr(benchmark_match, "label", "")
                observability["benchmark_similarity"] = getattr(benchmark_match, "similarity", 0)
                observability["findings_count"] = len(findings)
                observability["suggestions_count"] = len(suggestions)
                observability["mockups_count"] = len(redesign_mockups)
                observability["mockup_status"] = self._to_plain_data(mockup_status)
                observability["capability_profile"] = self._to_plain_data(capability_profile)
                observability["ranking_diagnostics"] = self._to_plain_data(ranking_diagnostics)
                observability["ab_test_scoring"] = self._to_plain_data(ab_test_scoring)
                observability["feedback_summary"] = self._to_plain_data(feedback_summary)
                observability["summary"] = ai_summary

                report = ReportResponse(
                    input_url=normalized_url,
                    detected_type=page_archetype,
                    scores=scores,
                    findings=findings,
                    suggestions=suggestions,
                    redesign_suggestions=redesign_suggestions,
                    benchmark=benchmark,
                    layout_matches=layout_matches,
                    screenshots=ScreenshotSet(
                        desktop=desktop_above_path if include_desktop else None,
                        mobile=mobile_above_path if include_mobile else None,
                        desktop_full=desktop_full_path if include_desktop else None,
                        mobile_full=mobile_full_path if include_mobile else None,
                    ),
                    heatmaps=HeatmapSet(
                        desktop=visual_desktop.get("heatmap"),
                        mobile=visual_mobile.get("heatmap"),
                    ),
                    extracted_signals=signals,
                    visual_signals={
                        "desktop": visual_desktop,
                        "mobile": visual_mobile,
                    },
                    benchmark_match=benchmark_match,
                    retrieval_examples=retrieval_examples,
                    layout_similarity=layout_similarity,
                    historical_benchmark=historical_benchmark,
                    redesign_mockups=redesign_mockups,
                    ai_summary=ai_summary,
                    generated_at=datetime.now(timezone.utc).isoformat(),
                    workspace_id=workspace_id,
                    evaluation=evaluation,
                    redesign_transformation=redesign_transformation,
                    overlay_preview=overlay_preview,
                    overlay_data=overlay_data,
                    pipeline_metrics=timings,
                    trace_id=trace_id,
                    mockup_status=mockup_status,
                    capability_profile=capability_profile,
                    design_pattern_classifier=design_pattern_classifier,
                    ranking_diagnostics=ranking_diagnostics,
                    feedback_summary=feedback_summary,
                    ab_test_scoring=ab_test_scoring,
                )

                try:
                    storage_service.create_report(report)
                    try:
                        storage_service.save_observability_record(
                            trace_id=trace_id,
                            input_url=normalized_url,
                            workspace_id=workspace_id,
                            payload=self._to_plain_data(
                                {
                                    "pipeline_metrics": timings,
                                    "observability": observability,
                                    "scores": scores,
                                    "archetype": page_archetype,
                                    "evaluation": evaluation,
                                    "benchmark_match": benchmark_match,
                                    "mockup_status": mockup_status,
                                    "capability_profile": capability_profile,
                                    "design_pattern_classifier": design_pattern_classifier,
                                    "ranking_diagnostics": ranking_diagnostics,
                                    "feedback_summary": feedback_summary,
                                    "ab_test_scoring": ab_test_scoring,
                                }
                            ),
                        )
                    except Exception as exc:
                        print(f"[WARN] Failed to persist observability for {normalized_url}: {exc}")
                except Exception as exc:
                    print(f"[WARN] Failed to persist report for {normalized_url}: {exc}")

                return report
            finally:
                await browser.close()

    async def generate_mockups_for_report(
        self,
        report: ReportResponse,
        suggestion_title: str | None = None,
        variation_index: int = 0,
        mode: str = "renderer",
    ) -> list[RedesignMockup]:
        status = self._normalize_mockup_mode(
            self._coerce_mockup_status(await asyncio.to_thread(local_image_service.health))
        )

        if not status.enabled:
            print(f"[Mockups] Disabled: {status.reason}")
            return []

        suggestions = list(report.redesign_suggestions or [])
        if not suggestions:
            print("[Mockups] No redesign suggestions available.")
            return []

        try:
            return await asyncio.to_thread(
                redesign_service.generate_mockups_only,
                suggestions=suggestions,
                signals=report.extracted_signals,
                scores=report.scores,
                archetype=report.detected_type,
                layout_similarity=report.layout_similarity,
                input_url=report.input_url,
                suggestion_title=suggestion_title,
                variation_index=variation_index,
                mode=mode,
            )
        except Exception as exc:
            print(
                f"[WARN] Failed to generate mockups for {report.input_url} "
                f"(suggestion_title={suggestion_title}, variation_index={variation_index}): {exc}"
            )
            return []

    async def compare_urls(
        self,
        your_url: str,
        competitor_url: str,
        workspace_id: int | None = None,
        generate_mockups: bool = False,
    ) -> CompareResponse:
        your_report, competitor_report = await asyncio.gather(
            self.analyze_url(your_url, True, True, True, workspace_id, generate_mockups),
            self.analyze_url(competitor_url, True, True, True, workspace_id, generate_mockups),
        )

        your_total = your_report.scores.ux_score
        competitor_total = competitor_report.scores.ux_score

        your_focus = your_report.scores.attention_focus
        competitor_focus = competitor_report.scores.attention_focus

        your_cta = your_report.scores.cta_visibility
        competitor_cta = competitor_report.scores.cta_visibility

        your_readability = your_report.scores.readability
        competitor_readability = competitor_report.scores.readability

        your_cognitive = your_report.scores.cognitive_load
        competitor_cognitive = competitor_report.scores.cognitive_load

        if your_total > competitor_total:
            winner = "your_page"
            reasoning = self._build_compare_reasoning(
                winner="your_page",
                winner_report=your_report,
                loser_report=competitor_report,
            )
        elif competitor_total > your_total:
            winner = "competitor_page"
            reasoning = self._build_compare_reasoning(
                winner="competitor_page",
                winner_report=competitor_report,
                loser_report=your_report,
            )
        else:
            winner = "tie"
            reasoning = (
                f"Both pages landed at {your_total}/100 overall. "
                f"Your page scored focus {your_focus} vs {competitor_focus}, CTA visibility {your_cta} vs {competitor_cta}, "
                f"readability {your_readability} vs {competitor_readability}, and cognitive load {your_cognitive} vs {competitor_cognitive}, "
                f"so neither experience created a decisive structural advantage."
            )

        return CompareResponse(
            your_report=your_report,
            competitor_report=competitor_report,
            winner=winner,
            reasoning=reasoning,
        )

    async def batch_analyze(
        self,
        urls: list[str],
        include_mobile: bool = True,
        include_desktop: bool = True,
        include_benchmarking: bool = True,
        workspace_id: int | None = None,
        generate_mockups: bool = False,
    ) -> list[ReportResponse]:
        return [
            await self.analyze_url(
                u,
                include_mobile=include_mobile,
                include_desktop=include_desktop,
                include_benchmarking=include_benchmarking,
                workspace_id=workspace_id,
                generate_mockups=generate_mockups,
            )
            for u in urls
        ]

    async def site_audit(self, urls: list[str], workspace_id: int | None = None) -> dict[str, Any]:
        reports = await self.batch_analyze(
            urls=urls,
            include_mobile=True,
            include_desktop=True,
            include_benchmarking=True,
            workspace_id=workspace_id,
        )
        if reports:
            avg_ux = round(sum(r.scores.ux_score for r in reports) / len(reports))
            avg_focus = round(sum(r.scores.attention_focus for r in reports) / len(reports))
            avg_cta = round(sum(r.scores.cta_visibility for r in reports) / len(reports))
        else:
            avg_ux = avg_focus = avg_cta = 0

        return {
            "reports": reports,
            "consistency_metrics": [
                {"label": "Average UX", "score": avg_ux, "summary": "Average calibrated UX score across audited pages."},
                {
                    "label": "Average Focus",
                    "score": avg_focus,
                    "summary": "Average attention concentration across first-screen layouts.",
                },
                {
                    "label": "Average CTA Clarity",
                    "score": avg_cta,
                    "summary": "Average visibility and dominance of primary actions.",
                },
            ],
            "summary": f"Site audit completed for {len(reports)} pages. Average UX score: {avg_ux}/100.",
        }

    async def _prepare_page(self, page: Any, url: str) -> None:
        await page.goto(url, wait_until="domcontentloaded", timeout=90000)
        await page.wait_for_timeout(1800)
        try:
            await page.wait_for_load_state("networkidle", timeout=15000)
        except Exception:
            pass
        await self._dismiss_common_overlays(page)
        await page.evaluate("window.scrollTo(0, 0)")
        await page.wait_for_timeout(900)

    async def _dismiss_common_overlays(self, page: Any) -> None:
        selectors = [
            "button[aria-label*=close i]",
            "button[aria-label*=dismiss i]",
            "button[title*=close i]",
            "[data-testid*=close i]",
            "button:has-text('Continue')",
            "button:has-text('Accept')",
            "button:has-text('Accept All')",
            "button:has-text('Got it')",
            "button:has-text('Not now')",
            "button:has-text('No thanks')",
            "button:has-text('×')",
        ]
        for selector in selectors:
            try:
                loc = page.locator(selector).first
                if await loc.is_visible(timeout=800):
                    await loc.click(timeout=800)
                    await page.wait_for_timeout(250)
            except Exception:
                pass

    async def _capture_page_images(self, page: Any, prefix: str) -> tuple[str, str]:
        file_id = uuid.uuid4().hex
        above_fold_file = self.generated_dir / f"{file_id}_{prefix}.png"
        full_file = self.generated_dir / f"{file_id}_{prefix}_full.png"

        await page.screenshot(path=str(above_fold_file), full_page=False)
        await page.screenshot(path=str(full_file), full_page=True)

        print(f"[INFO] Saved screenshot: {above_fold_file}")
        print(f"[INFO] Saved screenshot: {full_file}")

        return f"/static/generated/{above_fold_file.name}", f"/static/generated/{full_file.name}"

    def _resolve_static_file(self, static_url: str | None) -> Path | None:
        if not static_url:
            return None
        candidate = self.generated_dir / Path(static_url).name
        return candidate if candidate.exists() else None

    async def _extract_page_metrics(self, page: Any) -> dict[str, Any]:
        js = """
() => {
  const viewportH = window.innerHeight || document.documentElement.clientHeight || 0;
  const viewportW = window.innerWidth || document.documentElement.clientWidth || 0;
  const interactiveSelectors = ['a[href]','button','input[type="button"]','input[type="submit"]','[role="button"]','[onclick]'].join(',');
  const textSelectors = ['h1','h2','h3','h4','h5','h6','p','span','a','button','li','label'].join(',');
  const ctaTerms = ['buy','shop','start','get started','learn more','book','try','sign up','signup','register','contact','subscribe','continue','join','request demo','see pricing','add to cart','download','pre-order','order','compare','explore','watch','apply now'];
  const ignoreTerms = ['united arab emirates','search','menu','account','support','privacy','cookie','region','country','sign in','store locator'];
  const pageTextLower = document.body.innerText.toLowerCase();
  const blockedByProtection =
    pageTextLower.includes("verify you are human") ||
    pageTextLower.includes("checking your browser") ||
    pageTextLower.includes("cloudflare") ||
    pageTextLower.includes("captcha") ||
    pageTextLower.includes("security check") ||
    pageTextLower.includes("access denied") ||
    pageTextLower.includes("bot protection");
  
  function normText(text) { return (text || '').replace(/\\s+/g, ' ').trim(); }
  function isVisible(el) {
    if (!el) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 1 && rect.height > 1 && rect.bottom > 0 && rect.right > 0;
  }
  function isAboveFold(el) {
    if (!isVisible(el)) return false;
    const rect = el.getBoundingClientRect();
    return rect.top < viewportH && rect.left < viewportW && rect.bottom > 0;
  }
  function isIgnoredText(text) {
    const lower = normText(text).toLowerCase();
    return lower ? ignoreTerms.some(term => lower === term || lower.includes(term)) : false;
  }
  function isNavLike(el) {
    return !!el.closest('nav, header, footer, [role="navigation"], [role="menu"], dialog, [aria-modal="true"]');
  }
  function looksButtonLike(el) {
    const tag = (el.tagName || '').toLowerCase();
    const cls = String(el.className || '').toLowerCase();
    return tag === 'button' || cls.includes('button') || cls.includes('btn') || cls.includes('cta');
  }

  const allVisible = Array.from(document.querySelectorAll('body *')).filter(isVisible);
  const aboveFold = allVisible.filter(isAboveFold);
  const allInteractive = Array.from(document.querySelectorAll(interactiveSelectors)).filter(isVisible);
  const aboveFoldInteractive = allInteractive.filter(isAboveFold);
  const links = Array.from(document.querySelectorAll('a[href]')).filter(isVisible);
  const buttons = Array.from(document.querySelectorAll('button,input[type="button"],input[type="submit"],[role="button"]')).filter(isVisible);
  const images = Array.from(document.images || []).filter(isVisible);
  const headings = Array.from(document.querySelectorAll('h1,h2,h3,h4,h5,h6')).filter(isVisible);
  const paragraphs = Array.from(document.querySelectorAll('p')).filter(isVisible);
  const forms = Array.from(document.querySelectorAll('form')).filter(isVisible);
  const sections = Array.from(document.querySelectorAll('section, main > div, article')).filter(isVisible);

  const allTextNodes = Array.from(document.querySelectorAll(textSelectors)).filter(isVisible).map(el => normText(el.innerText)).filter(Boolean);
  const aboveFoldTextNodes = Array.from(document.querySelectorAll(textSelectors)).filter(isAboveFold).map(el => normText(el.innerText)).filter(Boolean);
  const pageText = allTextNodes.join(' ');
  const aboveFoldText = aboveFoldTextNodes.join(' ');
  const wordCount = normText(pageText).split(' ').filter(Boolean).length;
  const aboveFoldWords = normText(aboveFoldText).split(' ').filter(Boolean).length;

  const h1 = normText(document.querySelector('h1')?.innerText || '');
  const title = document.title || '';
  const metaDescription = document.querySelector('meta[name="description"]')?.content || '';

  const nav = document.querySelector('nav, header, [role="navigation"]');
  const navLinks = nav ? Array.from(nav.querySelectorAll('a[href],button,[role="button"]')).filter(isVisible).length : 0;

  const navVisualWeight =
  navLinks *
  (
      viewportW > 1200
      ? 0.45
      : 0.75
  );

  const ctaLike = aboveFoldInteractive.map(el => {
    const text = normText(el.innerText || el.getAttribute('aria-label') || el.value || '');
    const rect = el.getBoundingClientRect();
    const area = Math.max(0, rect.width * rect.height);
    const lower = text.toLowerCase();
    const matched = ctaTerms.some(term => lower.includes(term));
    return { text, area, matched, buttonLike: looksButtonLike(el), ignored: isIgnoredText(text), navLike: isNavLike(el), tag: (el.tagName || '').toLowerCase() };
  }).filter(item => !item.ignored && !item.navLike && (item.matched || item.buttonLike));

  const weightedCtaAboveFold = ctaLike.reduce((acc, item) => {
    let weight = 1.0;
    if (item.area >= 25000) weight += 1.0;
    else if (item.area >= 10000) weight += 0.5;
    if (item.matched) weight += 1.0;
    if (item.buttonLike) weight += 0.3;
    return acc + weight;
  }, 0);

  const primaryCta = ctaLike.slice().sort((a, b) => ((Number(b.matched) * 100000) + b.area) - ((Number(a.matched) * 100000) + a.area))[0];
  const strongCtas = ctaLike.filter(item => item.matched || item.area >= 10000);
  const paragraphWordCounts = paragraphs.map(p => normText(p.innerText).split(' ').filter(Boolean).length).filter(n => n > 0);
  const avgParagraphWords = paragraphWordCounts.length ? paragraphWordCounts.reduce((a, b) => a + b, 0) / paragraphWordCounts.length : 0;
  const lowerTitle = (title + ' ' + metaDescription + ' ' + h1).toLowerCase();
  const categoryHints = [];
  if (/pricing|plans|enterprise|platform|request demo|book demo|start free/.test(lowerTitle)) categoryHints.push('saas');
  if (/shop|buy|store|cart|accessories|iphone|macbook|watch|airpods|ipad/.test(lowerTitle)) categoryHints.push('commerce');
  if (/docs|documentation|guide|api/.test(lowerTitle)) categoryHints.push('docs');
  if (/dashboard|analytics|workspace/.test(lowerTitle)) categoryHints.push('dashboard');
  if (/blog|article|news|press/.test(lowerTitle)) categoryHints.push('content');

  return {
    title,
    meta_description: metaDescription,
    h1,
    word_count: wordCount,
    heading_count: headings.length,
    paragraph_count: paragraphs.length,
    image_count: images.length,
    button_count: buttons.length,
    link_count: links.length,
    form_count: forms.length,
    section_count: sections.length,
    total_nodes: allVisible.length,
    above_fold_nodes: aboveFold.length,
    above_fold_words: aboveFoldWords,
    visible_buttons_count: allInteractive.length,
    above_fold_buttons_count: aboveFoldInteractive.length,
    cta_count: ctaLike.length,
    cta_above_fold_count: ctaLike.length,
    strong_cta_above_fold_count: strongCtas.length,
    weighted_cta_above_fold: Number(weightedCtaAboveFold.toFixed(2)),
    nav_links_count: navLinks,
    avg_paragraph_words: Number(avgParagraphWords.toFixed(2)),
    hero_text_length: aboveFoldWords,
    has_cookie_banner: /cookie|privacy|region|country|consent/i.test(aboveFoldText.slice(0, 700)),
    page_category_hint: categoryHints[0] || 'marketing',
    primary_cta_label: primaryCta ? primaryCta.text : '',
    largest_heading_px: 0,
    nav_visual_weight: Number(navVisualWeight.toFixed(2)),
    blocked_by_protection: blockedByProtection,
  };
}
"""
        return await page.evaluate(js)

    def _build_extracted_signals(self, desktop_metrics: dict[str, Any], mobile_metrics: dict[str, Any]) -> ExtractedSignals:
        source = desktop_metrics or mobile_metrics or {}
        return ExtractedSignals(
            title=str(source.get("title") or ""),
            h1=str(source.get("h1") or ""),
            word_count=int(source.get("word_count") or 0),
            heading_count=int(source.get("heading_count") or 0),
            button_count=int(source.get("button_count") or 0),
            link_count=int(source.get("link_count") or 0),
            image_count=int(source.get("image_count") or 0),
            paragraph_count=int(source.get("paragraph_count") or 0),
            has_cookie_banner=bool(source.get("has_cookie_banner") or mobile_metrics.get("has_cookie_banner")),
            page_category_hint=str(source.get("page_category_hint") or "marketing"),
            hero_text_length=int(source.get("hero_text_length") or 0),
            nav_item_count=int(source.get("nav_links_count") or 0),
            form_count=int(source.get("form_count") or 0),
            section_count=int(source.get("section_count") or 0),
            primary_cta_label=str(source.get("primary_cta_label") or ""),
            meta_description=str(source.get("meta_description") or ""),
            above_fold_words=int(source.get("above_fold_words") or 0),
            above_fold_nodes=int(source.get("above_fold_nodes") or 0),
            above_fold_buttons=int(source.get("above_fold_buttons_count") or 0),
            cta_count=int(source.get("cta_count") or 0),
            cta_above_fold_count=int(source.get("cta_above_fold_count") or 0),
            strong_cta_above_fold_count=int(source.get("strong_cta_above_fold_count") or 0),
            weighted_cta_above_fold=float(
                source.get("weighted_ctaAboveFold") or source.get("weighted_cta_above_fold") or 0.0
            ),
            largest_heading_px=int(source.get("largest_heading_px") or 0),
            avg_paragraph_words=float(source.get("avg_paragraph_words") or 0.0),
            extra={
                "desktop_metrics": desktop_metrics,
                "mobile_metrics": mobile_metrics,
                "blocked_by_protection": bool(
                    source.get("blocked_by_protection")
                ),
            },
        )

    def _infer_page_archetype(self, signals: ExtractedSignals, metrics: dict[str, Any]) -> str:
        hint = (signals.page_category_hint or "").lower()
        if hint in {"commerce", "saas", "docs", "dashboard", "content", "marketing"}:
            return hint

        title_blob = " ".join([signals.title or "", signals.h1 or ""]).lower()
        if any(term in title_blob for term in ["shop", "buy", "store", "cart", "iphone", "mac", "watch"]):
            return "commerce"
        if any(term in title_blob for term in ["pricing", "platform", "request demo", "book demo", "enterprise"]):
            return "saas"
        if any(term in title_blob for term in ["docs", "documentation", "guide", "api"]):
            return "docs"
        if any(term in title_blob for term in ["dashboard", "workspace", "analytics"]):
            return "dashboard"
        if any(term in title_blob for term in ["blog", "article", "news", "press"]):
            return "content"
        if int(metrics.get("nav_links_count") or 0) >= 10 and int(metrics.get("image_count") or 0) >= 15:
            return "commerce"
        if int(signals.word_count or 0) > 1500 and int(metrics.get("cta_count") or 0) <= 2:
            return "content"
        return "marketing"

    def _compute_scores(self, signals: ExtractedSignals, metrics: dict[str, Any], archetype: str) -> ScoreBlock:
        nodes = int(metrics.get("above_fold_nodes") or 0)
        words = int(metrics.get("above_fold_words") or 0)
        nav = float(metrics.get("nav_visual_weight") or metrics.get("nav_links_count") or 0)
        visual_entropy = float(metrics.get("visual_entropy") or 0)
        visual_clutter = float(metrics.get("visual_clutter") or 0)
        layout_busyness = float(metrics.get("layout_busyness") or 0)

        cta_weight = float(metrics.get("weighted_cta_above_fold") or 0.0)
        strong_cta_count = int(signals.strong_cta_above_fold_count or 0)
        primary_cta = str(signals.primary_cta_label or "").strip()

        # ----------------------------
        # ATTENTION FOCUS
        # ----------------------------

        focus = 82.0

        if nodes > 180:
            focus -= (nodes - 180) * 0.07

        # extreme-density penalty
        if nodes > 320:
            focus -= (nodes - 320) * 0.10
        
        if words > 140:
            focus -= (words - 140) * 0.035

        if nav > 12:
            focus -= (nav - 12) * 1.1

        # positive rewards
        if nodes < 180:
            focus += 8

        if words < 80:
            focus += 6

        if nav <= 10:
            focus += 5

        if visual_entropy > 60:
            focus -= (visual_entropy - 60) * 0.25

        if visual_clutter > 65:
            focus -= (visual_clutter - 65) * 0.30

        if layout_busyness > 65:
            focus -= (layout_busyness - 65) * 0.25


        focus = self._clamp_score(focus, 25, 98)

        # ----------------------------
        # CTA
        # ----------------------------

        cta = 55.0

        if primary_cta:
            cta += 20

        if strong_cta_count == 1:
            cta += 15

        elif strong_cta_count == 2:
            cta += 10

        elif strong_cta_count == 3:
            cta += 5

        elif strong_cta_count >= 4:
            cta -= (strong_cta_count - 3) * 4

        if nodes > 300:
            cta -= 10

        if nodes > 400:
            cta -= 8

        if cta_weight > 20:
            cta -= 2


        cta = self._clamp_score(cta, 40, 98)

        # ----------------------------
        # READABILITY
        # ----------------------------

        readability = 78.0

        if signals.avg_paragraph_words > 38:
            readability -= 6

        if signals.heading_count < 2:
            readability -= 4

        if signals.hero_text_length > 160:
            readability -= (signals.hero_text_length - 160) * 0.03

        # rewards
        if signals.hero_text_length < 80:
            readability += 10

        if signals.heading_count >= 3:
            readability += 4

        readability = self._clamp_score(readability, 30, 99)

        # ----------------------------
        # COGNITIVE LOAD
        # ----------------------------

        cognitive = 84.0

        if nodes > 220:
            cognitive -= (nodes - 220) * 0.06

        # heavy-density penalty
        if nodes > 320:
            cognitive -= (nodes - 320) * 0.08

        if nav > 12:
            cognitive -= (nav - 12) * 1.2

        if strong_cta_count >= 5:
            cognitive -= (strong_cta_count - 4) * 1.5

        if signals.hero_text_length > 180:
            cognitive -= (signals.hero_text_length - 180) * 0.03

        # rewards
        if nodes < 180:
            cognitive += 6

        if nav <= 10:
            cognitive += 5

        if visual_entropy > 60:
            cognitive -= (visual_entropy - 60) * 0.20

        if visual_clutter > 65:
            cognitive -= (visual_clutter - 65) * 0.35

        if layout_busyness > 65:
            cognitive -= (layout_busyness - 65) * 0.25

        cognitive = self._clamp_score(cognitive, 25, 98)

        # ----------------------------
        # FINAL UX
        # ----------------------------

        ux = round(
            (focus * 0.34)
            + (cta * 0.28)
            + (readability * 0.18)
            + (cognitive * 0.20)
        )

        return ScoreBlock(
            ux_score=int(ux),
            attention_focus=int(round(focus)),
            cta_visibility=int(round(cta)),
            readability=int(round(readability)),
            cognitive_load=int(round(cognitive)),
        )

    def _build_findings(
        self,
        *,
        signals: ExtractedSignals,
        metrics: dict[str, Any],
        archetype: str,
        scores: ScoreBlock,
    ) -> list[Finding]:
        findings: list[Finding] = []
        nav_weight = float(metrics.get("nav_visual_weight") or signals.nav_item_count or 0)

        if nav_weight > 12:
            findings.append(
                Finding(
                    title="High navigation density",
                    severity="Medium" if signals.nav_item_count <= 20 else "High",
                    description=(
                        f"The first screen exposes {signals.nav_item_count} navigation choices, which is above the "
                        f"recommended 8-12 range for fast scanning and increases decision friction."
                    ),
                )
            )

        if signals.hero_text_length > 220:
            findings.append(
                Finding(
                    title="Hero message overload",
                    severity="Medium",
                    description=(
                        f"The above-fold area contains about {signals.hero_text_length} words, which makes the core value "
                        f"proposition slower to absorb before the next step becomes obvious."
                    ),
                )
            )

        if scores.cta_visibility < 78:
            findings.append(
                Finding(
                    title="Diffuse CTA hierarchy",
                    severity="High",
                    description=(
                        f"The page shows {signals.cta_above_fold_count} CTA-like interactive elements above the fold, "
                        f"with weighted prominence {signals.weighted_cta_above_fold:.1f}, which suggests the primary action "
                        f"does not dominate clearly enough."
                    ),
                )
            )

        if scores.attention_focus < 80:
            findings.append(
                Finding(
                    title="Competing first-screen elements",
                    severity="Medium",
                    description=(
                        f"The opening viewport contains {signals.above_fold_nodes} visible nodes and {signals.above_fold_words} "
                        f"words above the fold, creating too many simultaneous scan targets for a clean focal path."
                    ),
                )
            )

        if signals.cta_above_fold_count >= 5:
            findings.append(
                Finding(
                    title="Multiple above-fold actions compete",
                    severity="Medium",
                    description=(
                        f"There are {signals.cta_above_fold_count} CTA-like actions above the fold, which can weaken the dominance "
                        f"of the intended next step even when button visibility is strong."
                    ),
                )
            )

        if signals.above_fold_nodes >= 300:
            findings.append(
                Finding(
                    title="Dense first-screen scan field",
                    severity="Medium",
                    description=(
                        f"The first viewport contains about {signals.above_fold_nodes} visible nodes, indicating a heavy scan field "
                        f"that may slow orientation and reduce immediate clarity."
                    ),
                )
            )

        if signals.avg_paragraph_words > 38:
            findings.append(
                Finding(
                    title="Paragraph density is slightly heavy",
                    severity="Low",
                    description=(
                        f"Average paragraph length is about {signals.avg_paragraph_words:.1f} words, which may reduce scannability "
                        f"for a fast-converting landing experience."
                    ),
                )
            )

        if signals.primary_cta_label == "":
            findings.append(
                Finding(
                    title="Primary CTA label is not clearly dominant",
                    severity="Medium",
                    description=(
                        "The system could not confidently isolate one dominant primary CTA label from the visible first-screen actions."
                    ),
                )
            )

        if not findings:
            findings.append(
                Finding(
                    title="Strong first-screen structure",
                    severity="Low",
                    description=(
                        f"The page maintains a controlled first-screen layout with {signals.nav_item_count or 0} nav items, "
                        f"{signals.cta_above_fold_count or 0} CTA-like actions, and {signals.hero_text_length or 0} hero words, "
                        f"which supports a clear visual path."
                    ),
                )
            )

        ordered = sorted(
            findings,
            key=lambda item: {"High": 0, "Medium": 1, "Low": 2}.get(item.severity, 3),
        )
        return ordered[:8]

    def _build_suggestions(
        self,
        *,
        signals: ExtractedSignals,
        metrics: dict[str, Any],
        findings: list[Finding],
        archetype: str,
        scores: ScoreBlock,
    ) -> list[Suggestion]:
        suggestions: list[Suggestion] = []
        nav_weight = float(metrics.get("nav_visual_weight") or signals.nav_item_count or 0)

        if nav_weight > 12:
            suggestions.append(
                Suggestion(
                    title="Tighten navigation hierarchy",
                    impact="Medium" if signals.nav_item_count <= 20 else "High",
                    description=(
                        f"Reduce top-level navigation from {signals.nav_item_count} visible choices to roughly 8-10, "
                        f"or group lower-priority routes into menus so the header supports the hero instead of competing with it."
                    ),
                    dedupe_key="navigation_hierarchy",
                )
            )

        if scores.cta_visibility < 85 or signals.cta_above_fold_count >= 5:
            suggestions.append(
                Suggestion(
                    title="Create one dominant primary action",
                    impact="Medium",
                    description=(
                        f"Use one clearly dominant CTA above the fold and downgrade secondary actions. "
                        f"Current above-fold CTA count is {signals.cta_above_fold_count}, which is likely diluting action clarity."
                    ),
                    dedupe_key="primary_action_clarity",
                )
            )

        if scores.readability < 92 or signals.hero_text_length > 180:
            suggestions.append(
                Suggestion(
                    title="Compress hero copy",
                    impact="Medium",
                    description=(
                        f"Trim the opening message to a tighter headline-supporting line pair. "
                        f"The current above-fold copy load is about {signals.hero_text_length} words."
                    ),
                    dedupe_key="hero_copy_compression",
                )
            )

        if scores.attention_focus < 82 or signals.above_fold_nodes > 280:
            suggestions.append(
                Suggestion(
                    title="Reduce first-screen noise",
                    impact="Medium",
                    description=(
                        f"Simplify or defer lower-priority visual elements. The first viewport currently contains "
                        f"{signals.above_fold_nodes} visible nodes, which is high for a fast-scan landing experience."
                    ),
                    dedupe_key="first_screen_noise",
                )
            )

        if signals.avg_paragraph_words > 38 and not any(s.dedupe_key == "hero_copy_compression" for s in suggestions):
            suggestions.append(
                Suggestion(
                    title="Shorten dense body copy",
                    impact="Low",
                    description=(
                        "Tighten longer paragraphs and increase scan rhythm with shorter supporting lines, clearer subheads, and more breathing room."
                    ),
                    dedupe_key="body_copy_density",
                )
            )

        if signals.section_count and signals.section_count > 8:
            suggestions.append(
                Suggestion(
                    title="Improve section pacing",
                    impact="Low",
                    description=(
                        f"The page contains {signals.section_count} visible sections, so stronger grouping and spacing rhythm could improve perceived flow."
                    ),
                    dedupe_key="section_pacing",
                )
            )

        if (
            archetype in {"commerce", "marketing", "saas"}
            and signals.primary_cta_label
            and not any(s.dedupe_key == "primary_action_clarity" for s in suggestions)
        ):
            suggestions.append(
                Suggestion(
                    title="Strengthen CTA-message alignment",
                    impact="Low",
                    description=(
                        f"Make the hero message and the primary action '{signals.primary_cta_label}' feel more directly connected so the next step becomes more obvious."
                    ),
                    dedupe_key="cta_message_alignment",
                )
            )

        if not suggestions:
            suggestions.append(
                Suggestion(
                    title="Polish current hierarchy",
                    impact="Low",
                    description=(
                        "The structure is already strong. Use small spacing, emphasis, and proof-placement refinements "
                        "to further improve scan speed and confidence."
                    ),
                    dedupe_key="hierarchy_polish",
                )
            )

        return suggestions[:8]

    def _build_benchmark_rows(self, scores: ScoreBlock, archetype: str) -> list[BenchmarkRow]:
        archetype_targets = {
            "commerce": {"ux": 91, "focus": 88, "cta": 95, "readability": 90},
            "marketing": {"ux": 92, "focus": 89, "cta": 94, "readability": 91},
            "saas": {"ux": 90, "focus": 88, "cta": 93, "readability": 90},
            "content": {"ux": 89, "focus": 85, "cta": 80, "readability": 95},
            "docs": {"ux": 88, "focus": 84, "cta": 78, "readability": 94},
            "dashboard": {"ux": 87, "focus": 86, "cta": 82, "readability": 88},
        }
        target = archetype_targets.get(archetype, archetype_targets["marketing"])
        return [
            BenchmarkRow(label="CTA Prominence", current=int(scores.cta_visibility), benchmark=int(target["cta"])),
            BenchmarkRow(label="Attention Focus", current=int(scores.attention_focus), benchmark=int(target["focus"])),
            BenchmarkRow(label="Readability", current=int(scores.readability), benchmark=int(target["readability"])),
            BenchmarkRow(label="Overall UX", current=int(scores.ux_score), benchmark=int(target["ux"])),
        ]

    def _build_layout_matches(self, layout_similarity: LayoutSimilarity | None) -> list[LayoutMatch]:
        if layout_similarity is None:
            return []

        top_matches = getattr(layout_similarity, "top_matches", None) or []
        matches: list[LayoutMatch] = []

        for item in top_matches[:6]:
            matches.append(
                LayoutMatch(
                    title=str(getattr(item, "profile", "Unknown pattern")),
                    category=str(getattr(item, "category", "-")),
                    score=int(getattr(item, "similarity", 0)),
                    rationale=str(getattr(item, "rationale", "")),
                )
            )

        if not matches and layout_similarity.profile:
            matches.append(
                LayoutMatch(
                    title=layout_similarity.profile,
                    category="-",
                    score=int(layout_similarity.similarity or 0),
                    rationale=layout_similarity.summary or layout_similarity.rationale or "",
                )
            )

        return matches

    def _build_benchmark_match(
        self,
        *,
        benchmark_match_dict: dict[str, Any] | None,
        archetype: str,
        scores: ScoreBlock,
    ) -> BenchmarkMatch:
        if benchmark_match_dict:
            return BenchmarkMatch(
                label=str(benchmark_match_dict.get("profile") or benchmark_match_dict.get("label") or archetype.title()),
                category=str(benchmark_match_dict.get("category") or archetype),
                similarity=int(benchmark_match_dict.get("similarity") or 0),
                description=str(
                    benchmark_match_dict.get("rationale")
                    or benchmark_match_dict.get("description")
                    or f"Best-fit benchmark selected from the {archetype} pattern family."
                ),
            )

        return BenchmarkMatch(
            label=archetype.title(),
            category=archetype,
            similarity=min(99, max(72, int(scores.ux_score + 7))),
            description=f"Best-fit benchmark selected from the {archetype} pattern family.",
        )

    def _build_historical_benchmark(self, normalized_url: str, scores: ScoreBlock) -> HistoricalBenchmark:
        hostname = (urlparse(normalized_url).netloc or normalized_url).lower()
        past_reports = storage_service.list_reports_for_domain(hostname, limit=20)

        points: list[HistoricalPoint] = []
        for report in reversed(past_reports):
            report_scores = report.scores
            points.append(
                HistoricalPoint(
                    label=str(report.generated_at),
                    ux=int(report_scores.ux_score),
                    focus=int(report_scores.attention_focus),
                    cta=int(report_scores.cta_visibility),
                    readability=int(report_scores.readability),
                    cognitive=int(report_scores.cognitive_load),
                    timestamp=str(report.generated_at),
                )
            )

        if not points:
            return HistoricalBenchmark(
                domain=hostname,
                run_count=0,
                latest_ux_score=0,
                average_ux_score=0.0,
                trend="flat",
                points=[],
            )

        avg = round(sum(p.ux for p in points) / len(points), 1)
        trend = "flat"
        if len(points) >= 2:
            if points[-1].ux > points[0].ux:
                trend = "up"
            elif points[-1].ux < points[0].ux:
                trend = "down"

        return HistoricalBenchmark(
            domain=hostname,
            run_count=len(points),
            latest_ux_score=int(points[-1].ux),
            average_ux_score=float(avg),
            trend=trend,
            points=points,
        )

    def _build_summary(
        self,
        *,
        scores: ScoreBlock,
        findings: list[Finding],
        suggestions: list[Suggestion],
        metrics: dict[str, Any],
        archetype: str,
        layout_similarity: LayoutSimilarity | None,
        signals: ExtractedSignals,
        historical_benchmark: HistoricalBenchmark,
        evaluation: EvaluationBlock | dict[str, Any] | None = None,
        redesign_transformation: RedesignTransformation | dict[str, Any] | None = None,
        benchmark_match: BenchmarkMatch | None = None,
        design_pattern_classifier: Any = None,
        feedback_summary: Any = None,
    ) -> str:
        top_finding = findings[0].title if findings else "No critical findings"
        second_finding = findings[1].title if len(findings) > 1 else None
        top_suggestion = suggestions[0].title if suggestions else "No immediate recommendation"

        nav_items = int(signals.nav_item_count or 0)
        cta_count = int(signals.cta_above_fold_count or 0)
        hero_words = int(signals.hero_text_length or 0)
        above_fold_nodes = int(signals.above_fold_nodes or 0)

        benchmark_label = ""
        benchmark_similarity = 0
        if benchmark_match is not None:
            benchmark_label = str(getattr(benchmark_match, "label", "") or "")
            benchmark_similarity = int(getattr(benchmark_match, "similarity", 0) or 0)

        classifier_label = ""
        classifier_confidence = 0.0
        if design_pattern_classifier is not None:
            classifier_label = str(self._obj_get(design_pattern_classifier, "primary_pattern", "") or "")
            try:
                classifier_confidence = float(self._obj_get(design_pattern_classifier, "confidence", 0.0) or 0.0)
            except Exception:
                classifier_confidence = 0.0

        history_sentence = "No prior stored runs exist yet for this domain."
        if historical_benchmark.run_count > 0:
            history_sentence = (
                f"This domain has {historical_benchmark.run_count} stored run(s), with latest UX "
                f"{historical_benchmark.latest_ux_score} and average UX {historical_benchmark.average_ux_score}, "
                f"showing a '{historical_benchmark.trend}' trend."
            )

        confidence_sentence = ""
        if evaluation:
            confidence = self._obj_get(evaluation, "confidence", None)
            priority_issue = self._obj_get(evaluation, "priority_issue", "")
            priority_score = self._obj_get(evaluation, "priority_score", None)
            if confidence is not None:
                if priority_score is not None:
                    confidence_sentence = (
                        f" Evaluation confidence is {confidence}, and the main pressure point is "
                        f"'{priority_issue}' at {priority_score}/100 pressure."
                    )
                else:
                    confidence_sentence = (
                        f" Evaluation confidence is {confidence}, and the main pressure point is '{priority_issue}'."
                    )

        transformation_sentence = ""
        if redesign_transformation:
            deltas = self._obj_get(redesign_transformation, "deltas", {}) or {}
            focus_delta = deltas.get("attention_focus", 0)
            cta_delta = deltas.get("cta_visibility", 0)
            nav_delta = deltas.get("nav_items", 0)
            readability_delta = deltas.get("readability", 0)
            transformation_sentence = (
                f" Suggested transformation targets a nav delta of {nav_delta}, "
                f"attention focus improvement of {focus_delta}, CTA visibility improvement of {cta_delta}, "
                f"and readability improvement of {readability_delta}."
            )

        findings_sentence = f"The highest-priority issue is '{top_finding}'."
        if second_finding:
            findings_sentence += f" A secondary pressure point is '{second_finding}'."

        profile_name = "reference pattern"
        profile_similarity = 0
        if layout_similarity is not None:
            profile_name = str(layout_similarity.profile or archetype).lower()
            profile_similarity = int(layout_similarity.similarity or 0)

        structure_sentence = self._structure_interpretation(
            nav_items=nav_items,
            cta_count=cta_count,
            hero_words=hero_words,
            above_fold_nodes=above_fold_nodes,
        )

        benchmark_sentence = ""
        if benchmark_label:
            benchmark_sentence = (
                f" Retrieval matched the page most closely to '{benchmark_label}' at {benchmark_similarity}%."
            )

        classifier_sentence = ""
        if classifier_label:
            classifier_sentence = (
                f" The design pattern classifier labeled it as '{classifier_label}' with confidence {round(classifier_confidence, 3)}."
            )

        feedback_sentence = ""
        if feedback_summary is not None:
            total_events = int(self._obj_get(feedback_summary, "total_events", 0) or 0)
            accepted_suggestions = int(self._obj_get(feedback_summary, "accepted_suggestions", 0) or 0)
            rejected_suggestions = int(self._obj_get(feedback_summary, "rejected_suggestions", 0) or 0)
            if total_events > 0:
                feedback_sentence = (
                    f" Historical feedback exists for this domain, with {accepted_suggestions} accepted and "
                    f"{rejected_suggestions} rejected suggestion signals informing ranking."
                )
            else:
                feedback_sentence = " No historical user feedback has been recorded yet for this domain."

        return (
            f"This {archetype} page scored {scores.ux_score}/100 overall. "
            f"Attention focus is {scores.attention_focus}/100, CTA visibility is {scores.cta_visibility}/100, "
            f"readability is {scores.readability}/100, and cognitive load is {scores.cognitive_load}/100. "
            f"The page exposes {nav_items} nav items, {cta_count} CTA-like actions above the fold, "
            f"and about {hero_words} above-fold words. "
            f"{structure_sentence} "
            f"CLIP-style similarity aligned the page with {profile_name} at {profile_similarity}%. "
            f"{benchmark_sentence}"
            f"{classifier_sentence}"
            f" {findings_sentence} "
            f"The most important next step is '{top_suggestion}'. "
            f"{history_sentence}"
            f"{feedback_sentence}"
            f"{confidence_sentence}"
            f"{transformation_sentence}"
        ).strip()

    def _enhance_transformation_realism(
        self,
        *,
        redesign_transformation: Any,
        signals: ExtractedSignals,
        scores: ScoreBlock,
        suggestions: list[Suggestion],
    ) -> RedesignTransformation:
        raw = self._to_plain_data(redesign_transformation) or {}
        before = dict(raw.get("before") or {})
        after = dict(raw.get("after") or {})
        deltas = dict(raw.get("deltas") or {})

        before.setdefault("nav_items", int(signals.nav_item_count or 0))
        before.setdefault("hero_text_length", int(signals.hero_text_length or 0))
        before.setdefault("hero_words", int(before["hero_text_length"]))
        before.setdefault("cta_visibility", int(scores.cta_visibility))
        before.setdefault("attention_focus", int(scores.attention_focus))
        before.setdefault("readability", int(scores.readability))

        after.setdefault("nav_items", max(4, int(before["nav_items"]) - 2 if before["nav_items"] else 6))
        after.setdefault(
            "hero_text_length",
            max(18, int(before["hero_text_length"]) - 35 if before["hero_text_length"] else 60),
        )
        after.setdefault("hero_words", int(after["hero_text_length"]))
        after.setdefault("cta_visibility", min(98, int(before["cta_visibility"]) + 6))
        after.setdefault("attention_focus", min(98, int(before["attention_focus"]) + 5))
        after.setdefault("readability", min(99, int(before["readability"]) + 3))

        deltas["nav_items"] = int(after["nav_items"]) - int(before["nav_items"])
        deltas["hero_text_length"] = int(after["hero_text_length"]) - int(before["hero_text_length"])
        deltas["hero_words"] = int(deltas["hero_text_length"])
        deltas["cta_visibility"] = int(after["cta_visibility"]) - int(before["cta_visibility"])
        deltas["attention_focus"] = int(after["attention_focus"]) - int(before["attention_focus"])
        deltas["readability"] = int(after["readability"]) - int(before["readability"])

        assumptions = [
            "Assumes redesign keeps the same product, offer, and overall page purpose.",
            "Assumes primary changes are structural, not brand or copy-strategy overhauls.",
            "Assumes uplift estimates reflect directional improvements rather than measured live outcomes.",
        ]

        if suggestions:
            assumptions.append(f"Primary transformation is anchored to: {suggestions[0].title}.")

        realism_confidence = 0.76
        if abs(deltas["cta_visibility"]) <= 10 and abs(deltas["attention_focus"]) <= 10:
            realism_confidence += 0.08
        realism_confidence = min(0.95, realism_confidence)

        return RedesignTransformation(
            before=before,
            after=after,
            deltas=deltas,
            assumptions=assumptions,
            realism_confidence=round(realism_confidence, 3),
        )
    
    def _build_overlay_data(
        self,
        *,
        signals: ExtractedSignals,
        scores: ScoreBlock,
        redesign_transformation: RedesignTransformation,
    ) -> dict[str, Any]:
        before = self._to_plain_data(redesign_transformation.before) or {}
        after = self._to_plain_data(redesign_transformation.after) or {}
        deltas = self._to_plain_data(redesign_transformation.deltas) or {}
        assumptions = self._to_plain_data(redesign_transformation.assumptions) or []

        return {
            "summary": {
                "mode": "Concepts",
                "focus_delta": int(deltas.get("attention_focus", 0) or 0),
                "cta_delta": int(deltas.get("cta_visibility", 0) or 0),
                "nav_before": int(before.get("nav_items", signals.nav_item_count or 0) or 0),
                "nav_after": int(after.get("nav_items", signals.nav_item_count or 0) or 0),
                "nodes_before": int(signals.above_fold_nodes or 0),
                "nodes_after": max(0, int(signals.above_fold_nodes or 0) - 22),
                "realism": int(round(float(getattr(redesign_transformation, "realism_confidence", 0.76)) * 100)),
            },
            "assumptions": assumptions,
            "regions": [
                {
                    "id": "nav-density",
                    "label": "Navigation density",
                    "x": 6,
                    "y": 7,
                    "width": 88,
                    "height": 9,
                    "impact": "high" if int(signals.nav_item_count or 0) > 12 else "medium",
                },
                {
                    "id": "hero-focus",
                    "label": "Hero focus",
                    "x": 10,
                    "y": 18,
                    "width": 58,
                    "height": 22,
                    "impact": "high",
                },
                {
                    "id": "cta-path",
                    "label": "CTA path",
                    "x": 38,
                    "y": 56,
                    "width": 24,
                    "height": 12,
                    "impact": "medium",
                },
            ],
        }

    def _normalize_url(self, value: str) -> str:
        value = (value or "").strip()
        if not value:
            raise ValueError("URL is required")
        if not value.startswith(("http://", "https://")):
            value = f"https://{value}"
        return value

    def _clamp_score(self, value: float, low: float = 0, high: float = 100) -> float:
        return max(low, min(high, value))

    def _obj_get(self, value: Any, key: str, default: Any = None) -> Any:
        if value is None:
            return default
        if isinstance(value, dict):
            return value.get(key, default)
        return getattr(value, key, default)

    def _to_plain_data(self, value: Any) -> Any:
        if value is None:
            return None
        if hasattr(value, "model_dump"):
            try:
                return self._to_plain_data(value.model_dump(mode="json"))
            except TypeError:
                return self._to_plain_data(value.model_dump())
        if isinstance(value, dict):
            return {str(k): self._to_plain_data(v) for k, v in value.items()}
        if isinstance(value, (list, tuple)):
            return [self._to_plain_data(item) for item in value]
        return value

    def _coerce_mockup_status(self, value: Any) -> MockupStatus:
        if isinstance(value, MockupStatus):
            return value

        if isinstance(value, dict):
            return MockupStatus(
                available=bool(value.get("available", False)),
                enabled=bool(value.get("enabled", False)),
                mode=str(value.get("mode", "disabled") or "disabled"),
                ui_mode=str(value.get("ui_mode", "concepts") or "concepts"),
                reason=str(value.get("reason", "") or ""),
            )

        return MockupStatus(
            available=False,
            enabled=False,
            mode="disabled",
            ui_mode="concepts",
            reason="Mockup status unavailable.",
        )

    def _normalize_mockup_mode(self, status: MockupStatus) -> MockupStatus:
        raw_mode = (status.mode or "").strip().lower()
        ui_mode = "visual_previews" if status.available else "concepts"

        if raw_mode in {"gpu", "visual_previews", "visual-preview", "visual"} and status.available:
            normalized_mode = "visual_previews"
            ui_mode = "visual_previews"
        elif raw_mode in {"cpu", "cpu-disabled", "concepts", "concept", "disabled", "fallback", "cpu_disabled"}:
            normalized_mode = raw_mode or "concepts"
            ui_mode = "concepts"
        else:
            normalized_mode = "visual_previews" if status.available else "concepts"

        return MockupStatus(
            available=bool(status.available),
            enabled=bool(status.enabled),
            mode=normalized_mode,
            ui_mode=ui_mode,
            reason=str(status.reason or ""),
        )

    def _structure_interpretation(
        self,
        *,
        nav_items: int,
        cta_count: int,
        hero_words: int,
        above_fold_nodes: int,
    ) -> str:
        pressures: list[str] = []

        if nav_items > 12:
            pressures.append(f"header choice overload from {nav_items} nav items")
        if cta_count >= 4:
            pressures.append(f"action competition from {cta_count} CTA-like elements")
        if hero_words > 180:
            pressures.append(f"message heaviness from roughly {hero_words} hero words")
        if above_fold_nodes > 280:
            pressures.append(f"a dense scan field from about {above_fold_nodes} visible nodes")

        if not pressures:
            return "Structurally, the first screen is relatively controlled, with no single signal showing severe overload."

        if len(pressures) == 1:
            return f"Structurally, the main drag on clarity is {pressures[0]}."
        if len(pressures) == 2:
            return f"Structurally, the main drags on clarity are {pressures[0]} and {pressures[1]}."
        return (
            f"Structurally, the page is carrying several pressure points, including {pressures[0]}, "
            f"{pressures[1]}, and {pressures[2]}."
        )

    def _compare_driver_text(
        self,
        *,
        focus_edge: float,
        cta_edge: float,
        readability_edge: float,
        your_report: ReportResponse,
        competitor_report: ReportResponse,
    ) -> str:
        drivers = [
            (
                abs(focus_edge),
                f"attention focus ({your_report.scores.attention_focus} vs {competitor_report.scores.attention_focus})",
            ),
            (
                abs(cta_edge),
                f"CTA visibility ({your_report.scores.cta_visibility} vs {competitor_report.scores.cta_visibility})",
            ),
            (
                abs(readability_edge),
                f"readability ({your_report.scores.readability} vs {competitor_report.scores.readability})",
            ),
        ]
        drivers.sort(key=lambda item: item[0], reverse=True)
        return drivers[0][1]

    def _build_compare_reasoning(
        self,
        *,
        winner: str,
        winner_report: ReportResponse,
        loser_report: ReportResponse,
    ) -> str:
        winner_score = winner_report.scores.ux_score
        loser_score = loser_report.scores.ux_score

        focus_edge = winner_report.scores.attention_focus - loser_report.scores.attention_focus
        cta_edge = winner_report.scores.cta_visibility - loser_report.scores.cta_visibility
        readability_edge = winner_report.scores.readability - loser_report.scores.readability
        cognitive_edge = winner_report.scores.cognitive_load - loser_report.scores.cognitive_load

        strongest_driver = self._compare_driver_text(
            focus_edge=focus_edge,
            cta_edge=cta_edge,
            readability_edge=readability_edge,
            your_report=winner_report,
            competitor_report=loser_report,
        )

        winner_priority = self._obj_get(winner_report.evaluation, "priority_issue", "")
        loser_priority = self._obj_get(loser_report.evaluation, "priority_issue", "")

        winner_finding = winner_report.findings[0].title if winner_report.findings else "No major finding"
        loser_finding = loser_report.findings[0].title if loser_report.findings else "No major finding"

        winner_suggestion = winner_report.suggestions[0].title if winner_report.suggestions else "No major suggestion"
        loser_suggestion = loser_report.suggestions[0].title if loser_report.suggestions else "No major suggestion"

        benchmark_sentence = ""
        winner_benchmark = winner_report.benchmark_match
        loser_benchmark = loser_report.benchmark_match
        if winner_benchmark is not None and loser_benchmark is not None:
            benchmark_sentence = (
                f" The winning page mapped better to its reference benchmark "
                f"({winner_benchmark.label} at {winner_benchmark.similarity}% vs "
                f"{loser_benchmark.label} at {loser_benchmark.similarity}%)."
            )

        if winner == "your_page":
            prefix = f"Your page outperformed the competitor, {winner_score} to {loser_score}."
        else:
            prefix = f"The competitor outperformed your page, {winner_score} to {loser_score}."

        return (
            f"{prefix} "
            f"The clearest edge came from {strongest_driver}, while cognitive load also landed at "
            f"{winner_report.scores.cognitive_load} vs {loser_report.scores.cognitive_load}. "
            f"The stronger page's main pressure point was '{winner_priority or 'not strongly concentrated'}', "
            f"whereas the weaker page was held back most by '{loser_priority or 'broader structural weakness'}'. "
            f"Top finding comparison was '{winner_finding}' vs '{loser_finding}', and the next-step recommendations "
            f"were '{winner_suggestion}' vs '{loser_suggestion}'."
            f"{benchmark_sentence}"
        )


analysis_engine = AnalysisEngine()