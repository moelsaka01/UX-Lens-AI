from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from app.core.logging_setup import get_logger
from app.core.request_context import get_request_id, get_trace_id

logger = get_logger(__name__)


@dataclass
class StageTiming:
    label: str
    seconds: float


@dataclass
class RequestTrace:
    request_id: str
    trace_id: str
    input_url: str
    stages: dict[str, float] = field(default_factory=dict)
    started_at: float = field(default_factory=time.perf_counter)
    _markers: dict[str, float] = field(default_factory=dict)

    def start(self, label: str) -> None:
        self._markers[label] = time.perf_counter()

    def end(self, label: str) -> None:
        started = self._markers.get(label)
        if started is None:
            return
        self.stages[label] = round(time.perf_counter() - started, 4)

    def total_seconds(self) -> float:
        return round(time.perf_counter() - self.started_at, 4)

    def to_payload(self) -> dict[str, Any]:
        ordered = [
            {"label": key, "seconds": value}
            for key, value in self.stages.items()
        ]
        return {
            "request_id": self.request_id,
            "trace_id": self.trace_id,
            "input_url": self.input_url,
            "stages": ordered,
            "stage_map": dict(self.stages),
            "total_seconds": self.total_seconds(),
        }


class ObservabilityService:
    def new_trace(self, input_url: str) -> RequestTrace:
        return RequestTrace(
            request_id=get_request_id(),
            trace_id=get_trace_id(),
            input_url=input_url,
        )

    def log_trace(self, trace: RequestTrace) -> None:
        logger.info(
            "analysis_trace_completed",
            extra={
                "event": "analysis_trace_completed",
                "extra_data": trace.to_payload(),
            },
        )


observability_service = ObservabilityService()