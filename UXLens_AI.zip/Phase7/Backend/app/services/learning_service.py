from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from app.schemas import FeedbackSummary, RankingWeightSet
from app.services.storage_service import storage_service


WEIGHT_KEYS = [
    "ux_weight",
    "attention_focus_weight",
    "cta_visibility_weight",
    "readability_weight",
    "cognitive_load_weight",
    "novelty_weight",
    "confidence_weight",
    "business_alignment_weight",
    "evidence_strength_weight",
]


class LearningService:
    """Free/local learning layer built from explicit user feedback and stored A/B results.

    This is intentionally not a paid model-training dependency. It is a deterministic,
    explainable online-learning heuristic that can later be replaced by a real offline
    learner without changing the frontend contract.
    """

    def default_weights(self, *, version: str = "v1", source: str = "static") -> RankingWeightSet:
        return RankingWeightSet(
            version=version,
            source=source,  # type: ignore[arg-type]
            ux_weight=0.28,
            attention_focus_weight=0.22,
            cta_visibility_weight=0.22,
            readability_weight=0.10,
            cognitive_load_weight=0.10,
            novelty_weight=0.02,
            confidence_weight=0.03,
            business_alignment_weight=0.02,
            evidence_strength_weight=0.01,
            updated_at=datetime.now(UTC).isoformat(),
        )

    def get_weights(self, *, workspace_id: int | None = None, version: str = "v1") -> RankingWeightSet:
        stored = storage_service.get_ranking_weights(workspace_id=workspace_id, version=version)
        if stored is not None:
            return stored
        weights = self.default_weights(version=version)
        storage_service.upsert_ranking_weights(weights, workspace_id=workspace_id)
        return weights

    def status(self, *, workspace_id: int | None = None, domain: str | None = None) -> dict[str, Any]:
        feedback = storage_service.get_feedback_summary(workspace_id=workspace_id, domain=domain)
        weights = self.get_weights(workspace_id=workspace_id)
        ab_results = storage_service.list_ab_test_results(workspace_id=workspace_id, domain=domain, limit=200)
        coverage = self._coverage(feedback=feedback, ab_count=len(ab_results))

        return {
            "available": True,
            "mode": "local_explainable_online_learning",
            "requires_paid_services": False,
            "workspace_id": workspace_id,
            "domain": domain,
            "coverage": coverage,
            "can_learn_now": coverage["score"] > 0,
            "weights": weights.model_dump(),
            "feedback_summary": feedback.model_dump(),
            "ab_runs_recorded": len(ab_results),
            "notes": [
                "Uses local SQLite feedback and A/B scoring results.",
                "No login, paid API, subscription, or external training service is required.",
                "Weights become more useful as thumbs-up, thumbs-down, accepted, rejected, and preferred-variant events accumulate.",
            ],
        }

    def recommend_weights(
        self,
        *,
        workspace_id: int | None = None,
        domain: str | None = None,
        version: str = "v1",
    ) -> dict[str, Any]:
        current = self.get_weights(workspace_id=workspace_id, version=version)
        feedback = storage_service.get_feedback_summary(workspace_id=workspace_id, domain=domain)
        ab_results = storage_service.list_ab_test_results(workspace_id=workspace_id, domain=domain, limit=200)

        raw = current.model_dump()
        adjustments = {key: 0.0 for key in WEIGHT_KEYS}

        accepted = int(feedback.accepted_suggestions or 0)
        rejected = int(feedback.rejected_suggestions or 0)
        positive = int(feedback.positive_signals or 0)
        negative = int(feedback.negative_signals or 0)
        preferred = sum(int(v or 0) for v in (feedback.preferred_variants or {}).values())
        ab_count = len(ab_results)

        if accepted or positive:
            adjustments["business_alignment_weight"] += min(0.055, accepted * 0.006 + positive * 0.002)
            adjustments["confidence_weight"] += min(0.035, accepted * 0.003 + positive * 0.002)
            adjustments["evidence_strength_weight"] += min(0.025, accepted * 0.0025)

        if rejected or negative:
            adjustments["novelty_weight"] += min(0.035, rejected * 0.004 + negative * 0.002)
            adjustments["evidence_strength_weight"] += min(0.025, rejected * 0.002)
            adjustments["ux_weight"] += min(0.020, negative * 0.0015)

        if preferred:
            adjustments["business_alignment_weight"] += min(0.035, preferred * 0.004)
            adjustments["cta_visibility_weight"] += min(0.025, preferred * 0.002)

        if ab_count:
            adjustments["cta_visibility_weight"] += min(0.040, ab_count * 0.0015)
            adjustments["attention_focus_weight"] += min(0.035, ab_count * 0.0012)

        proposed = {key: max(0.0, float(raw.get(key, 0.0)) + adjustments[key]) for key in WEIGHT_KEYS}
        normalized = self._normalize(proposed)

        source = "hybrid" if (accepted + rejected + positive + negative + preferred + ab_count) > 0 else "static"
        weights = RankingWeightSet(
            version=version,
            source=source,  # type: ignore[arg-type]
            updated_at=datetime.now(UTC).isoformat(),
            **normalized,
        )

        return {
            "weights": weights.model_dump(),
            "current_weights": current.model_dump(),
            "adjustments": adjustments,
            "feedback_summary": feedback.model_dump(),
            "ab_runs_recorded": ab_count,
            "explanation": self._explain(feedback=feedback, ab_count=ab_count, source=source),
        }

    def learn(
        self,
        *,
        workspace_id: int | None = None,
        domain: str | None = None,
        version: str = "v1",
        persist: bool = True,
    ) -> dict[str, Any]:
        recommendation = self.recommend_weights(workspace_id=workspace_id, domain=domain, version=version)
        weights = RankingWeightSet.model_validate(recommendation["weights"])

        if persist:
            storage_service.upsert_ranking_weights(weights, workspace_id=workspace_id)

        return {
            "ok": True,
            "persisted": persist,
            "weights": weights.model_dump(),
            "diagnostics": {
                "current_weights": recommendation["current_weights"],
                "adjustments": recommendation["adjustments"],
                "feedback_summary": recommendation["feedback_summary"],
                "ab_runs_recorded": recommendation["ab_runs_recorded"],
                "explanation": recommendation["explanation"],
            },
        }

    def reset(self, *, workspace_id: int | None = None, version: str = "v1") -> dict[str, Any]:
        weights = self.default_weights(version=version, source="static")
        storage_service.upsert_ranking_weights(weights, workspace_id=workspace_id)
        return {"ok": True, "weights": weights.model_dump(), "message": "Ranking weights reset to default static profile."}

    def upsert_weights(
        self,
        *,
        raw_weights: dict[str, Any],
        workspace_id: int | None = None,
        version: str = "v1",
        source: str = "hybrid",
    ) -> RankingWeightSet:
        unknown = sorted(key for key in raw_weights if key not in WEIGHT_KEYS)
        if unknown:
            raise ValueError(f"Unsupported ranking weight keys: {', '.join(unknown)}")

        current = self.get_weights(workspace_id=workspace_id, version=version).model_dump()
        merged = {key: float(current.get(key, 0.0)) for key in WEIGHT_KEYS}

        for key, value in raw_weights.items():
            numeric = float(value)
            if numeric < 0:
                raise ValueError(f"Ranking weight '{key}' cannot be negative.")
            merged[key] = numeric

        normalized = self._normalize(merged)
        weights = RankingWeightSet(
            version=version,
            source=source if source in {"static", "learned", "hybrid"} else "hybrid",  # type: ignore[arg-type]
            updated_at=datetime.now(UTC).isoformat(),
            **normalized,
        )
        storage_service.upsert_ranking_weights(weights, workspace_id=workspace_id)
        return weights

    def _normalize(self, values: dict[str, float]) -> dict[str, float]:
        total = sum(max(0.0, float(values.get(key, 0.0))) for key in WEIGHT_KEYS)
        if total <= 0:
            values = self.default_weights().model_dump()
            total = sum(float(values[key]) for key in WEIGHT_KEYS)
        return {key: round(max(0.0, float(values.get(key, 0.0))) / total, 6) for key in WEIGHT_KEYS}

    def _coverage(self, *, feedback: FeedbackSummary, ab_count: int) -> dict[str, Any]:
        feedback_events = int(feedback.total_events or 0)
        signal_count = (
            feedback_events
            + int(feedback.accepted_suggestions or 0)
            + int(feedback.rejected_suggestions or 0)
            + sum(int(v or 0) for v in (feedback.preferred_variants or {}).values())
            + ab_count
        )
        score = round(min(1.0, signal_count / 25.0), 3)
        if score >= 0.75:
            label = "strong"
        elif score >= 0.35:
            label = "emerging"
        elif score > 0:
            label = "thin"
        else:
            label = "none"
        return {"score": score, "label": label, "signal_count": signal_count}

    def _explain(self, *, feedback: FeedbackSummary, ab_count: int, source: str) -> list[str]:
        notes = []
        if source == "static":
            notes.append("No learning signals exist yet, so the default static ranking profile is preserved.")
        if feedback.accepted_suggestions:
            notes.append(f"Accepted suggestions increased business-alignment and confidence weighting ({feedback.accepted_suggestions} accepted).")
        if feedback.rejected_suggestions:
            notes.append(f"Rejected suggestions increased novelty and evidence-sensitivity weighting ({feedback.rejected_suggestions} rejected).")
        if ab_count:
            notes.append(f"Stored A/B scoring runs increased CTA and attention-focus sensitivity ({ab_count} run(s)).")
        if not notes:
            notes.append("Learning pipeline is ready, but needs feedback events or A/B scoring records to adjust weights.")
        return notes

    def compute_adjustments(
        self,
        *,
        workspace_id: int | None = None,
        domain: str | None = None,
    ) -> dict[str, float]:
        recommendation = self.recommend_weights(
            workspace_id=workspace_id,
            domain=domain,
            version="v1",
        )
        return {
            key: float(value)
            for key, value in recommendation.get("adjustments", {}).items()
            if key in WEIGHT_KEYS
        }
    
learning_service = LearningService()
