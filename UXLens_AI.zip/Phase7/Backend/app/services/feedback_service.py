from __future__ import annotations

from urllib.parse import urlparse

from app.schemas import FeedbackSummary
from app.services.storage_service import storage_service


class FeedbackService:
    def _extract_domain(self, input_url: str) -> str:
        parsed = urlparse(str(input_url or "").strip())
        return (parsed.netloc or "").lower().strip()

    def build_feedback_summary(
        self,
        *,
        normalized_url: str,
        workspace_id: int | None,
    ) -> FeedbackSummary:
        domain = self._extract_domain(normalized_url)

        try:
            summary = storage_service.get_feedback_summary(
                workspace_id=workspace_id,
                domain=domain or None,
            )
            if summary is not None:
                return self._normalize_summary(summary)
        except Exception as exc:
            print(f"[WARN] Failed to load feedback summary for {normalized_url}: {exc}")

        return self._empty_summary()

    def feedback_signal_strength(
        self,
        *,
        summary: FeedbackSummary | None,
    ) -> float:
        if summary is None:
            return 0.0

        total_events = max(0, int(summary.total_events or 0))
        accepted = max(0, int(summary.accepted_suggestions or 0))
        rejected = max(0, int(summary.rejected_suggestions or 0))
        positive = max(0, int(summary.positive_signals or 0))
        negative = max(0, int(summary.negative_signals or 0))
        preferred_count = sum(int(v or 0) for v in (summary.preferred_variants or {}).values())

        if total_events <= 0:
            return 0.0

        raw_strength = (
            (accepted * 1.6)
            + (positive * 1.0)
            + (preferred_count * 1.2)
            - (rejected * 1.1)
            - (negative * 0.9)
        ) / max(1.0, total_events * 2.0)

        bounded = max(-1.0, min(1.0, raw_strength))
        return round(bounded, 4)

    def feedback_data_coverage(
        self,
        *,
        summary: FeedbackSummary | None,
    ) -> float:
        if summary is None:
            return 0.0

        total_events = max(0, int(summary.total_events or 0))
        accepted = max(0, int(summary.accepted_suggestions or 0))
        rejected = max(0, int(summary.rejected_suggestions or 0))
        preferred_count = sum(int(v or 0) for v in (summary.preferred_variants or {}).values())

        signal_count = total_events + accepted + rejected + preferred_count
        coverage = min(1.0, signal_count / 20.0)
        return round(coverage, 4)

    def _normalize_summary(self, summary: FeedbackSummary) -> FeedbackSummary:
        preferred_variants = {
            str(key): max(0, int(value or 0))
            for key, value in (summary.preferred_variants or {}).items()
            if str(key or "").strip()
        }

        top_positive_themes = [
            str(item).strip()
            for item in (summary.top_positive_themes or [])
            if str(item or "").strip()
        ][:5]

        top_negative_themes = [
            str(item).strip()
            for item in (summary.top_negative_themes or [])
            if str(item or "").strip()
        ][:5]

        return FeedbackSummary(
            total_events=max(0, int(summary.total_events or 0)),
            positive_signals=max(0, int(summary.positive_signals or 0)),
            negative_signals=max(0, int(summary.negative_signals or 0)),
            accepted_suggestions=max(0, int(summary.accepted_suggestions or 0)),
            rejected_suggestions=max(0, int(summary.rejected_suggestions or 0)),
            preferred_variants=preferred_variants,
            top_positive_themes=top_positive_themes,
            top_negative_themes=top_negative_themes,
        )

    def _empty_summary(self) -> FeedbackSummary:
        return FeedbackSummary(
            total_events=0,
            positive_signals=0,
            negative_signals=0,
            accepted_suggestions=0,
            rejected_suggestions=0,
            preferred_variants={},
            top_positive_themes=[],
            top_negative_themes=[],
        )


feedback_service = FeedbackService()