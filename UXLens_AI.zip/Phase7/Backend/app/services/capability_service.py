from __future__ import annotations

from app.schemas import CapabilityProfile, DesignPatternClassifierOutput, FeedbackSummary, MockupStatus


class CapabilityService:
    def build_capability_profile(
        self,
        *,
        mockup_status: MockupStatus,
        design_pattern_classifier: DesignPatternClassifierOutput | None,
        feedback_summary: FeedbackSummary | None,
    ) -> CapabilityProfile:
        notes: list[str] = []

        redesign_ui_mode = (
            mockup_status.ui_mode
            if mockup_status.ui_mode in {"concepts", "visual_previews"}
            else ("visual_previews" if mockup_status.available else "concepts")
        )

        if redesign_ui_mode == "visual_previews" and mockup_status.available:
            notes.append("Visual preview mode is available for redesign rendering.")
        else:
            notes.append("Visual mockups are unavailable, redesign UI should prefer concept mode.")

        classifier_available = bool(
            design_pattern_classifier and str(design_pattern_classifier.primary_pattern or "").strip()
        )
        if classifier_available:
            notes.append(
                f"Design pattern classification is available through "
                f"{design_pattern_classifier.model_name or 'the configured classifier'}."
            )
        else:
            notes.append("Design pattern classification fell back to archetype-level inference.")

        feedback_events = int(feedback_summary.total_events or 0) if feedback_summary else 0
        accepted_suggestions = int(feedback_summary.accepted_suggestions or 0) if feedback_summary else 0
        rejected_suggestions = int(feedback_summary.rejected_suggestions or 0) if feedback_summary else 0

        feedback_available = feedback_summary is not None
        learning_ranker_available = True
        ab_scoring_available = True

        if feedback_available and feedback_events > 0:
            notes.append(
                f"Feedback loop is active with {feedback_events} recorded event(s), "
                f"{accepted_suggestions} accepted suggestion signal(s), and "
                f"{rejected_suggestions} rejected suggestion signal(s)."
            )
        else:
            notes.append("Feedback loop is active, but no historical feedback has been recorded yet.")

        if feedback_available and feedback_events > 0:
            notes.append("Ranking diagnostics can use stored feedback context and learned or hybrid weights.")
        else:
            notes.append("Ranking diagnostics are available, but the system is currently operating mostly on static weights.")

        if feedback_available and accepted_suggestions + rejected_suggestions > 0:
            notes.append("A/B redesign scoring can be interpreted alongside real feedback preferences.")
        else:
            notes.append("A/B redesign scoring is available with heuristic or hybrid prediction support.")

        return CapabilityProfile(
            redesign_ui_mode=redesign_ui_mode,  # type: ignore[arg-type]
            mockups_available=bool(mockup_status.available),
            design_pattern_classifier_available=classifier_available,
            learning_ranker_available=learning_ranker_available,
            feedback_loop_available=True,
            ab_scoring_available=ab_scoring_available,
            notes=notes,
        )


capability_service = CapabilityService()