from __future__ import annotations

from io import BytesIO
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Image as RLImage
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from app.config import settings
from app.schemas import ReportResponse


class ReportService:
    def build_pdf(self, report: ReportResponse, screenshot_dir: Path) -> bytes:
        buffer = BytesIO()

        doc = SimpleDocTemplate(
            buffer,
            pagesize=A4,
            leftMargin=1.2 * cm,
            rightMargin=1.2 * cm,
            topMargin=1.2 * cm,
            bottomMargin=1.2 * cm,
        )

        styles = getSampleStyleSheet()

        title_style = ParagraphStyle(
            "TitleBrand",
            parent=styles["Heading1"],
            fontSize=22,
            leading=26,
            textColor=colors.HexColor("#3B82F6"),
            spaceAfter=8,
        )

        section_style = ParagraphStyle(
            "SectionBrand",
            parent=styles["Heading2"],
            textColor=colors.HexColor("#8B5CF6"),
            spaceBefore=10,
            spaceAfter=6,
        )

        story = []

        story.append(Paragraph(settings.branded_company_name, title_style))
        story.append(Paragraph(settings.branded_tagline, styles["BodyText"]))
        story.append(Spacer(1, 10))

        story.append(
            Paragraph(
                f"<b>URL:</b> {report.input_url}<br/><b>Type:</b> {report.detected_type}<br/><b>Generated:</b> {report.generated_at}",
                styles["BodyText"],
            )
        )
        story.append(Spacer(1, 10))

        # Screenshot
        if report.screenshots.desktop:
            img_path = screenshot_dir / Path(report.screenshots.desktop).name
            if img_path.exists():
                story.append(RLImage(str(img_path), width=17 * cm, height=10 * cm))
                story.append(Spacer(1, 8))

        # Scores
        score_table = Table([
            ["UX", "Focus", "CTA", "Readability", "Cognitive"],
            [
                report.scores.ux_score,
                report.scores.attention_focus,
                report.scores.cta_visibility,
                report.scores.readability,
                report.scores.cognitive_load,
            ],
        ])

        score_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#3B82F6")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
        ]))

        story.append(Paragraph("Scorecard", section_style))
        story.append(score_table)
        story.append(Spacer(1, 10))

        # Summary
        story.append(Paragraph("Executive Summary", section_style))
        story.append(Paragraph(report.ai_summary, styles["BodyText"]))
        story.append(Spacer(1, 8))

        # Findings
        story.append(Paragraph("Findings", section_style))
        for f in report.findings:
            story.append(Paragraph(f"<b>{f.title}</b> ({f.severity}) - {f.description}", styles["BodyText"]))
            story.append(Spacer(1, 4))

        # Suggestions
        story.append(Paragraph("Suggestions", section_style))
        for s in report.suggestions:
            story.append(Paragraph(f"<b>{s.title}</b> ({s.impact}) - {s.description}", styles["BodyText"]))
            story.append(Spacer(1, 4))

        # Redesign Suggestions (NEW)
        if hasattr(report, "redesign_suggestions"):
            story.append(Paragraph("Redesign Directions", section_style))
            for r in report.redesign_suggestions:
                story.append(
                    Paragraph(
                        f"<b>{r.title}</b> - {r.proposed}",
                        styles["BodyText"],
                    )
                )
                story.append(Spacer(1, 4))

        doc.build(story)

        return buffer.getvalue()


report_service = ReportService()