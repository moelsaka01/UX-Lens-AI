from __future__ import annotations

import json
import sqlite3
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse

from app.config import settings
from app.schemas import (
    FeedbackSummary,
    HistoryItem,
    RankingWeightSet,
    ReportResponse,
    UserFeedbackEvent,
    WatchlistItem,
    Workspace,
    WorkspaceMember,
)


class StorageService:
    def __init__(self) -> None:
        self.db_path = Path(settings.base_dir) / "app.db"
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON;")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    email TEXT NOT NULL UNIQUE,
                    password_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS workspaces (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    brand_name TEXT NOT NULL,
                    primary_color TEXT NOT NULL,
                    secondary_color TEXT NOT NULL,
                    logo_text TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS workspace_members (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    workspace_id INTEGER NOT NULL,
                    user_id INTEGER NOT NULL,
                    role TEXT NOT NULL,
                    UNIQUE(workspace_id, user_id)
                );

                CREATE TABLE IF NOT EXISTS reports (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    trace_id TEXT,
                    input_url TEXT NOT NULL,
                    domain TEXT NOT NULL DEFAULT '',
                    detected_type TEXT NOT NULL,
                    ux_score INTEGER NOT NULL,
                    generated_at TEXT NOT NULL,
                    workspace_id INTEGER,
                    payload TEXT NOT NULL,
                    payload_bytes INTEGER NOT NULL DEFAULT 0,
                    findings_count INTEGER NOT NULL DEFAULT 0,
                    suggestions_count INTEGER NOT NULL DEFAULT 0,
                    benchmark_label TEXT,
                    benchmark_similarity INTEGER,
                    evaluation_confidence REAL,
                    total_analysis_seconds REAL,
                    design_pattern_label TEXT DEFAULT '',
                    design_pattern_family TEXT DEFAULT '',
                    design_pattern_confidence REAL,
                    redesign_ui_mode TEXT DEFAULT 'concepts',
                    ab_winner_variant_id TEXT DEFAULT '',
                    ab_primary_metric TEXT DEFAULT '',
                    ab_summary TEXT DEFAULT ''
                );

                CREATE INDEX IF NOT EXISTS idx_reports_domain ON reports(domain);
                CREATE INDEX IF NOT EXISTS idx_reports_trace_id ON reports(trace_id);
                CREATE INDEX IF NOT EXISTS idx_reports_generated_at ON reports(generated_at);

                CREATE TABLE IF NOT EXISTS analysis_traces (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    trace_id TEXT NOT NULL UNIQUE,
                    input_url TEXT NOT NULL,
                    domain TEXT NOT NULL DEFAULT '',
                    workspace_id INTEGER,
                    generated_at TEXT NOT NULL,
                    total_analysis_seconds REAL NOT NULL DEFAULT 0,
                    screenshot_and_extraction_seconds REAL NOT NULL DEFAULT 0,
                    scoring_and_rules_seconds REAL NOT NULL DEFAULT 0,
                    clip_similarity_seconds REAL NOT NULL DEFAULT 0,
                    benchmark_retrieval_seconds REAL NOT NULL DEFAULT 0,
                    visual_analysis_seconds REAL NOT NULL DEFAULT 0,
                    evaluation_and_redesign_seconds REAL NOT NULL DEFAULT 0,
                    payload_bytes INTEGER NOT NULL DEFAULT 0,
                    findings_count INTEGER NOT NULL DEFAULT 0,
                    suggestions_count INTEGER NOT NULL DEFAULT 0,
                    mockups_count INTEGER NOT NULL DEFAULT 0,
                    evaluation_confidence REAL,
                    priority_issue TEXT DEFAULT '',
                    benchmark_label TEXT DEFAULT '',
                    benchmark_similarity INTEGER NOT NULL DEFAULT 0,
                    design_pattern_label TEXT DEFAULT '',
                    design_pattern_family TEXT DEFAULT '',
                    design_pattern_confidence REAL,
                    redesign_ui_mode TEXT DEFAULT 'concepts',
                    raw_steps_json TEXT NOT NULL DEFAULT '{}',
                    payload_json TEXT NOT NULL DEFAULT '{}'
                );

                CREATE INDEX IF NOT EXISTS idx_analysis_traces_domain ON analysis_traces(domain);
                CREATE INDEX IF NOT EXISTS idx_analysis_traces_generated_at ON analysis_traces(generated_at);

                CREATE TABLE IF NOT EXISTS watchlists (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    url TEXT NOT NULL,
                    notes TEXT NOT NULL DEFAULT '',
                    created_at TEXT NOT NULL,
                    workspace_id INTEGER,
                    last_report_id INTEGER,
                    last_score INTEGER
                );

                CREATE TABLE IF NOT EXISTS ranking_weights (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    workspace_id INTEGER,
                    version TEXT NOT NULL DEFAULT 'v1',
                    source TEXT NOT NULL DEFAULT 'static',
                    ux_weight REAL NOT NULL DEFAULT 0.0,
                    attention_focus_weight REAL NOT NULL DEFAULT 0.0,
                    cta_visibility_weight REAL NOT NULL DEFAULT 0.0,
                    readability_weight REAL NOT NULL DEFAULT 0.0,
                    cognitive_load_weight REAL NOT NULL DEFAULT 0.0,
                    novelty_weight REAL NOT NULL DEFAULT 0.0,
                    confidence_weight REAL NOT NULL DEFAULT 0.0,
                    business_alignment_weight REAL NOT NULL DEFAULT 0.0,
                    evidence_strength_weight REAL NOT NULL DEFAULT 0.0,
                    updated_at TEXT NOT NULL,
                    UNIQUE(workspace_id, version)
                );

                CREATE INDEX IF NOT EXISTS idx_ranking_weights_workspace_version
                ON ranking_weights(workspace_id, version);

                CREATE TABLE IF NOT EXISTS feedback_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    feedback_id TEXT NOT NULL UNIQUE,
                    workspace_id INTEGER,
                    report_id TEXT,
                    input_url TEXT DEFAULT '',
                    domain TEXT DEFAULT '',
                    user_id TEXT,
                    created_at TEXT NOT NULL,
                    free_text TEXT DEFAULT '',
                    payload_json TEXT NOT NULL DEFAULT '{}'
                );

                CREATE INDEX IF NOT EXISTS idx_feedback_events_workspace_id ON feedback_events(workspace_id);
                CREATE INDEX IF NOT EXISTS idx_feedback_events_domain ON feedback_events(domain);
                CREATE INDEX IF NOT EXISTS idx_feedback_events_created_at ON feedback_events(created_at);

                CREATE TABLE IF NOT EXISTS feedback_labels (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    feedback_id TEXT NOT NULL,
                    workspace_id INTEGER,
                    report_id TEXT,
                    target_id TEXT NOT NULL DEFAULT '',
                    target_type TEXT NOT NULL DEFAULT 'suggestion',
                    verdict TEXT NOT NULL DEFAULT 'neutral',
                    score REAL,
                    reason TEXT DEFAULT '',
                    metadata_json TEXT NOT NULL DEFAULT '{}',
                    created_at TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_feedback_labels_feedback_id ON feedback_labels(feedback_id);
                CREATE INDEX IF NOT EXISTS idx_feedback_labels_target_id ON feedback_labels(target_id);
                CREATE INDEX IF NOT EXISTS idx_feedback_labels_verdict ON feedback_labels(verdict);

                CREATE TABLE IF NOT EXISTS ab_test_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    trace_id TEXT,
                    workspace_id INTEGER,
                    report_id TEXT,
                    input_url TEXT DEFAULT '',
                    domain TEXT DEFAULT '',
                    generated_at TEXT NOT NULL,
                    scoring_type TEXT NOT NULL DEFAULT 'heuristic',
                    baseline_variant_id TEXT DEFAULT '',
                    winner_variant_id TEXT DEFAULT '',
                    primary_metric TEXT DEFAULT '',
                    summary TEXT DEFAULT '',
                    variants_json TEXT NOT NULL DEFAULT '[]'
                );

                CREATE INDEX IF NOT EXISTS idx_ab_test_results_domain ON ab_test_results(domain);
                CREATE INDEX IF NOT EXISTS idx_ab_test_results_workspace_id ON ab_test_results(workspace_id);
                """
            )
            conn.commit()

    def _extract_domain(self, input_url: str) -> str:
        raw = str(input_url or "").strip()
        if not raw:
            return ""

        parsed = urlparse(raw if raw.startswith(("http://", "https://")) else f"https://{raw}")
        domain = (parsed.netloc or parsed.path or "").lower().strip()
        return domain.removeprefix("www.")

    def _normalize_domain(self, domain: str | None) -> str:
        return str(domain or "").lower().strip().removeprefix("www.")

    def _payload_bytes(self, payload: str) -> int:
        return len(payload.encode("utf-8"))

    def _to_plain_data(self, value: Any) -> Any:
        if value is None:
            return None

        if hasattr(value, "model_dump"):
            try:
                return self._to_plain_data(value.model_dump(mode="json"))
            except TypeError:
                return self._to_plain_data(value.model_dump())

        if isinstance(value, dict):
            return {str(k): self._to_plain_data(v) for k, v in value.items()}

        if isinstance(value, (list, tuple)):
            return [self._to_plain_data(item) for item in value]

        return value

    def _json_string(self, value: Any) -> str:
        return json.dumps(self._to_plain_data(value), ensure_ascii=False)

    def _safe_pipeline_steps(self, report: ReportResponse) -> dict[str, float]:
        pipeline_metrics = report.pipeline_metrics
        if pipeline_metrics is None:
            return {}

        if isinstance(pipeline_metrics, dict):
            normalized: dict[str, float] = {}
            for key, value in pipeline_metrics.items():
                try:
                    normalized[str(key)] = float(value)
                except Exception:
                    continue
            return normalized

        if hasattr(pipeline_metrics, "steps"):
            steps = getattr(pipeline_metrics, "steps", {}) or {}
            normalized: dict[str, float] = {}
            for key, value in steps.items():
                try:
                    normalized[str(key)] = float(value)
                except Exception:
                    continue
            return normalized

        return {}

    def _safe_evaluation_confidence(self, report: ReportResponse) -> float | None:
        evaluation = report.evaluation
        if evaluation is None:
            return None

        if isinstance(evaluation, dict):
            value = evaluation.get("confidence")
        else:
            value = getattr(evaluation, "confidence", None)

        try:
            return float(value) if value is not None else None
        except Exception:
            return None

    def _safe_priority_issue(self, report: ReportResponse) -> str:
        evaluation = report.evaluation
        if evaluation is None:
            return ""

        if isinstance(evaluation, dict):
            value = evaluation.get("priority_issue", "")
        else:
            value = getattr(evaluation, "priority_issue", "")

        return str(value or "")

    def _safe_benchmark_label(self, report: ReportResponse) -> str:
        match = report.benchmark_match
        if match is None:
            return ""
        return str(getattr(match, "label", "") or "")

    def _safe_benchmark_similarity(self, report: ReportResponse) -> int:
        match = report.benchmark_match
        if match is None:
            return 0
        try:
            return int(getattr(match, "similarity", 0) or 0)
        except Exception:
            return 0

    def _safe_design_pattern_label(self, report: ReportResponse) -> str:
        classifier = report.design_pattern_classifier
        if classifier is None:
            return ""
        if isinstance(classifier, dict):
            return str(classifier.get("primary_pattern", "") or "")
        return str(getattr(classifier, "primary_pattern", "") or "")

    def _safe_design_pattern_family(self, report: ReportResponse) -> str:
        classifier = report.design_pattern_classifier
        if classifier is None:
            return ""
        if isinstance(classifier, dict):
            return str(classifier.get("primary_family", "") or "")
        return str(getattr(classifier, "primary_family", "") or "")

    def _safe_design_pattern_confidence(self, report: ReportResponse) -> float | None:
        classifier = report.design_pattern_classifier
        if classifier is None:
            return None
        try:
            if isinstance(classifier, dict):
                value = classifier.get("confidence")
            else:
                value = getattr(classifier, "confidence", None)
            return float(value) if value is not None else None
        except Exception:
            return None

    def _safe_redesign_ui_mode(self, report: ReportResponse) -> str:
        status = report.mockup_status
        if status is None:
            return "concepts"
        if isinstance(status, dict):
            return str(status.get("ui_mode", "concepts") or "concepts")
        return str(getattr(status, "ui_mode", "concepts") or "concepts")

    def _safe_ab_winner_variant_id(self, report: ReportResponse) -> str:
        ab_data = report.ab_test_scoring
        if ab_data is None:
            return ""
        if isinstance(ab_data, dict):
            return str(ab_data.get("winner_variant_id", "") or "")
        return str(getattr(ab_data, "winner_variant_id", "") or "")

    def _safe_ab_primary_metric(self, report: ReportResponse) -> str:
        ab_data = report.ab_test_scoring
        if ab_data is None:
            return ""
        if isinstance(ab_data, dict):
            return str(ab_data.get("primary_metric", "") or "")
        return str(getattr(ab_data, "primary_metric", "") or "")

    def _safe_ab_summary(self, report: ReportResponse) -> str:
        ab_data = report.ab_test_scoring
        if ab_data is None:
            return ""
        if isinstance(ab_data, dict):
            return str(ab_data.get("summary", "") or "")
        return str(getattr(ab_data, "summary", "") or "")

    def create_user(self, name: str, email: str, password_hash: str) -> int:
        created_at = datetime.now(UTC).isoformat()
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO users (name, email, password_hash, created_at) VALUES (?, ?, ?, ?)",
                (name, email.lower().strip(), password_hash, created_at),
            )
            conn.commit()
            return int(cur.lastrowid)

    def get_user_by_email(self, email: str):
        with self._connect() as conn:
            return conn.execute(
                "SELECT * FROM users WHERE email = ?",
                (email.lower().strip(),),
            ).fetchone()

    def get_user_by_id(self, user_id: int):
        with self._connect() as conn:
            return conn.execute(
                "SELECT * FROM users WHERE id = ?",
                (user_id,),
            ).fetchone()

    def create_workspace(
        self,
        owner_user_id: int,
        name: str,
        brand_name: str,
        primary_color: str,
        secondary_color: str,
        logo_text: str,
    ) -> Workspace:
        created_at = datetime.now(UTC).isoformat()
        brand_name = brand_name or name

        with self._connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO workspaces (name, brand_name, primary_color, secondary_color, logo_text, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (name, brand_name, primary_color, secondary_color, logo_text, created_at),
            )
            workspace_id = int(cur.lastrowid)
            conn.execute(
                "INSERT INTO workspace_members (workspace_id, user_id, role) VALUES (?, ?, ?)",
                (workspace_id, owner_user_id, "owner"),
            )
            conn.commit()

        return Workspace(
            id=workspace_id,
            name=name,
            brand_name=brand_name,
            primary_color=primary_color,
            secondary_color=secondary_color,
            logo_text=logo_text,
            created_at=created_at,
        )

    def list_workspaces_for_user(self, user_id: int) -> list[Workspace]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT w.*
                FROM workspaces w
                JOIN workspace_members wm ON wm.workspace_id = w.id
                WHERE wm.user_id = ?
                ORDER BY w.id DESC
                """,
                (user_id,),
            ).fetchall()

        return [
            Workspace(
                id=int(r["id"]),
                name=str(r["name"]),
                brand_name=str(r["brand_name"]),
                primary_color=str(r["primary_color"]),
                secondary_color=str(r["secondary_color"]),
                logo_text=str(r["logo_text"]),
                created_at=str(r["created_at"]),
            )
            for r in rows
        ]

    def list_members(self, workspace_id: int) -> list[WorkspaceMember]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT wm.id, wm.workspace_id, wm.user_id, wm.role, u.name, u.email
                FROM workspace_members wm
                JOIN users u ON u.id = wm.user_id
                WHERE wm.workspace_id = ?
                ORDER BY wm.id ASC
                """,
                (workspace_id,),
            ).fetchall()

        return [
            WorkspaceMember(
                id=int(r["id"]),
                workspace_id=int(r["workspace_id"]),
                user_id=int(r["user_id"]),
                role=str(r["role"]),
                name=str(r["name"]),
                email=str(r["email"]),
            )
            for r in rows
        ]

    def add_member_by_email(
        self,
        workspace_id: int,
        email: str,
        role: str = "member",
    ) -> WorkspaceMember | None:
        user = self.get_user_by_email(email)
        if user is None:
            return None

        with self._connect() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO workspace_members (workspace_id, user_id, role) VALUES (?, ?, ?)",
                (workspace_id, int(user["id"]), role),
            )
            conn.commit()

        members = self.list_members(workspace_id)
        return next((m for m in members if m.user_id == int(user["id"])), None)

    def save_report(self, report: ReportResponse) -> int:
        payload = self._json_string(report)
        domain = self._extract_domain(report.input_url)
        payload_bytes = self._payload_bytes(payload)
        findings_count = len(report.findings or [])
        suggestions_count = len(report.suggestions or [])
        benchmark_label = self._safe_benchmark_label(report)
        benchmark_similarity = self._safe_benchmark_similarity(report)
        evaluation_confidence = self._safe_evaluation_confidence(report)
        steps = self._safe_pipeline_steps(report)
        total_analysis_seconds = float(steps.get("total_analysis", 0.0))

        design_pattern_label = self._safe_design_pattern_label(report)
        design_pattern_family = self._safe_design_pattern_family(report)
        design_pattern_confidence = self._safe_design_pattern_confidence(report)
        redesign_ui_mode = self._safe_redesign_ui_mode(report)
        ab_winner_variant_id = self._safe_ab_winner_variant_id(report)
        ab_primary_metric = self._safe_ab_primary_metric(report)
        ab_summary = self._safe_ab_summary(report)

        with self._connect() as conn:
            try:
                conn.execute("BEGIN")

                cur = conn.execute(
                    """
                    INSERT INTO reports (
                        trace_id,
                        input_url,
                        domain,
                        detected_type,
                        ux_score,
                        generated_at,
                        workspace_id,
                        payload,
                        payload_bytes,
                        findings_count,
                        suggestions_count,
                        benchmark_label,
                        benchmark_similarity,
                        evaluation_confidence,
                        total_analysis_seconds,
                        design_pattern_label,
                        design_pattern_family,
                        design_pattern_confidence,
                        redesign_ui_mode,
                        ab_winner_variant_id,
                        ab_primary_metric,
                        ab_summary
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        getattr(report, "trace_id", None),
                        report.input_url,
                        domain,
                        report.detected_type,
                        report.scores.ux_score,
                        report.generated_at,
                        report.workspace_id,
                        payload,
                        payload_bytes,
                        findings_count,
                        suggestions_count,
                        benchmark_label,
                        benchmark_similarity,
                        evaluation_confidence,
                        total_analysis_seconds,
                        design_pattern_label,
                        design_pattern_family,
                        design_pattern_confidence,
                        redesign_ui_mode,
                        ab_winner_variant_id,
                        ab_primary_metric,
                        ab_summary,
                    ),
                )
                report_id = int(cur.lastrowid)

                if getattr(report, "trace_id", None):
                    conn.execute(
                        """
                        INSERT OR REPLACE INTO analysis_traces (
                            trace_id,
                            input_url,
                            domain,
                            workspace_id,
                            generated_at,
                            total_analysis_seconds,
                            screenshot_and_extraction_seconds,
                            scoring_and_rules_seconds,
                            clip_similarity_seconds,
                            benchmark_retrieval_seconds,
                            visual_analysis_seconds,
                            evaluation_and_redesign_seconds,
                            payload_bytes,
                            findings_count,
                            suggestions_count,
                            mockups_count,
                            evaluation_confidence,
                            priority_issue,
                            benchmark_label,
                            benchmark_similarity,
                            design_pattern_label,
                            design_pattern_family,
                            design_pattern_confidence,
                            redesign_ui_mode,
                            raw_steps_json,
                            payload_json
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            getattr(report, "trace_id", None),
                            report.input_url,
                            domain,
                            report.workspace_id,
                            report.generated_at,
                            float(steps.get("total_analysis", 0.0)),
                            float(steps.get("screenshot_and_extraction", 0.0)),
                            float(steps.get("scoring_and_rules", 0.0)),
                            float(steps.get("clip_similarity", 0.0)),
                            float(steps.get("benchmark_retrieval", 0.0)),
                            float(steps.get("visual_analysis", 0.0)),
                            float(steps.get("evaluation_and_redesign", 0.0)),
                            payload_bytes,
                            findings_count,
                            suggestions_count,
                            len(report.redesign_mockups or []),
                            evaluation_confidence,
                            self._safe_priority_issue(report),
                            benchmark_label,
                            benchmark_similarity,
                            design_pattern_label,
                            design_pattern_family,
                            design_pattern_confidence,
                            redesign_ui_mode,
                            self._json_string(steps),
                            payload,
                        ),
                    )

                ab_data = report.ab_test_scoring
                if ab_data:
                    if isinstance(ab_data, dict):
                        variants = ab_data.get("variants", [])
                        scoring_type = str(ab_data.get("scoring_type", "heuristic") or "heuristic")
                        baseline_variant_id = str(ab_data.get("baseline_variant_id", "") or "")
                        winner_variant_id = str(ab_data.get("winner_variant_id", "") or "")
                        primary_metric = str(ab_data.get("primary_metric", "") or "")
                        summary = str(ab_data.get("summary", "") or "")
                    else:
                        variants = getattr(ab_data, "variants", []) or []
                        scoring_type = str(getattr(ab_data, "scoring_type", "heuristic") or "heuristic")
                        baseline_variant_id = str(getattr(ab_data, "baseline_variant_id", "") or "")
                        winner_variant_id = str(getattr(ab_data, "winner_variant_id", "") or "")
                        primary_metric = str(getattr(ab_data, "primary_metric", "") or "")
                        summary = str(getattr(ab_data, "summary", "") or "")

                    conn.execute(
                        """
                        INSERT INTO ab_test_results (
                            trace_id,
                            workspace_id,
                            report_id,
                            input_url,
                            domain,
                            generated_at,
                            scoring_type,
                            baseline_variant_id,
                            winner_variant_id,
                            primary_metric,
                            summary,
                            variants_json
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            getattr(report, "trace_id", None),
                            report.workspace_id,
                            str(report_id),
                            report.input_url,
                            domain,
                            report.generated_at,
                            scoring_type,
                            baseline_variant_id,
                            winner_variant_id,
                            primary_metric,
                            summary,
                            self._json_string(variants),
                        ),
                    )

                conn.commit()
                return report_id
            except Exception:
                conn.rollback()
                raise

    def create_report(self, report: ReportResponse) -> int:
        return self.save_report(report)

    def save_observability_record(
        self,
        *,
        trace_id: str,
        input_url: str,
        workspace_id: int | None = None,
        payload: dict[str, Any],
    ) -> None:
        domain = self._extract_domain(input_url)
        generated_at = datetime.now(UTC).isoformat()

        normalized_payload = self._to_plain_data(payload)
        pipeline_metrics = normalized_payload.get("pipeline_metrics", {}) or {}
        raw_payload = self._json_string(normalized_payload)

        def as_float(key: str) -> float:
            try:
                return float(pipeline_metrics.get(key, 0.0) or 0.0)
            except Exception:
                return 0.0

        observability = normalized_payload.get("observability", {}) or {}

        priority_issue = str(observability.get("priority_issue", "") or "")

        try:
            evaluation_confidence = (
                float(observability.get("evaluation_confidence"))
                if observability.get("evaluation_confidence") is not None
                else None
            )
        except Exception:
            evaluation_confidence = None

        try:
            benchmark_label = str(observability.get("benchmark_label", "") or "")
        except Exception:
            benchmark_label = ""

        try:
            benchmark_similarity = int(observability.get("benchmark_similarity", 0) or 0)
        except Exception:
            benchmark_similarity = 0

        try:
            findings_count = int(observability.get("findings_count", 0) or 0)
        except Exception:
            findings_count = 0

        try:
            suggestions_count = int(observability.get("suggestions_count", 0) or 0)
        except Exception:
            suggestions_count = 0

        try:
            mockups_count = int(observability.get("mockups_count", 0) or 0)
        except Exception:
            mockups_count = 0

        design_pattern_classifier = normalized_payload.get("design_pattern_classifier", {}) or {}
        capability_profile = normalized_payload.get("capability_profile", {}) or {}

        try:
            design_pattern_label = str(design_pattern_classifier.get("primary_pattern", "") or "")
        except Exception:
            design_pattern_label = ""

        try:
            design_pattern_family = str(design_pattern_classifier.get("primary_family", "") or "")
        except Exception:
            design_pattern_family = ""

        try:
            design_pattern_confidence = (
                float(design_pattern_classifier.get("confidence"))
                if design_pattern_classifier.get("confidence") is not None
                else None
            )
        except Exception:
            design_pattern_confidence = None

        redesign_ui_mode = str(capability_profile.get("redesign_ui_mode", "concepts") or "concepts")
        payload_bytes = self._payload_bytes(raw_payload)

        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO analysis_traces (
                    trace_id,
                    input_url,
                    domain,
                    workspace_id,
                    generated_at,
                    total_analysis_seconds,
                    screenshot_and_extraction_seconds,
                    scoring_and_rules_seconds,
                    clip_similarity_seconds,
                    benchmark_retrieval_seconds,
                    visual_analysis_seconds,
                    evaluation_and_redesign_seconds,
                    payload_bytes,
                    findings_count,
                    suggestions_count,
                    mockups_count,
                    evaluation_confidence,
                    priority_issue,
                    benchmark_label,
                    benchmark_similarity,
                    design_pattern_label,
                    design_pattern_family,
                    design_pattern_confidence,
                    redesign_ui_mode,
                    raw_steps_json,
                    payload_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    trace_id,
                    input_url,
                    domain,
                    workspace_id,
                    generated_at,
                    as_float("total_analysis"),
                    as_float("screenshot_and_extraction"),
                    as_float("scoring_and_rules"),
                    as_float("clip_similarity"),
                    as_float("benchmark_retrieval"),
                    as_float("visual_analysis"),
                    as_float("evaluation_and_redesign"),
                    payload_bytes,
                    findings_count,
                    suggestions_count,
                    mockups_count,
                    evaluation_confidence,
                    priority_issue,
                    benchmark_label,
                    benchmark_similarity,
                    design_pattern_label,
                    design_pattern_family,
                    design_pattern_confidence,
                    redesign_ui_mode,
                    self._json_string(pipeline_metrics),
                    raw_payload,
                ),
            )
            conn.commit()

    def list_reports(self, limit: int = 20, workspace_id: Optional[int] = None) -> list[HistoryItem]:
        query = "SELECT id, input_url, detected_type, ux_score, generated_at, workspace_id FROM reports"
        params: list[object] = []

        if workspace_id is not None:
            query += " WHERE workspace_id = ?"
            params.append(workspace_id)

        query += " ORDER BY id DESC LIMIT ?"
        params.append(limit)

        with self._connect() as conn:
            rows = conn.execute(query, tuple(params)).fetchall()

        return [
            HistoryItem(
                report_id=int(r["id"]),
                input_url=str(r["input_url"]),
                detected_type=str(r["detected_type"]),
                ux_score=int(r["ux_score"]),
                generated_at=str(r["generated_at"]),
                workspace_id=int(r["workspace_id"]) if r["workspace_id"] is not None else None,
            )
            for r in rows
        ]

    def get_report(self, report_id: int) -> ReportResponse | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT payload FROM reports WHERE id = ?",
                (report_id,),
            ).fetchone()

        if row is None:
            return None

        return ReportResponse.model_validate(json.loads(row["payload"]))

    def list_reports_for_domain(
        self,
        domain: str,
        limit: int = 20,
    ) -> list[ReportResponse]:
        normalized = self._normalize_domain(domain)
        results: list[ReportResponse] = []

        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT payload
                FROM reports
                WHERE domain = ?
                ORDER BY id DESC
                LIMIT ?
                """,
                (normalized, max(limit * 3, limit)),
            ).fetchall()

        for row in rows:
            try:
                report = ReportResponse.model_validate(json.loads(row["payload"]))
            except Exception:
                continue

            parsed = urlparse(report.input_url)
            report_domain = (parsed.netloc or "").lower().strip()
            if report_domain == normalized:
                results.append(report)

            if len(results) >= limit:
                break

        return results

    def get_trace(self, trace_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT *
                FROM analysis_traces
                WHERE trace_id = ?
                """,
                (trace_id,),
            ).fetchone()

        if row is None:
            return None

        data = dict(row)
        raw_steps_json = data.get("raw_steps_json") or "{}"
        payload_json = data.get("payload_json") or "{}"

        try:
            data["raw_steps"] = json.loads(raw_steps_json)
        except Exception:
            data["raw_steps"] = {}

        try:
            data["payload"] = json.loads(payload_json)
        except Exception:
            data["payload"] = {}

        return data

    def list_recent_traces(
        self,
        limit: int = 20,
        domain: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        query = """
            SELECT *
            FROM analysis_traces
        """
        params: list[Any] = []

        if domain:
            query += " WHERE domain = ?"
            params.append(self._normalize_domain(domain))

        query += " ORDER BY id DESC LIMIT ?"
        params.append(limit)

        with self._connect() as conn:
            rows = conn.execute(query, tuple(params)).fetchall()

        results: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            try:
                item["raw_steps"] = json.loads(item.get("raw_steps_json") or "{}")
            except Exception:
                item["raw_steps"] = {}
            try:
                item["payload"] = json.loads(item.get("payload_json") or "{}")
            except Exception:
                item["payload"] = {}
            results.append(item)
        return results

    def create_watch(
        self,
        name: str,
        url: str,
        notes: str,
        workspace_id: Optional[int] = None,
    ) -> WatchlistItem:
        created_at = datetime.now(UTC).isoformat()
        with self._connect() as conn:
            cur = conn.execute(
                """
                INSERT INTO watchlists (name, url, notes, created_at, workspace_id)
                VALUES (?, ?, ?, ?, ?)
                """,
                (name, url, notes, created_at, workspace_id),
            )
            conn.commit()
            watch_id = int(cur.lastrowid)

        return WatchlistItem(
            watch_id=watch_id,
            name=name,
            url=url,
            notes=notes,
            created_at=created_at,
            workspace_id=workspace_id,
        )

    def list_watchlists(self, workspace_id: Optional[int] = None) -> list[WatchlistItem]:
        query = "SELECT id, name, url, notes, created_at, workspace_id, last_report_id, last_score FROM watchlists"
        params: list[object] = []

        if workspace_id is not None:
            query += " WHERE workspace_id = ?"
            params.append(workspace_id)

        query += " ORDER BY id DESC"

        with self._connect() as conn:
            rows = conn.execute(query, tuple(params)).fetchall()

        return [
            WatchlistItem(
                watch_id=int(r["id"]),
                name=str(r["name"]),
                url=str(r["url"]),
                notes=str(r["notes"]),
                created_at=str(r["created_at"]),
                workspace_id=int(r["workspace_id"]) if r["workspace_id"] is not None else None,
                last_report_id=int(r["last_report_id"]) if r["last_report_id"] is not None else None,
                last_score=int(r["last_score"]) if r["last_score"] is not None else None,
            )
            for r in rows
        ]

    def update_watch_result(self, watch_id: int, report_id: int, last_score: int) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                UPDATE watchlists
                SET last_report_id = ?, last_score = ?
                WHERE id = ?
                """,
                (report_id, last_score, watch_id),
            )
            conn.commit()

    def upsert_ranking_weights(
        self,
        weights: RankingWeightSet,
        workspace_id: Optional[int] = None,
    ) -> None:
        updated_at = weights.updated_at or datetime.now(UTC).isoformat()

        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO ranking_weights (
                    workspace_id,
                    version,
                    source,
                    ux_weight,
                    attention_focus_weight,
                    cta_visibility_weight,
                    readability_weight,
                    cognitive_load_weight,
                    novelty_weight,
                    confidence_weight,
                    business_alignment_weight,
                    evidence_strength_weight,
                    updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(workspace_id, version) DO UPDATE SET
                    source=excluded.source,
                    ux_weight=excluded.ux_weight,
                    attention_focus_weight=excluded.attention_focus_weight,
                    cta_visibility_weight=excluded.cta_visibility_weight,
                    readability_weight=excluded.readability_weight,
                    cognitive_load_weight=excluded.cognitive_load_weight,
                    novelty_weight=excluded.novelty_weight,
                    confidence_weight=excluded.confidence_weight,
                    business_alignment_weight=excluded.business_alignment_weight,
                    evidence_strength_weight=excluded.evidence_strength_weight,
                    updated_at=excluded.updated_at
                """,
                (
                    workspace_id,
                    weights.version,
                    weights.source,
                    weights.ux_weight,
                    weights.attention_focus_weight,
                    weights.cta_visibility_weight,
                    weights.readability_weight,
                    weights.cognitive_load_weight,
                    weights.novelty_weight,
                    weights.confidence_weight,
                    weights.business_alignment_weight,
                    weights.evidence_strength_weight,
                    updated_at,
                ),
            )
            conn.commit()

    def get_ranking_weights(
        self,
        workspace_id: Optional[int] = None,
        version: str = "v1",
    ) -> RankingWeightSet | None:
        with self._connect() as conn:
            if workspace_id is None:
                row = conn.execute(
                    """
                    SELECT *
                    FROM ranking_weights
                    WHERE workspace_id IS NULL
                      AND version = ?
                    ORDER BY id DESC
                    LIMIT 1
                    """,
                    (version,),
                ).fetchone()
            else:
                row = conn.execute(
                    """
                    SELECT *
                    FROM ranking_weights
                    WHERE workspace_id = ?
                      AND version = ?
                    ORDER BY id DESC
                    LIMIT 1
                    """,
                    (workspace_id, version),
                ).fetchone()

        if row is None:
            return None

        return RankingWeightSet(
            version=str(row["version"]),
            source=str(row["source"]),
            ux_weight=float(row["ux_weight"]),
            attention_focus_weight=float(row["attention_focus_weight"]),
            cta_visibility_weight=float(row["cta_visibility_weight"]),
            readability_weight=float(row["readability_weight"]),
            cognitive_load_weight=float(row["cognitive_load_weight"]),
            novelty_weight=float(row["novelty_weight"]),
            confidence_weight=float(row["confidence_weight"]),
            business_alignment_weight=float(row["business_alignment_weight"]),
            evidence_strength_weight=float(row["evidence_strength_weight"]),
            updated_at=str(row["updated_at"]),
        )

    def save_feedback_event(
        self,
        feedback: UserFeedbackEvent,
        workspace_id: Optional[int | str] = None,
        report_id: Optional[str] = None,
        input_url: str = "",
    ) -> None:
        feedback_id = str(feedback.feedback_id or "").strip() or f"fb_{datetime.now(UTC).timestamp()}"
        created_at = str(feedback.created_at or datetime.now(UTC).isoformat())
        free_text = str(feedback.free_text or "")
        domain = self._extract_domain(input_url) if input_url else ""
        numeric_workspace_id = int(workspace_id) if workspace_id is not None and str(workspace_id).isdigit() else None

        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR REPLACE INTO feedback_events (
                    feedback_id,
                    workspace_id,
                    report_id,
                    input_url,
                    domain,
                    user_id,
                    created_at,
                    free_text,
                    payload_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    feedback_id,
                    numeric_workspace_id,
                    report_id,
                    input_url,
                    domain,
                    feedback.user_id,
                    created_at,
                    free_text,
                    self._json_string(feedback),
                ),
            )

            conn.execute("DELETE FROM feedback_labels WHERE feedback_id = ?", (feedback_id,))

            for label in feedback.labels or []:
                conn.execute(
                    """
                    INSERT INTO feedback_labels (
                        feedback_id,
                        workspace_id,
                        report_id,
                        target_id,
                        target_type,
                        verdict,
                        score,
                        reason,
                        metadata_json,
                        created_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        feedback_id,
                        numeric_workspace_id,
                        report_id,
                        str(label.target_id or ""),
                        str(label.target_type or "suggestion"),
                        str(label.verdict or "neutral"),
                        float(label.score) if label.score is not None else None,
                        str(label.reason or ""),
                        self._json_string(label.metadata),
                        created_at,
                    ),
                )

            conn.commit()

    def list_feedback_events(
        self,
        workspace_id: Optional[int | str] = None,
        domain: Optional[str] = None,
        limit: int = 100,
    ) -> list[UserFeedbackEvent]:
        query = "SELECT payload_json FROM feedback_events"
        clauses: list[str] = []
        params: list[Any] = []

        if workspace_id is not None and str(workspace_id).isdigit():
            clauses.append("workspace_id = ?")
            params.append(int(workspace_id))

        if domain:
            clauses.append("domain = ?")
            params.append(self._normalize_domain(domain))

        if clauses:
            query += " WHERE " + " AND ".join(clauses)

        query += " ORDER BY id DESC LIMIT ?"
        params.append(limit)

        with self._connect() as conn:
            rows = conn.execute(query, tuple(params)).fetchall()

        events: list[UserFeedbackEvent] = []
        for row in rows:
            try:
                events.append(UserFeedbackEvent.model_validate(json.loads(row["payload_json"])))
            except Exception:
                continue
        return events

    def get_feedback_summary(
        self,
        workspace_id: Optional[int | str] = None,
        domain: Optional[str] = None,
    ) -> FeedbackSummary:
        clauses: list[str] = []
        params: list[Any] = []

        join_clause = """
            FROM feedback_labels fl
            LEFT JOIN feedback_events fe ON fe.feedback_id = fl.feedback_id
        """

        if workspace_id is not None and str(workspace_id).isdigit():
            clauses.append("fl.workspace_id = ?")
            params.append(int(workspace_id))

        if domain:
            clauses.append("fe.domain = ?")
            params.append(self._normalize_domain(domain))

        where_sql = f"WHERE {' AND '.join(clauses)}" if clauses else ""

        with self._connect() as conn:
            row = conn.execute(
                f"""
                SELECT
                    COUNT(DISTINCT fl.feedback_id) AS total_events,
                    SUM(CASE WHEN fl.verdict IN ('positive', 'accepted', 'preferred') THEN 1 ELSE 0 END) AS positive_signals,
                    SUM(CASE WHEN fl.verdict IN ('negative', 'rejected') THEN 1 ELSE 0 END) AS negative_signals,
                    SUM(CASE WHEN fl.verdict = 'accepted' THEN 1 ELSE 0 END) AS accepted_suggestions,
                    SUM(CASE WHEN fl.verdict = 'rejected' THEN 1 ELSE 0 END) AS rejected_suggestions
                {join_clause}
                {where_sql}
                """,
                tuple(params),
            ).fetchone()

            preferred_rows = conn.execute(
                f"""
                SELECT target_id, COUNT(*) AS cnt
                {join_clause}
                {where_sql}
                {"AND" if where_sql else "WHERE"} fl.verdict = 'preferred'
                GROUP BY target_id
                ORDER BY cnt DESC, target_id ASC
                LIMIT 10
                """,
                tuple(params),
            ).fetchall()

            positive_reason_rows = conn.execute(
                f"""
                SELECT reason, COUNT(*) AS cnt
                {join_clause}
                {where_sql}
                {"AND" if where_sql else "WHERE"} fl.verdict IN ('positive', 'accepted', 'preferred')
                  AND TRIM(COALESCE(fl.reason, '')) <> ''
                GROUP BY reason
                ORDER BY cnt DESC, reason ASC
                LIMIT 5
                """,
                tuple(params),
            ).fetchall()

            negative_reason_rows = conn.execute(
                f"""
                SELECT reason, COUNT(*) AS cnt
                {join_clause}
                {where_sql}
                {"AND" if where_sql else "WHERE"} fl.verdict IN ('negative', 'rejected')
                  AND TRIM(COALESCE(fl.reason, '')) <> ''
                GROUP BY reason
                ORDER BY cnt DESC, reason ASC
                LIMIT 5
                """,
                tuple(params),
            ).fetchall()

        preferred_variants = {
            str(r["target_id"]): int(r["cnt"])
            for r in preferred_rows
            if str(r["target_id"] or "").strip()
        }

        total_events = int(row["total_events"] or 0) if row else 0
        positive_signals = int(row["positive_signals"] or 0) if row else 0
        negative_signals = int(row["negative_signals"] or 0) if row else 0
        accepted_suggestions = int(row["accepted_suggestions"] or 0) if row else 0
        rejected_suggestions = int(row["rejected_suggestions"] or 0) if row else 0

        return FeedbackSummary(
            total_events=total_events,
            positive_signals=positive_signals,
            negative_signals=negative_signals,
            accepted_suggestions=accepted_suggestions,
            rejected_suggestions=rejected_suggestions,
            preferred_variants=preferred_variants,
            top_positive_themes=[str(r["reason"]) for r in positive_reason_rows],
            top_negative_themes=[str(r["reason"]) for r in negative_reason_rows],
        )

    def save_ab_test_result(
        self,
        *,
        trace_id: Optional[str],
        workspace_id: Optional[int | str],
        report_id: Optional[str],
        input_url: str,
        scoring_type: str,
        baseline_variant_id: str,
        winner_variant_id: str,
        primary_metric: str,
        summary: str,
        variants: list[dict[str, Any]] | list[Any],
    ) -> None:
        domain = self._extract_domain(input_url)
        generated_at = datetime.now(UTC).isoformat()

        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO ab_test_results (
                    trace_id,
                    workspace_id,
                    report_id,
                    input_url,
                    domain,
                    generated_at,
                    scoring_type,
                    baseline_variant_id,
                    winner_variant_id,
                    primary_metric,
                    summary,
                    variants_json
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    trace_id,
                    int(workspace_id) if workspace_id is not None and str(workspace_id).isdigit() else None,
                    report_id,
                    input_url,
                    domain,
                    generated_at,
                    scoring_type,
                    baseline_variant_id,
                    winner_variant_id,
                    primary_metric,
                    summary,
                    self._json_string(variants),
                ),
            )
            conn.commit()

    def list_ab_test_results(
        self,
        workspace_id: Optional[int | str] = None,
        domain: Optional[str] = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        query = "SELECT * FROM ab_test_results"
        clauses: list[str] = []
        params: list[Any] = []

        if workspace_id is not None and str(workspace_id).isdigit():
            clauses.append("workspace_id = ?")
            params.append(int(workspace_id))

        if domain:
            clauses.append("domain = ?")
            params.append(self._normalize_domain(domain))

        if clauses:
            query += " WHERE " + " AND ".join(clauses)

        query += " ORDER BY id DESC LIMIT ?"
        params.append(limit)

        with self._connect() as conn:
            rows = conn.execute(query, tuple(params)).fetchall()

        results: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            try:
                item["variants"] = json.loads(item.get("variants_json") or "[]")
            except Exception:
                item["variants"] = []
            results.append(item)
        return results


storage_service = StorageService()