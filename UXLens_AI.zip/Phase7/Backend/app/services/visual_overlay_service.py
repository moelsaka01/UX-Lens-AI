from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFont

from app.config import settings


class VisualOverlayService:
    def __init__(self) -> None:
        self._cache: OrderedDict[str, str | None] = OrderedDict()
        self._cache_limit = 24

    def generate_overlay(
        self,
        image_path: str | None,
        redesign_transformation: dict[str, Any] | None = None,
    ) -> str | None:
        if not image_path:
            return None

        path = Path(settings.screenshot_dir) / Path(image_path).name
        if not path.exists():
            return None

        cache_key = f"{path.resolve()}::{self._safe_cache_key(redesign_transformation)}"
        if cache_key in self._cache:
            cached = self._cache[cache_key]
            self._cache.move_to_end(cache_key)
            return cached

        try:
            with Image.open(path) as opened:
                image = opened.convert("RGBA")

            w, h = image.size

            dim_strength = int(max(20, min(170, float(getattr(settings, "overlay_dim_strength", 0.45)) * 255)))
            base_overlay = Image.new("RGBA", image.size, (8, 12, 16, dim_strength))
            composed = Image.alpha_composite(image, base_overlay)

            draw = ImageDraw.Draw(composed)

            before: dict[str, Any] = {}
            after: dict[str, Any] = {}
            deltas: dict[str, Any] = {}
            assumptions: list[str] = []
            realism_confidence = 0.0
            ui_mode = "concepts"

            if redesign_transformation:
                before = redesign_transformation.get("before", {}) or {}
                after = redesign_transformation.get("after", {}) or {}
                deltas = redesign_transformation.get("deltas", {}) or {}
                assumptions = list(redesign_transformation.get("assumptions", []) or [])
                realism_confidence = float(redesign_transformation.get("realism_confidence", 0.0) or 0.0)
                ui_mode = str(redesign_transformation.get("ui_mode", "concepts") or "concepts")

            nav_before = self._int_from(before, "nav_items", fallback=0)
            nav_after = self._int_from(after, "nav_items", fallback=nav_before)

            cta_before = self._int_from(
                before,
                "cta_count",
                fallback=self._int_from(before, "cta_above_fold_count", fallback=0),
            )
            cta_after = self._int_from(
                after,
                "cta_count",
                fallback=self._int_from(after, "cta_above_fold_count", fallback=cta_before),
            )

            hero_before = self._int_from(
                before,
                "hero_text_length",
                fallback=self._int_from(before, "hero_words", fallback=0),
            )
            hero_after = self._int_from(
                after,
                "hero_text_length",
                fallback=self._int_from(after, "hero_words", fallback=hero_before),
            )

            nodes_before = self._int_from(before, "above_fold_nodes", fallback=0)
            nodes_after = self._int_from(after, "above_fold_nodes", fallback=nodes_before)

            focus_delta = self._float_from(deltas, "attention_focus", fallback=0.0)
            cta_delta = self._float_from(deltas, "cta_visibility", fallback=0.0)
            readability_delta = self._float_from(deltas, "readability", fallback=0.0)

            overlay_intensity = self._overlay_intensity(
                focus_delta=focus_delta,
                cta_delta=cta_delta,
                readability_delta=readability_delta,
                nav_before=nav_before,
                nav_after=nav_after,
                nodes_before=nodes_before,
                nodes_after=nodes_after,
            )

            self._draw_top_nav_cleanup(
                draw=draw,
                w=w,
                h=h,
                nav_before=nav_before,
                nav_after=nav_after,
                overlay_intensity=overlay_intensity,
                ui_mode=ui_mode,
            )

            self._draw_hero_compaction(
                draw=draw,
                w=w,
                h=h,
                hero_before=hero_before,
                hero_after=hero_after,
                overlay_intensity=overlay_intensity,
                ui_mode=ui_mode,
            )

            self._draw_cta_emphasis(
                draw=draw,
                w=w,
                h=h,
                cta_before=cta_before,
                cta_after=cta_after,
                overlay_intensity=overlay_intensity,
                ui_mode=ui_mode,
            )

            self._draw_density_cleanup(
                draw=draw,
                w=w,
                h=h,
                nodes_before=nodes_before,
                nodes_after=nodes_after,
                overlay_intensity=overlay_intensity,
                ui_mode=ui_mode,
            )


            overlay_suffix = abs(hash(cache_key)) % 10_000_000
            output_path = settings.screenshot_dir / f"{path.stem}_overlay_{overlay_suffix}.png"
            composed.convert("RGB").save(output_path)

            result = f"/static/generated/{output_path.name}"
            self._remember_cache(cache_key, result)
            return result

        except Exception as exc:
            print(f"[OverlayService] Failed for {path.name}: {exc}")
            self._remember_cache(cache_key, None)
            return None

    def _draw_top_nav_cleanup(
        self,
        *,
        draw: ImageDraw.ImageDraw,
        w: int,
        h: int,
        nav_before: int,
        nav_after: int,
        overlay_intensity: float,
        ui_mode: str,
    ) -> None:
        if nav_before <= 0:
            return

        header_box = [
            int(w * 0.04),
            int(h * 0.04),
            int(w * 0.96),
            int(h * 0.15),
        ]

        if ui_mode == "visual_previews":
            amber = self._scale_color((255, 196, 92), overlay_intensity)
            outline_alpha = 235
            line_width = max(2, int(3 + overlay_intensity * 2))
        else:
            amber = self._scale_color((214, 176, 110), max(0.35, overlay_intensity * 0.72))
            outline_alpha = 190
            line_width = 2

        draw.rounded_rectangle(
            header_box,
            radius=18,
            outline=(*amber, outline_alpha),
            width=line_width,
        )

        if nav_after < nav_before:
            ratio = max(0.26, min(0.92, nav_after / max(1, nav_before)))
            reduced_width = int((header_box[2] - header_box[0]) * ratio)
            focus_box = [
                header_box[0] + 16,
                header_box[1] + 12,
                header_box[0] + reduced_width,
                header_box[3] - 12,
            ]
            draw.rounded_rectangle(
                focus_box,
                radius=14,
                outline=(255, 208, 110, 255 if ui_mode == "visual_previews" else 210),
                width=max(2, int(2 + overlay_intensity * 2)) if ui_mode == "visual_previews" else 2,
            )

    def _draw_hero_compaction(
        self,
        *,
        draw: ImageDraw.ImageDraw,
        w: int,
        h: int,
        hero_before: int,
        hero_after: int,
        overlay_intensity: float,
        ui_mode: str,
    ) -> None:
        hero_box = [
            int(w * 0.08),
            int(h * 0.18),
            int(w * 0.60),
            int(h * 0.50),
        ]

        if ui_mode == "visual_previews":
            blue = self._scale_color((110, 168, 255), overlay_intensity)
            line_width = max(2, int(3 + overlay_intensity * 2))
            alpha = 235
        else:
            blue = self._scale_color((130, 168, 220), max(0.35, overlay_intensity * 0.72))
            line_width = 2
            alpha = 190

        draw.rounded_rectangle(
            hero_box,
            radius=22,
            outline=(*blue, alpha),
            width=line_width,
        )

        if hero_before > 0 and hero_after > 0 and hero_after < hero_before:
            compression_ratio = hero_after / max(1, hero_before)
            compressed_box = [
                hero_box[0] + 12,
                hero_box[1] + 12,
                int(hero_box[0] + ((hero_box[2] - hero_box[0]) * max(0.45, min(0.95, compression_ratio + 0.15)))),
                int(hero_box[1] + ((hero_box[3] - hero_box[1]) * 0.56)),
            ]
            draw.rounded_rectangle(
                compressed_box,
                radius=18,
                outline=(120, 182, 255, 255 if ui_mode == "visual_previews" else 210),
                width=max(2, int(2 + overlay_intensity * 2)) if ui_mode == "visual_previews" else 2,
            )

    def _draw_cta_emphasis(
        self,
        *,
        draw: ImageDraw.ImageDraw,
        w: int,
        h: int,
        cta_before: int,
        cta_after: int,
        overlay_intensity: float,
        ui_mode: str,
    ) -> None:
        primary_cta = [
            int(w * 0.10),
            int(h * 0.52),
            int(w * 0.34),
            int(h * 0.62),
        ]

        if ui_mode == "visual_previews":
            green = self._scale_color((66, 236, 186), overlay_intensity)
            line_width = max(3, int(4 + overlay_intensity * 2))
            alpha = 255
        else:
            green = self._scale_color((104, 202, 170), max(0.35, overlay_intensity * 0.72))
            line_width = 2
            alpha = 205

        draw.rounded_rectangle(
            primary_cta,
            radius=20,
            outline=(*green, alpha),
            width=line_width,
        )

        if cta_before > 1:
            secondary_area = [
                int(w * 0.36),
                int(h * 0.52),
                int(w * 0.58),
                int(h * 0.62),
            ]
            draw.rounded_rectangle(
                secondary_area,
                radius=20,
                outline=(255, 120, 120, 220 if ui_mode == "visual_previews" else 170),
                width=max(2, int(2 + overlay_intensity)) if ui_mode == "visual_previews" else 2,
            )

        if cta_after == 1 and ui_mode == "visual_previews":
            glow = [
                int(w * 0.085),
                int(h * 0.505),
                int(w * 0.355),
                int(h * 0.635),
            ]
            draw.rounded_rectangle(
                glow,
                radius=24,
                outline=(66, 236, 186, 160),
                width=2,
            )

    def _draw_density_cleanup(
        self,
        *,
        draw: ImageDraw.ImageDraw,
        w: int,
        h: int,
        nodes_before: int,
        nodes_after: int,
        overlay_intensity: float,
        ui_mode: str,
    ) -> None:
        if nodes_before <= 0 or nodes_after >= nodes_before:
            return

        right_col_box = [
            int(w * 0.63),
            int(h * 0.28),
            int(w * 0.94),
            int(h * 0.74),
        ]

        if ui_mode == "visual_previews":
            purple = self._scale_color((181, 146, 255), overlay_intensity)
            alpha = 210
            line_width = max(2, int(2 + overlay_intensity * 2))
        else:
            purple = self._scale_color((170, 154, 220), max(0.35, overlay_intensity * 0.70))
            alpha = 170
            line_width = 2

        draw.rounded_rectangle(
            right_col_box,
            radius=20,
            outline=(*purple, alpha),
            width=line_width,
        )

        trimmed_box = [
            int(w * 0.67),
            int(h * 0.34),
            int(w * 0.90),
            int(h * 0.56),
        ]
        draw.rounded_rectangle(
            trimmed_box,
            radius=16,
            outline=(196, 170, 255, 255 if ui_mode == "visual_previews" else 200),
            width=2,
        )

    def _overlay_intensity(
        self,
        *,
        focus_delta: float,
        cta_delta: float,
        readability_delta: float,
        nav_before: int,
        nav_after: int,
        nodes_before: int,
        nodes_after: int,
    ) -> float:
        score = 0.45
        score += min(0.20, max(0.0, focus_delta) / 20.0)
        score += min(0.15, max(0.0, cta_delta) / 20.0)
        score += min(0.08, max(0.0, readability_delta) / 15.0)

        if nav_before > 0 and nav_after < nav_before:
            score += min(0.10, (nav_before - nav_after) / 20.0)
        if nodes_before > 0 and nodes_after < nodes_before:
            score += min(0.10, (nodes_before - nodes_after) / 120.0)

        return max(0.35, min(1.0, score))

    def _scale_color(self, rgb: tuple[int, int, int], intensity: float) -> tuple[int, int, int]:
        return tuple(max(0, min(255, int(channel * (0.72 + (intensity * 0.28))))) for channel in rgb)

    def _safe_cache_key(self, value: dict[str, Any] | None) -> str:
        if not value:
            return "none"

        before = value.get("before", {}) or {}
        after = value.get("after", {}) or {}
        deltas = value.get("deltas", {}) or {}
        assumptions = list(value.get("assumptions", []) or [])

        return (
            f"b:{before.get('nav_items','')}-{before.get('cta_count', before.get('cta_above_fold_count',''))}"
            f"-{before.get('hero_text_length', before.get('hero_words',''))}-{before.get('above_fold_nodes','')}"
            f"|a:{after.get('nav_items','')}-{after.get('cta_count', after.get('cta_above_fold_count',''))}"
            f"-{after.get('hero_text_length', after.get('hero_words',''))}-{after.get('above_fold_nodes','')}"
            f"|d:{deltas.get('attention_focus','')}-{deltas.get('cta_visibility','')}"
            f"-{deltas.get('readability','')}-{deltas.get('hero_words', deltas.get('hero_text_length',''))}"
            f"-{deltas.get('above_fold_nodes','')}"
            f"|m:{value.get('ui_mode','concepts')}-{value.get('realism_confidence','')}"
            f"|assumptions:{len(assumptions)}:{'|'.join(str(item)[:40] for item in assumptions[:2])}"
        )

    def _load_font(self, size: int = 18, bold: bool = False) -> Any:
        font_candidates = [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        ]

        for font_path in font_candidates:
            try:
                if Path(font_path).exists():
                    return ImageFont.truetype(font_path, size=size)
            except Exception:
                pass

        try:
            return ImageFont.load_default()
        except Exception:
            return None
    
    def _draw_text_lines(
        self,
        *,
        draw: ImageDraw.ImageDraw,
        lines: list[str],
        x: int,
        y: int,
        line_gap: int,
        font: Any,
        fill: tuple[int, int, int, int],
    ) -> None:
        for idx, line in enumerate(lines):
            draw.text(
                (x, y + (idx * line_gap)),
                line,
                fill=fill,
                font=font,
            )

    def _truncate_line(self, text: str, max_len: int) -> str:
        text = str(text or "").strip()
        if len(text) <= max_len:
            return text
        return f"{text[:max_len - 3].rstrip()}..."

    def _signed_int(self, value: float) -> str:
        rounded = int(round(float(value)))
        return f"+{rounded}" if rounded >= 0 else str(rounded)

    def _int_from(self, data: dict[str, Any], key: str, fallback: int = 0) -> int:
        try:
            return int(data.get(key, fallback) or fallback)
        except Exception:
            return fallback

    def _float_from(self, data: dict[str, Any], key: str, fallback: float = 0.0) -> float:
        try:
            return float(data.get(key, fallback) or fallback)
        except Exception:
            return fallback

    def _remember_cache(self, cache_key: str, value: str | None) -> None:
        self._cache[cache_key] = value
        self._cache.move_to_end(cache_key)
        while len(self._cache) > self._cache_limit:
            self._cache.popitem(last=False)


visual_overlay_service = VisualOverlayService()