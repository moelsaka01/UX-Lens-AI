from __future__ import annotations

from typing import Any

from app.schemas import ExtractedSignals, Finding, LayoutSimilarity, RedesignTransformation, ScoreBlock, Suggestion


class RedesignEngine:
    def generate_transformation(
        self,
        *,
        signals: ExtractedSignals,
        scores: ScoreBlock,
        findings: list[Finding] | None = None,
        suggestions: list[Suggestion] | None = None,
        layout_similarity: LayoutSimilarity | None = None,
    ) -> RedesignTransformation:
        findings = findings or []
        suggestions = suggestions or []

        nav_items = int(signals.nav_item_count or 0)
        hero_text_length = int(signals.hero_text_length or 0)
        cta_count = int(signals.cta_above_fold_count or 0)
        strong_cta_count = int(signals.strong_cta_above_fold_count or 0)
        above_fold_nodes = int(signals.above_fold_nodes or 0)
        section_count = int(signals.section_count or 0)
        form_count = int(signals.form_count or 0)
        avg_paragraph_words = float(signals.avg_paragraph_words or 0.0)

        readability_score = int(scores.readability)
        focus_score = int(scores.attention_focus)
        cta_score = int(scores.cta_visibility)
        cognitive_score = int(scores.cognitive_load)

        suggestion_titles = [str(item.title or "").lower() for item in suggestions]
        finding_titles = [str(item.title or "").lower() for item in findings]
        combined_titles = " ".join(finding_titles + suggestion_titles)

        reduce_navigation = self._needs_navigation_reduction(
            nav_items=nav_items,
            findings=findings,
            suggestions=suggestions,
        )
        simplify_cta = self._needs_cta_simplification(
            cta_count=cta_count,
            findings=findings,
            suggestions=suggestions,
        )
        tighten_copy = self._needs_copy_tightening(
            hero_text_length=hero_text_length,
            findings=findings,
            suggestions=suggestions,
        )
        improve_pacing = self._needs_section_pacing_improvement(
            section_count=section_count,
            findings=findings,
            suggestions=suggestions,
        )
        reduce_clutter = self._needs_clutter_reduction(
            above_fold_nodes=above_fold_nodes,
            findings=findings,
            suggestions=suggestions,
        )
        strengthen_proof = self._needs_proof_repositioning(
            findings=findings,
            suggestions=suggestions,
        )
        improve_form_path = self._needs_form_path_improvement(
            form_count=form_count,
            findings=findings,
            suggestions=suggestions,
        )

        top_suggestion_title = str(suggestions[0].title or "").lower() if suggestions else ""
        top_finding_title = str(findings[0].title or "").lower() if findings else ""

        profile_similarity = int(layout_similarity.similarity or 0) if layout_similarity else 0
        profile_name = str(layout_similarity.profile or "").strip().lower() if layout_similarity else ""

        target_nav_items = nav_items
        if reduce_navigation:
            if nav_items >= 20:
                target_nav_items = self._clamp_int(nav_items - 8, 6, nav_items)
            elif nav_items >= 16:
                target_nav_items = self._clamp_int(nav_items - 6, 6, nav_items)
            elif nav_items >= 13:
                target_nav_items = self._clamp_int(nav_items - 4, 7, nav_items)
            elif nav_items >= 10:
                target_nav_items = self._clamp_int(nav_items - 2, 7, nav_items)

        target_cta_count = cta_count
        if simplify_cta:
            if cta_count >= 4:
                target_cta_count = 1
            elif cta_count >= 2:
                target_cta_count = 1
            elif cta_count == 0:
                target_cta_count = 1
        elif cta_count == 0:
            target_cta_count = 1

        target_hero_text_length = hero_text_length
        if tighten_copy:
            if hero_text_length >= 240:
                target_hero_text_length = max(26, hero_text_length - 85)
            elif hero_text_length >= 180:
                target_hero_text_length = max(30, hero_text_length - 60)
            elif hero_text_length >= 120:
                target_hero_text_length = max(34, hero_text_length - 36)
            elif hero_text_length >= 80:
                target_hero_text_length = max(34, hero_text_length - 18)
        elif hero_text_length > 100:
            target_hero_text_length = max(40, hero_text_length - 10)

        target_section_count = section_count
        if improve_pacing and section_count > 0:
            if section_count >= 12:
                target_section_count = max(7, section_count - 3)
            elif section_count >= 9:
                target_section_count = max(7, section_count - 2)
            elif section_count >= 7 and "content" in combined_titles:
                target_section_count = max(6, section_count - 1)

        nav_reduction = max(0, nav_items - target_nav_items)
        cta_reduction = max(0, cta_count - target_cta_count)
        copy_reduction = max(0, hero_text_length - target_hero_text_length)
        section_reduction = max(0, section_count - target_section_count)

        node_reduction = 0
        if reduce_navigation:
            node_reduction += min(24, nav_reduction * 2)
        if simplify_cta:
            node_reduction += min(12, max(1, cta_reduction) * 3)
        if tighten_copy:
            node_reduction += min(16, max(0, copy_reduction // 8))
        if improve_pacing:
            node_reduction += min(12, section_reduction * 2)
        if reduce_clutter:
            node_reduction += 10
        if strengthen_proof:
            node_reduction += 2
        if improve_form_path:
            node_reduction += 2

        target_above_fold_nodes = above_fold_nodes
        if above_fold_nodes > 0:
            minimum_nodes = 42 if above_fold_nodes >= 100 else 24
            target_above_fold_nodes = max(minimum_nodes, above_fold_nodes - node_reduction)

        similarity_bonus = 0
        if profile_similarity >= 88:
            similarity_bonus = 3
        elif profile_similarity >= 78:
            similarity_bonus = 2
        elif profile_similarity >= 68:
            similarity_bonus = 1

        focus_gain = 0
        if reduce_navigation:
            focus_gain += min(8, max(1, nav_reduction))
        if simplify_cta:
            focus_gain += 3
        if tighten_copy:
            focus_gain += min(4, max(1, copy_reduction // 20))
        if reduce_clutter:
            focus_gain += 5
        if improve_pacing:
            focus_gain += 2
        focus_gain += similarity_bonus

        cta_gain = 0
        if simplify_cta:
            cta_gain += min(9, max(2, cta_reduction * 3))
        if improve_form_path:
            cta_gain += 3
        if strong_cta_count == 0:
            cta_gain += 1
        if signals.primary_cta_label:
            cta_gain += 1

        readability_gain = 0
        if tighten_copy:
            readability_gain += min(7, max(2, copy_reduction // 16))
        if improve_pacing:
            readability_gain += 2
        if avg_paragraph_words > 38:
            readability_gain += 1

        cognitive_gain = 0
        if reduce_navigation:
            cognitive_gain += min(5, max(1, nav_reduction))
        if simplify_cta:
            cognitive_gain += 2
        if reduce_clutter:
            cognitive_gain += 5
        if improve_pacing:
            cognitive_gain += 2
        if tighten_copy:
            cognitive_gain += 1

        if "proof" in combined_titles or "trust" in combined_titles:
            focus_gain += 1
            cta_gain += 1
        if "form" in combined_titles or "conversion" in combined_titles:
            cta_gain += 1
        if "noise" in combined_titles or "clutter" in combined_titles or "competition" in combined_titles:
            cognitive_gain += 1
            focus_gain += 1
        if "hero" in combined_titles or "messaging" in combined_titles or "copy" in combined_titles:
            readability_gain += 1

        target_cta_visibility = self._clamp_int(cta_score + cta_gain, 0, 99)
        target_attention_focus = self._clamp_int(focus_score + focus_gain, 0, 99)
        target_readability = self._clamp_int(readability_score + readability_gain, 0, 99)
        target_cognitive_load = self._clamp_int(cognitive_score + cognitive_gain, 0, 99)

        before = {
            "nav_items": nav_items,
            "cta_visibility": cta_score,
            "attention_focus": focus_score,
            "hero_text_length": hero_text_length,
            "hero_words": hero_text_length,
            "cta_count": cta_count,
            "above_fold_nodes": above_fold_nodes,
            "section_count": section_count,
            "readability": readability_score,
            "cognitive_load": cognitive_score,
        }

        after = {
            "nav_items": int(target_nav_items),
            "cta_visibility": target_cta_visibility,
            "attention_focus": target_attention_focus,
            "hero_text_length": int(target_hero_text_length),
            "hero_words": int(target_hero_text_length),
            "cta_count": int(target_cta_count),
            "above_fold_nodes": int(target_above_fold_nodes),
            "section_count": int(target_section_count),
            "readability": target_readability,
            "cognitive_load": target_cognitive_load,
        }

        deltas = {key: int(after[key]) - int(before[key]) for key in before.keys()}

        assumptions = [
            "Assumes the redesign preserves the same product, audience, and page intent.",
            "Assumes the largest gains come from hierarchy, message compression, CTA emphasis, and cleaner visual sequencing.",
            "Assumes projected gains are directional UX estimates, not measured live experiment outcomes.",
        ]

        if reduce_navigation:
            assumptions.append(
                f"Navigation is simplified from {nav_items} visible routes toward {target_nav_items} without removing critical destinations."
            )
        if simplify_cta:
            assumptions.append(
                f"CTA competition is reduced from {cta_count} above-fold action points toward {target_cta_count} dominant action path."
            )
        if tighten_copy:
            assumptions.append(
                f"Hero message load is compressed from about {hero_text_length} words toward {target_hero_text_length} words."
            )
        if improve_pacing:
            assumptions.append(
                f"Section flow is tightened from {section_count} visible sections toward {target_section_count} more deliberate content blocks."
            )
        if strengthen_proof:
            assumptions.append("Trust and proof elements are moved closer to the hero and CTA path.")
        if improve_form_path:
            assumptions.append("Form framing is improved through reassurance, proof, and clearer value reinforcement.")
        if profile_name:
            assumptions.append(
                f"Transformation is constrained to remain credible for the detected '{profile_name}' layout family."
            )

        reasoning_notes = self._build_reasoning_notes(
            top_suggestion_title=top_suggestion_title,
            top_finding_title=top_finding_title,
            reduce_navigation=reduce_navigation,
            simplify_cta=simplify_cta,
            tighten_copy=tighten_copy,
            improve_pacing=improve_pacing,
            reduce_clutter=reduce_clutter,
            strengthen_proof=strengthen_proof,
            improve_form_path=improve_form_path,
            nav_items=nav_items,
            cta_count=cta_count,
            hero_text_length=hero_text_length,
            above_fold_nodes=above_fold_nodes,
            target_nav_items=target_nav_items,
            target_cta_count=target_cta_count,
            target_hero_text_length=target_hero_text_length,
            target_above_fold_nodes=target_above_fold_nodes,
        )
        if reasoning_notes:
            assumptions.extend(reasoning_notes[:3])

        realism_confidence = 0.71
        if abs(deltas["attention_focus"]) <= 10:
            realism_confidence += 0.05
        if abs(deltas["cta_visibility"]) <= 10:
            realism_confidence += 0.05
        if abs(deltas["readability"]) <= 8:
            realism_confidence += 0.03
        if abs(deltas["cognitive_load"]) <= 8:
            realism_confidence += 0.03
        if target_above_fold_nodes <= above_fold_nodes:
            realism_confidence += 0.03
        if profile_similarity >= 75:
            realism_confidence += 0.02
        if suggestions:
            realism_confidence += 0.02
        realism_confidence = min(0.95, realism_confidence)

        return RedesignTransformation(
            before=before,
            after=after,
            deltas=deltas,
            assumptions=assumptions,
            realism_confidence=round(realism_confidence, 3),
        )

    def _build_reasoning_notes(
        self,
        *,
        top_suggestion_title: str,
        top_finding_title: str,
        reduce_navigation: bool,
        simplify_cta: bool,
        tighten_copy: bool,
        improve_pacing: bool,
        reduce_clutter: bool,
        strengthen_proof: bool,
        improve_form_path: bool,
        nav_items: int,
        cta_count: int,
        hero_text_length: int,
        above_fold_nodes: int,
        target_nav_items: int,
        target_cta_count: int,
        target_hero_text_length: int,
        target_above_fold_nodes: int,
    ) -> list[str]:
        notes: list[str] = []

        if "navigation" in top_suggestion_title or "navigation" in top_finding_title:
            notes.append(
                f"Primary redesign move targets header simplification by reducing visible nav choices from {nav_items} to about {target_nav_items}."
            )

        if "primary action" in top_suggestion_title or "cta" in top_suggestion_title or "cta" in top_finding_title:
            notes.append(
                f"Primary redesign move sharpens action hierarchy by reducing above-fold CTA competition from {cta_count} to about {target_cta_count}."
            )

        if "hero" in top_suggestion_title or "copy" in top_suggestion_title or "messaging" in top_finding_title:
            notes.append(
                f"Primary redesign move compresses the opening message from about {hero_text_length} words toward {target_hero_text_length} words."
            )

        if "noise" in top_suggestion_title or "clutter" in top_finding_title or reduce_clutter:
            notes.append(
                f"Primary redesign move reduces visual load in the first screen by cutting visible nodes from about {above_fold_nodes} to {target_above_fold_nodes}."
            )

        if strengthen_proof:
            notes.append("Trust cues are assumed to move closer to the hero so reassurance supports the main action earlier.")
        if improve_form_path:
            notes.append("Form pressure is assumed to be softened by reinforcing value and reducing commitment anxiety near submission.")
        if improve_pacing:
            notes.append("Section pacing is assumed to improve through stronger grouping and fewer abrupt content transitions.")
        if tighten_copy and not any("opening message" in note.lower() for note in notes):
            notes.append("Copy load is reduced so the value proposition lands faster and supports earlier action clarity.")
        if simplify_cta and not any("action hierarchy" in note.lower() for note in notes):
            notes.append("CTA hierarchy is tightened so one primary next step dominates the decision moment.")
        if reduce_navigation and not any("header simplification" in note.lower() for note in notes):
            notes.append("Header choice load is reduced to support stronger hero focus and less early branching.")

        return notes

    def _needs_navigation_reduction(
        self,
        *,
        nav_items: int,
        findings: list[Finding],
        suggestions: list[Suggestion],
    ) -> bool:
        if nav_items >= 14:
            return True

        combined = " ".join(
            [str(item.title).lower() for item in findings]
            + [str(item.title).lower() for item in suggestions]
        )
        return "navigation" in combined or "nav" in combined or "header" in combined

    def _needs_cta_simplification(
        self,
        *,
        cta_count: int,
        findings: list[Finding],
        suggestions: list[Suggestion],
    ) -> bool:
        if cta_count >= 3:
            return True

        combined = " ".join(
            [str(item.title).lower() for item in findings]
            + [str(item.title).lower() for item in suggestions]
        )
        return "cta" in combined or "action" in combined or "primary action" in combined

    def _needs_copy_tightening(
        self,
        *,
        hero_text_length: int,
        findings: list[Finding],
        suggestions: list[Suggestion],
    ) -> bool:
        if hero_text_length >= 90:
            return True

        combined = " ".join(
            [str(item.title).lower() for item in findings]
            + [str(item.title).lower() for item in suggestions]
        )
        return "hero" in combined or "copy" in combined or "readability" in combined or "messaging" in combined

    def _needs_section_pacing_improvement(
        self,
        *,
        section_count: int,
        findings: list[Finding],
        suggestions: list[Suggestion],
    ) -> bool:
        if section_count >= 9:
            return True

        combined = " ".join(
            [str(item.title).lower() for item in findings]
            + [str(item.title).lower() for item in suggestions]
        )
        return "section pacing" in combined or "content rhythm" in combined or "content" in combined

    def _needs_clutter_reduction(
        self,
        *,
        above_fold_nodes: int,
        findings: list[Finding],
        suggestions: list[Suggestion],
    ) -> bool:
        if above_fold_nodes >= 280:
            return True

        combined = " ".join(
            [str(item.title).lower() for item in findings]
            + [str(item.title).lower() for item in suggestions]
        )
        return "noise" in combined or "clutter" in combined or "competition" in combined

    def _needs_proof_repositioning(
        self,
        *,
        findings: list[Finding],
        suggestions: list[Suggestion],
    ) -> bool:
        combined = " ".join(
            [str(item.title).lower() for item in findings]
            + [str(item.title).lower() for item in suggestions]
        )
        return "proof" in combined or "trust" in combined

    def _needs_form_path_improvement(
        self,
        *,
        form_count: int,
        findings: list[Finding],
        suggestions: list[Suggestion],
    ) -> bool:
        if form_count > 0:
            combined = " ".join(
                [str(item.title).lower() for item in findings]
                + [str(item.title).lower() for item in suggestions]
            )
            return "form" in combined or "conversion" in combined or "cta" in combined
        return False

    def _clamp_int(self, value: int, low: int, high: int) -> int:
        return max(low, min(high, int(value)))


redesign_engine = RedesignEngine()