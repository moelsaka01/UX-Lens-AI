from __future__ import annotations

import sqlite3
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from app.config import settings
from app.services.local_image_service import local_image_service


class ProductionArchitectureService:
    """Local/free production-readiness snapshot.

    No paid APM, hosted queue, hosted database, login layer, or SaaS dependency is used.
    This service gives the frontend a production architecture panel backed by local checks.
    """

    def snapshot(self) -> dict[str, Any]:
        db_path = Path(settings.base_dir) / "app.db"
        static_dir = Path(settings.static_dir)
        generated_dir = Path(settings.screenshot_dir)
        mockup_dir = Path(settings.mockup_dir)
        mockup_health = local_image_service.health()

        table_counts = self._table_counts(db_path)
        db_size_mb = round(db_path.stat().st_size / (1024 * 1024), 3) if db_path.exists() else 0.0
        generated_count = self._count_files(generated_dir)
        mockup_count = self._count_files(mockup_dir)

        checks = [
            self._check("api", True, "FastAPI application is available."),
            self._check("static_files", static_dir.exists(), f"Static directory: {static_dir}"),
            self._check("screenshots", generated_dir.exists(), f"Generated screenshot directory: {generated_dir}"),
            self._check("sqlite_storage", db_path.exists(), f"SQLite database size: {db_size_mb} MB"),
            self._check("feedback_loop", True, "Feedback endpoints and local persistence are enabled."),
            self._check("learning_ranker", True, "Local explainable ranking-weight learning is enabled."),
            self._check("mockup_pipeline", bool(mockup_health.get("enabled", False)), str(mockup_health.get("reason", "")) or "Mockup pipeline configured."),
        ]

        ready = sum(1 for item in checks if item["ok"])
        score = int(round((ready / max(1, len(checks))) * 100))

        return {
            "generated_at": datetime.now(UTC).isoformat(),
            "requires_login": False,
            "requires_paid_services": False,
            "environment": {
                "app_name": settings.app_name,
                "api_prefix": settings.api_prefix,
                "frontend_origin": settings.frontend_origin,
                "base_dir": str(settings.base_dir),
                "static_dir": str(static_dir),
                "database": str(db_path),
            },
            "readiness_score": score,
            "checks": checks,
            "storage": {
                "db_exists": db_path.exists(),
                "db_size_mb": db_size_mb,
                "table_counts": table_counts,
                "generated_file_count": generated_count,
                "mockup_file_count": mockup_count,
            },
            "capabilities": {
                "analysis": True,
                "compare": True,
                "feedback": True,
                "local_learning": True,
                "ab_scoring": True,
                "visual_mockups": bool(mockup_health.get("available", False)),
                "concept_mode": str(mockup_health.get("ui_mode", "concepts")) == "concepts",
            },
            "recommended_next_steps": self.recommended_next_steps(score=score, mockup_health=mockup_health),
        }

    def roadmap(self) -> dict[str, Any]:
        return {
            "phases": [
                {
                    "phase": "Phase 1",
                    "title": "Feedback-complete product loop",
                    "status": "implemented_locally",
                    "items": [
                        "Thumbs-up and thumbs-down suggestion feedback",
                        "Accepted, rejected, and preferred variant labels",
                        "Feedback summaries by workspace or domain",
                    ],
                },
                {
                    "phase": "Phase 2",
                    "title": "Explainable auto-learning ranker",
                    "status": "implemented_locally",
                    "items": [
                        "Stored ranking weights",
                        "Free/local heuristic learning from feedback and A/B records",
                        "Reset, recommend, and persist learning endpoints",
                    ],
                },
                {
                    "phase": "Phase 3",
                    "title": "Production architecture foundation",
                    "status": "implemented_without_paid_services",
                    "items": [
                        "Local observability records",
                        "Architecture readiness endpoint",
                        "No-login, no-subscription deployment path",
                    ],
                },
            ],
            "removed_or_avoided_paid_parts": [
                "No hosted APM dependency",
                "No paid feature flag service",
                "No managed queue requirement",
                "No paid model-training API",
                "No login/auth implementation",
            ],
        }

    def recommended_next_steps(self, *, score: int, mockup_health: dict[str, Any]) -> list[str]:
        steps = []
        if score < 100:
            steps.append("Run one analysis and one feedback event to populate local storage and learning signals.")
        if not bool(mockup_health.get("available", False)):
            steps.append("Visual previews are optional. CPU mode stays in concept mode for free/local operation.")
        steps.append("After frontend integration, use /api/learning/status to show the learning state in the UI.")
        steps.append("Use /api/architecture/status for the production-readiness panel.")
        return steps

    def _check(self, key: str, ok: bool, detail: str) -> dict[str, Any]:
        return {"key": key, "ok": bool(ok), "detail": detail}

    def _count_files(self, path: Path) -> int:
        if not path.exists():
            return 0
        return sum(1 for item in path.rglob("*") if item.is_file())

    def _table_counts(self, db_path: Path) -> dict[str, int]:
        if not db_path.exists():
            return {}
        tables = ["reports", "analysis_traces", "feedback_events", "feedback_labels", "ranking_weights", "ab_test_results", "watchlists"]
        counts: dict[str, int] = {}
        try:
            conn = sqlite3.connect(db_path)
            try:
                for table in tables:
                    try:
                        row = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()
                        counts[table] = int(row[0] if row else 0)
                    except Exception:
                        counts[table] = 0
            finally:
                conn.close()
        except Exception:
            return {}
        return counts


production_architecture_service = ProductionArchitectureService()
