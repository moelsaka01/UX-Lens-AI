from __future__ import annotations

from typing import Any

from app.schemas import Suggestion
from app.services.feature_store_service import feature_store_service
from app.services.model_registry_service import model_registry_service


class LearningModelService:
    def __init__(self) -> None:
        self._model: Any = None
        self._model_path: str = ""

    def available(self) -> bool:
        return model_registry_service.latest_model_path() is not None

    def status(self) -> dict[str, Any]:
        registry = model_registry_service.read_registry()
        return {
            "available": self.available(),
            "registry": registry,
        }

    def _load_model(self) -> Any:
        model_path = model_registry_service.latest_model_path()
        if model_path is None:
            return None

        if self._model is not None and self._model_path == str(model_path):
            return self._model

        try:
            import joblib

            self._model = joblib.load(model_path)
            self._model_path = str(model_path)
            return self._model
        except Exception as exc:
            print(f"[WARN] Failed to load ranking ML model: {exc}")
            self._model = None
            self._model_path = ""
            return None

    def predict_score(self, suggestion: Suggestion) -> float | None:
        model = self._load_model()
        if model is None:
            return None

        features = feature_store_service.features_from_suggestion(suggestion)
        vector = feature_store_service.vectorize(features)

        try:
            prediction = model.predict([vector])[0]
            return float(max(0.0, min(100.0, prediction)))
        except Exception as exc:
            print(f"[WARN] Ranking ML prediction failed: {exc}")
            return None


learning_model_service = LearningModelService()