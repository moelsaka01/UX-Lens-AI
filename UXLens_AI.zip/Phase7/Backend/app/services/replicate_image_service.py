from __future__ import annotations

import time
import uuid
from pathlib import Path
from typing import Any

import requests

from app.config import settings


class ReplicateImageService:
    def __init__(self) -> None:
        self.api_token = str(getattr(settings, "replicate_api_token", "") or "").strip()
        self.model = str(
            getattr(settings, "replicate_model", "black-forest-labs/flux-schnell")
            or "black-forest-labs/flux-schnell"
        )

    def available(self) -> bool:
        return bool(self.api_token)

    def generate_image(self, prompt: str, variation_index: int = 0) -> str:
        if not self.available():
            print("[ReplicateImageService] REPLICATE_API_TOKEN is missing.")
            return ""

        try:
            import replicate

            start = time.perf_counter()

            final_prompt = (
                "A realistic high-quality website redesign screenshot. "
                "Modern premium SaaS or commerce landing page UI. "
                "Clean navigation, strong hero section, realistic spacing, clear CTA hierarchy, "
                "polished typography, realistic website composition, professional product design. "
                "No browser chrome, no phone frame, no watermark, no distorted text, no messy layout. "
                f"Redesign brief: {prompt}"
            )

            output: Any = replicate.run(
                self.model,
                input={
                    "prompt": final_prompt,
                    "go_fast": True,
                    "megapixels": "1",
                    "num_outputs": 1,
                    "aspect_ratio": "16:9",
                    "output_format": "png",
                    "output_quality": 90,
                    "num_inference_steps": 4,
                },
            )

            image_url = self._extract_output_url(output)
            if not image_url:
                print("[ReplicateImageService] No image URL returned.")
                return ""

            response = requests.get(image_url, timeout=120)
            response.raise_for_status()

            filename = f"{uuid.uuid4().hex}.png"
            output_dir = Path(settings.mockup_dir)
            output_dir.mkdir(parents=True, exist_ok=True)

            output_path = output_dir / filename
            output_path.write_bytes(response.content)

            elapsed = round(time.perf_counter() - start, 3)
            print(f"[ReplicateImageService] FLUX image saved to {output_path} elapsed_seconds={elapsed}")

            return f"/static/generated/mockups/{filename}"

        except Exception as exc:
            print(f"[ReplicateImageService] Image generation failed: {exc}")
            return ""

    def _extract_output_url(self, output: Any) -> str:
        if isinstance(output, str):
            return output

        if isinstance(output, list) and output:
            first = output[0]
            if isinstance(first, str):
                return first
            if hasattr(first, "url"):
                return str(first.url)

        if hasattr(output, "url"):
            return str(output.url)

        return ""


replicate_image_service = ReplicateImageService()