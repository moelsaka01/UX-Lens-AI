from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from app.config import settings


class ModelRegistryService:
    def __init__(self) -> None:
        self.model_dir = Path(settings.base_dir) / "models" / "ranker"
        self.model_dir.mkdir(parents=True, exist_ok=True)
        self.registry_path = self.model_dir / "registry.json"

    def latest_model_path(self) -> Path | None:
        registry = self.read_registry()
        path = registry.get("latest_model_path")
        if not path:
            return None

        candidate = Path(path)
        return candidate if candidate.exists() else None

    def read_registry(self) -> dict[str, Any]:
        if not self.registry_path.exists():
            return {
                "available": False,
                "latest_model_path": "",
                "latest_metadata": {},
                "models": [],
            }

        try:
            return json.loads(self.registry_path.read_text(encoding="utf-8"))
        except Exception:
            return {
                "available": False,
                "latest_model_path": "",
                "latest_metadata": {},
                "models": [],
            }

    def register_model(self, *, model_path: Path, metadata: dict[str, Any]) -> dict[str, Any]:
        registry = self.read_registry()
        models = list(registry.get("models") or [])

        record = {
            "model_path": str(model_path),
            "registered_at": datetime.now(UTC).isoformat(),
            "metadata": metadata,
        }

        models.append(record)

        next_registry = {
            "available": True,
            "latest_model_path": str(model_path),
            "latest_metadata": metadata,
            "models": models[-20:],
        }

        self.registry_path.write_text(
            json.dumps(next_registry, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

        return next_registry


model_registry_service = ModelRegistryService()