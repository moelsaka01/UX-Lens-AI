from __future__ import annotations

import hashlib
import textwrap
import time
import uuid
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFont

from app.config import settings
from app.services.replicate_image_service import replicate_image_service

class LocalImageService:
    def __init__(self) -> None:
        self.available = True
        self.device = "renderer"
        self.init_error = ""

    def health(self) -> dict[str, Any]:
        provider = str(getattr(settings, "image_provider", "renderer") or "renderer").lower()

        return {
            "available": True,
            "enabled": bool(getattr(settings, "enable_mockup_generation", True)),
            "device": "external" if provider == "replicate" else "renderer",
            "mode": provider,
            "ui_mode": "visual_previews",
            "model": (
                str(getattr(settings, "replicate_model", "black-forest-labs/flux-schnell"))
                if provider == "replicate"
                else "deterministic-screenshot-to-design-renderer"
            ),
            "error": self.init_error,
            "reason": self.init_error,
        }

    def generate_mockup(self, prompt: str, variation_index: int = 0, mode: str = "renderer") -> str:
        normalized_mode = str(mode or "renderer").strip().lower()

        if normalized_mode == "image":
            print("[LocalImageService] Replicate FLUX AI image generation requested.")

            image_url = replicate_image_service.generate_image(
                prompt=self._build_ai_prompt(prompt),
                variation_index=variation_index,
            )

            if image_url:
                self.init_error = ""
                return image_url

            self.init_error = "Replicate returned no image. Falling back to local renderer."
            print(f"[LocalImageService] {self.init_error}")

        print("[LocalImageService] Local renderer preview requested.")
        return self._generate_renderer_preview(prompt, variation_index)

    def _build_ai_prompt(self, prompt: str) -> str:
        cleaned = " ".join(str(prompt or "").split())

        return (
            "Create a realistic high-quality website redesign screenshot. "
            "It should look like a real polished modern SaaS, ecommerce, or product landing page. "
            "Use clean spacing, realistic sections, a believable navigation bar, a strong hero section, "
            "credible CTA hierarchy, premium typography, and a professional visual system. "
            "Do not include browser chrome, phone frames, fake app windows, distorted text, random logos, "
            "abstract poster art, surreal UI, or unreadable paragraph blocks. "
            f"Redesign brief: {cleaned}"
        )

    def _font(self, size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
        candidates = [
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
            if bold
            else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
            "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"
            if bold
            else "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
        ]

        for path in candidates:
            try:
                return ImageFont.truetype(path, size)
            except Exception:
                pass

        return ImageFont.load_default()

    def _wrap(self, text: str, width: int) -> list[str]:
        cleaned = " ".join(str(text or "").split())
        if not cleaned:
            return []
        return textwrap.wrap(cleaned, width=width)

    def _extract_title(self, prompt: str) -> str:
        text = " ".join(str(prompt or "").split())
        if not text:
            return "Clearer hierarchy, stronger action path"

        first = text
        for sep in [".", ":", "-", "|"]:
            if sep in first:
                first = first.split(sep)[0]

        first = first.strip()
        if len(first) < 12:
            first = "Clearer hierarchy, stronger action path"

        return first[:72]

    def _extract_body(self, prompt: str) -> str:
        text = " ".join(str(prompt or "").split())
        if not text:
            return (
                "A cleaner visual direction with stronger hierarchy, clearer action priority, "
                "and reduced first-screen friction."
            )

        return text[:220]

    def _palette(self, prompt: str) -> dict[str, tuple[int, int, int]]:
        digest = hashlib.sha256(str(prompt or "").encode("utf-8")).hexdigest()
        hue_seed = int(digest[:2], 16)

        if hue_seed % 3 == 0:
            accent = (139, 246, 204)
            accent_2 = (94, 234, 212)
        elif hue_seed % 3 == 1:
            accent = (151, 210, 255)
            accent_2 = (126, 181, 255)
        else:
            accent = (248, 214, 137)
            accent_2 = (245, 190, 110)

        return {
            "bg": (5, 11, 15),
            "panel": (12, 24, 30),
            "panel_2": (17, 34, 41),
            "card": (9, 18, 23),
            "border": (51, 83, 78),
            "text": (244, 248, 245),
            "muted": (173, 190, 186),
            "accent": accent,
            "accent_2": accent_2,
            "dark": (3, 8, 11),
        }

    def _rounded_rect(
        self,
        draw: ImageDraw.ImageDraw,
        box: tuple[int, int, int, int],
        radius: int,
        fill: tuple[int, int, int] | tuple[int, int, int, int],
        outline: tuple[int, int, int] | tuple[int, int, int, int] | None = None,
        width: int = 1,
    ) -> None:
        draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)

    def _draw_button(
        self,
        draw: ImageDraw.ImageDraw,
        box: tuple[int, int, int, int],
        text: str,
        colors: dict[str, tuple[int, int, int]],
        primary: bool = True,
    ) -> None:
        fill = colors["accent"] if primary else colors["panel_2"]
        text_color = colors["dark"] if primary else colors["text"]
        outline = colors["accent_2"] if primary else colors["border"]

        self._rounded_rect(draw, box, 999, fill, outline, 1)

        font = self._font(18, True)
        bbox = draw.textbbox((0, 0), text, font=font)
        tx = box[0] + ((box[2] - box[0]) - (bbox[2] - bbox[0])) / 2
        ty = box[1] + ((box[3] - box[1]) - (bbox[3] - bbox[1])) / 2 - 1
        draw.text((tx, ty), text, fill=text_color, font=font)

    def _draw_metric_card(
        self,
        draw: ImageDraw.ImageDraw,
        box: tuple[int, int, int, int],
        label: str,
        value: str,
        colors: dict[str, tuple[int, int, int]],
    ) -> None:
        self._rounded_rect(draw, box, 22, colors["panel"], colors["border"], 1)

        draw.text((box[0] + 20, box[1] + 18), label, fill=colors["muted"], font=self._font(18, True))
        draw.text((box[0] + 20, box[1] + 50), value, fill=colors["text"], font=self._font(34, True))

        track = (box[0] + 20, box[3] - 22, box[2] - 20, box[3] - 14)
        self._rounded_rect(draw, track, 999, (30, 43, 48), None)
        fill_w = int((track[2] - track[0]) * 0.78)
        self._rounded_rect(
            draw,
            (track[0], track[1], track[0] + fill_w, track[3]),
            999,
            colors["accent_2"],
            None,
        )

    def _generate_renderer_preview(self, prompt: str, variation_index: int = 0) -> str:
        start = time.perf_counter()

        width = int(getattr(settings, "mockup_width", 1280) or 1280)
        height = int(getattr(settings, "mockup_height", 900) or 900)

        width = max(1280, width)
        height = max(900, height)

        colors = self._palette(f"{prompt}-{variation_index}")
        title = self._extract_title(prompt)
        body = self._extract_body(prompt)

        img = Image.new("RGB", (width, height), colors["bg"]).convert("RGBA")
        overlay = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)

        margin = 42

        self._rounded_rect(
            draw,
            (margin, margin, width - margin, height - margin),
            32,
            (*colors["panel"], 235),
            colors["border"],
            2,
        )

        nav_y = margin + 58
        draw.text((margin + 42, nav_y), "UXLens", fill=colors["text"], font=self._font(26, True))

        nav_items = ["Overview", "Product", "Proof", "Pricing"]
        nx = margin + 185
        for item in nav_items:
            draw.text((nx, nav_y + 7), item, fill=colors["muted"], font=self._font(16, True))
            nx += 112

        self._draw_button(
            draw,
            (width - margin - 218, nav_y - 8, width - margin - 42, nav_y + 42),
            "Primary CTA",
            colors,
            primary=True,
        )

        hero = (margin + 42, margin + 142, width - margin - 42, margin + 505)
        self._rounded_rect(draw, hero, 30, (*colors["card"], 240), colors["border"], 1)

        draw.text(
            (hero[0] + 36, hero[1] + 34),
            "AI OPTIMIZED REDESIGN",
            fill=colors["accent"],
            font=self._font(17, True),
        )

        y = hero[1] + 76
        for line in self._wrap(title, 36)[:2]:
            draw.text((hero[0] + 36, y), line, fill=colors["text"], font=self._font(48, True))
            y += 56

        y += 10
        for line in self._wrap(body, 82)[:3]:
            draw.text((hero[0] + 38, y), line, fill=colors["muted"], font=self._font(22))
            y += 31

        button_y = hero[3] - 88
        self._draw_button(draw, (hero[0] + 36, button_y, hero[0] + 186, button_y + 50), "Start now", colors, True)
        self._draw_button(draw, (hero[0] + 204, button_y, hero[0] + 370, button_y + 50), "Learn more", colors, False)

        side_panel = (width - margin - 370, hero[1] + 42, width - margin - 78, hero[3] - 42)
        self._rounded_rect(draw, side_panel, 24, (*colors["panel_2"], 220), colors["border"], 1)

        for i in range(5):
            yy = side_panel[1] + 36 + i * 42
            draw.rounded_rectangle(
                (side_panel[0] + 26, yy, side_panel[2] - 28 - i * 18, yy + 16),
                radius=8,
                fill=(*colors["accent"], 150 if i == 0 else 80),
            )

        metric_y = margin + 540
        gap = 18
        metric_w = (width - margin * 2 - 42 * 2 - gap * 3) // 4

        metric_items = [
            ("UX clarity", "92"),
            ("CTA focus", "88"),
            ("Scan speed", "84"),
            ("Trust feel", "91"),
        ]

        x = margin + 42
        for label, value in metric_items:
            self._draw_metric_card(draw, (x, metric_y, x + metric_w, metric_y + 132), label, value, colors)
            x += metric_w + gap

        lower_y = metric_y + 164
        card_gap = 22
        card_w = (width - margin * 2 - 42 * 2 - card_gap * 2) // 3

        x = margin + 42
        for label in ["Cleaner hierarchy", "Sharper CTA path", "Reduced visual noise"]:
            box = (x, lower_y, x + card_w, height - margin - 38)
            self._rounded_rect(draw, box, 24, (*colors["panel"], 218), colors["border"], 1)
            draw.text((box[0] + 24, box[1] + 24), label, fill=colors["text"], font=self._font(22, True))

            for i in range(3):
                yy = box[1] + 70 + i * 34
                draw.rounded_rectangle(
                    (box[0] + 24, yy, box[2] - 26 - i * 28, yy + 13),
                    radius=8,
                    fill=(*colors["muted"], 85),
                )

            x += card_w + card_gap

        img = Image.alpha_composite(img, overlay).convert("RGB")

        filename = f"{uuid.uuid4().hex}.png"
        output_dir = Path(settings.mockup_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        output_path = output_dir / filename
        img.save(output_path, quality=95)

        elapsed = round(time.perf_counter() - start, 3)
        print(f"[LocalImageService] Renderer preview saved to {output_path} elapsed_seconds={elapsed}")

        return f"/static/generated/mockups/{filename}"


local_image_service = LocalImageService()