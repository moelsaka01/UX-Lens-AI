from __future__ import annotations

from app.schemas import DesignPatternClassifierOutput, DesignPatternPrediction, ExtractedSignals


class DesignPatternService:
    def classify(
        self,
        *,
        normalized_url: str,
        signals: ExtractedSignals,
        metrics: dict,
        inferred_archetype: str,
    ) -> DesignPatternClassifierOutput:
        title = (signals.title or "").lower()
        h1 = (signals.h1 or "").lower()
        meta_description = (signals.meta_description or "").lower()
        primary_cta = (signals.primary_cta_label or "").lower()
        url_blob = (normalized_url or "").lower()

        query_blob = " ".join(
            [
                url_blob,
                title,
                h1,
                meta_description,
                primary_cta,
            ]
        )

        nav_items = int(signals.nav_item_count or 0)
        hero_words = int(signals.hero_text_length or 0)
        cta_count = int(signals.cta_above_fold_count or 0)
        strong_cta_count = int(signals.strong_cta_above_fold_count or 0)
        form_count = int(signals.form_count or 0)
        section_count = int(signals.section_count or 0)
        image_count = int(signals.image_count or 0)
        above_fold_nodes = int(signals.above_fold_nodes or 0)
        word_count = int(signals.word_count or 0)

        candidates: list[DesignPatternPrediction] = []

        def add_candidate(label: str, family: str, confidence: float, rationale: str) -> None:
            candidates.append(
                DesignPatternPrediction(
                    label=label,
                    family=family,
                    confidence=round(max(0.0, min(0.99, confidence)), 3),
                    rationale=rationale,
                    source="hybrid",
                )
            )

        def has_any(*terms: str) -> bool:
            return any(term in query_blob for term in terms)

        def cta_language_is_sales_like() -> bool:
            return any(
                term in primary_cta
                for term in [
                    "buy",
                    "shop",
                    "add to cart",
                    "pre-order",
                    "order",
                    "see pricing",
                    "request demo",
                    "book demo",
                    "start free",
                    "sign up",
                    "get started",
                ]
            )

        def likely_hardware_launch() -> bool:
            return has_any(
                "iphone",
                "ipad",
                "mac",
                "macbook",
                "watch",
                "airpods",
                "vision",
                "apple",
            )

        def likely_enterprise_saas() -> bool:
            return has_any(
                "pricing",
                "platform",
                "enterprise",
                "request demo",
                "book demo",
                "start free",
                "free trial",
                "workspace",
                "teams",
                "automation",
                "software",
            )

        def likely_marketplace_commerce() -> bool:
            return has_any(
                "shop",
                "buy",
                "store",
                "cart",
                "category",
                "deals",
                "collection",
                "checkout",
                "product",
            )

        def likely_docs() -> bool:
            return has_any(
                "docs",
                "documentation",
                "api",
                "guide",
                "reference",
                "sdk",
                "developer",
            )

        def likely_editorial() -> bool:
            return has_any(
                "blog",
                "article",
                "press",
                "news",
                "story",
                "insights",
            )

        def likely_dashboard() -> bool:
            return has_any(
                "dashboard",
                "analytics",
                "workspace",
                "reports",
                "metrics",
                "overview",
                "admin",
            )

        if likely_hardware_launch():
            confidence = 0.86
            if image_count >= 8:
                confidence += 0.03
            if hero_words <= 120:
                confidence += 0.02
            if nav_items <= 10:
                confidence += 0.01

            add_candidate(
                "Consumer Hardware Product Hero",
                "commerce",
                confidence,
                (
                    "Brand and product language strongly resembles a flagship hardware launch page, "
                    "with a visually led hero pattern and strong product-first merchandising cues."
                ),
            )

        if likely_enterprise_saas():
            confidence = 0.82
            if form_count > 0:
                confidence += 0.03
            if cta_language_is_sales_like():
                confidence += 0.02
            if section_count >= 5:
                confidence += 0.01

            add_candidate(
                "Enterprise SaaS Product Marketing",
                "saas",
                confidence,
                (
                    "The page language emphasizes software value framing, product explanation, and conversion intent, "
                    "which aligns with enterprise SaaS marketing structures."
                ),
            )

        if likely_marketplace_commerce():
            confidence = 0.79
            if image_count >= 12:
                confidence += 0.03
            if nav_items >= 10:
                confidence += 0.02
            if cta_language_is_sales_like():
                confidence += 0.02

            add_candidate(
                "Marketplace Commerce Discovery",
                "commerce",
                confidence,
                (
                    "Shopping and merchandising language suggests a commerce discovery pattern, "
                    "with product browsing and action-driven navigation expectations."
                ),
            )

        if likely_docs():
            confidence = 0.82
            if nav_items >= 8:
                confidence += 0.01
            if word_count >= 900:
                confidence += 0.02
            if cta_count <= 2:
                confidence += 0.01

            add_candidate(
                "Documentation Index",
                "docs",
                confidence,
                (
                    "Documentation-oriented terminology indicates a findability-first structure, "
                    "where navigation clarity and information access matter more than aggressive conversion."
                ),
            )

        if likely_editorial():
            confidence = 0.79
            if word_count >= 1200:
                confidence += 0.03
            if cta_count <= 2:
                confidence += 0.01
            if hero_words >= 120:
                confidence += 0.01

            add_candidate(
                "Editorial Content",
                "content",
                confidence,
                (
                    "Content-oriented keywords and heavier reading structure suggest an editorial pattern, "
                    "with reading rhythm and narrative flow taking priority over strong conversion prompts."
                ),
            )

        if likely_dashboard():
            confidence = 0.77
            if nav_items >= 6:
                confidence += 0.02
            if above_fold_nodes >= 180:
                confidence += 0.01

            add_candidate(
                "Analytics Dashboard",
                "dashboard",
                confidence,
                (
                    "Workspace and analytics terminology suggests a dashboard-oriented interface, "
                    "where density and utility cues matter more than landing-page persuasion patterns."
                ),
            )

        # Structure-based fallback candidates even when text cues are weak.
        if not candidates:
            if inferred_archetype == "commerce":
                confidence = 0.72
                if image_count >= 10:
                    confidence += 0.03
                if nav_items >= 10:
                    confidence += 0.02
                add_candidate(
                    "Consumer Product Marketing",
                    "commerce",
                    confidence,
                    (
                        "Pattern inferred from commerce-like structure, including stronger product visibility, "
                        "denser merchandising cues, and a transaction-oriented page setup."
                    ),
                )

            elif inferred_archetype == "saas":
                confidence = 0.74
                if form_count > 0:
                    confidence += 0.02
                if strong_cta_count >= 1:
                    confidence += 0.01
                add_candidate(
                    "Enterprise SaaS Product Marketing",
                    "saas",
                    confidence,
                    (
                        "Pattern inferred from SaaS-style conversion structure, including product explanation, "
                        "proof sections, and a stronger trial or demo-oriented CTA path."
                    ),
                )

            elif inferred_archetype == "docs":
                add_candidate(
                    "Documentation Index",
                    "docs",
                    0.79,
                    (
                        "Primary pattern inferred from a documentation-style information structure, "
                        "where navigation and scan efficiency dominate the experience."
                    ),
                )

            elif inferred_archetype == "content":
                add_candidate(
                    "Editorial Content",
                    "content",
                    0.77,
                    (
                        "Primary pattern inferred from a reading-oriented structure, "
                        "with heavier copy, lower action intensity, and a content-led page rhythm."
                    ),
                )

            elif inferred_archetype == "dashboard":
                add_candidate(
                    "Analytics Dashboard",
                    "dashboard",
                    0.75,
                    (
                        "Primary pattern inferred from an interface-led layout, "
                        "with utility density and workspace-style structure."
                    ),
                )

            else:
                confidence = 0.71
                if cta_count >= 2:
                    confidence += 0.01
                if hero_words <= 160:
                    confidence += 0.01
                add_candidate(
                    "Brand Marketing Landing Page",
                    "marketing",
                    confidence,
                    (
                        "Primary pattern inferred from a general marketing layout, "
                        "with hero-led messaging, conversion intent, and broad brand storytelling cues."
                    ),
                )

        # Add a secondary archetype-aware fallback when candidate diversity is too low.
        if len(candidates) == 1:
            if inferred_archetype == "marketing":
                add_candidate(
                    "Conversion-Focused Marketing Landing Page",
                    "marketing",
                    max(0.58, candidates[0].confidence - 0.08),
                    (
                        "Secondary candidate added from structural landing-page cues such as hero emphasis, "
                        "CTA exposure, and modular persuasion sections."
                    ),
                )
            elif inferred_archetype == "commerce":
                add_candidate(
                    "Commerce Product Storytelling",
                    "commerce",
                    max(0.58, candidates[0].confidence - 0.08),
                    (
                        "Secondary candidate added from product-led layout cues such as imagery, "
                        "merchandising structure, and purchase-oriented actions."
                    ),
                )
            elif inferred_archetype == "saas":
                add_candidate(
                    "PLG SaaS Landing Page",
                    "saas",
                    max(0.58, candidates[0].confidence - 0.08),
                    (
                        "Secondary candidate added from software marketing structure, "
                        "especially where trial or demo actions shape the page flow."
                    ),
                )

        candidates.sort(key=lambda item: item.confidence, reverse=True)
        primary = candidates[0]

        rationale = primary.rationale
        if len(candidates) > 1:
            second = candidates[1]
            rationale = (
                f"{primary.rationale} Secondary nearby pattern: '{second.label}' "
                f"at confidence {round(second.confidence, 3)}."
            )

        return DesignPatternClassifierOutput(
            primary_pattern=primary.label,
            primary_family=primary.family,
            confidence=primary.confidence,
            rationale=rationale,
            model_name="hybrid_heuristic_pattern_classifier_v2",
            model_type="hybrid",
            candidates=candidates[:5],
        )


design_pattern_service = DesignPatternService()