from __future__ import annotations

from typing import Optional, Tuple
from uuid import uuid4

from app.config import settings

try:
    from playwright.async_api import async_playwright
except Exception:
    async_playwright = None


class ScreenshotService:
    async def capture_url(self, url: str, mobile: bool = False) -> Tuple[Optional[str], Optional[str]]:
        """
        Capture screenshots using Playwright.
        Fail loudly so the real backend error is visible instead of returning a fake fallback image.
        """

        if async_playwright is None:
            raise RuntimeError("Playwright is not installed or failed to import.")

        try:
            return await self._capture_with_playwright(url, mobile)
        except Exception as exc:
            print(f"[ERROR] Playwright screenshot failed for {url} (mobile={mobile}): {exc}")
            raise

    async def _capture_with_playwright(self, url: str, mobile: bool = False) -> Tuple[str, str]:
        filename = f"{uuid4().hex}_{'mobile' if mobile else 'desktop'}.png"
        full_filename = f"{uuid4().hex}_{'mobile' if mobile else 'desktop'}_full.png"

        output_path = settings.screenshot_dir / filename
        full_output_path = settings.screenshot_dir / full_filename

        viewport = {"width": 430, "height": 932} if mobile else {"width": 1440, "height": 1024}

        user_agent = None
        if mobile:
            user_agent = (
                "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) "
                "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1"
            )

        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)

            context = await browser.new_context(
                viewport=viewport,
                user_agent=user_agent,
                is_mobile=mobile,
                has_touch=mobile,
                device_scale_factor=1,
            )

            page = await context.new_page()

            print(f"[INFO] Navigating to {url} (mobile={mobile})")
            await page.goto(url, wait_until="networkidle", timeout=30000)

            print(f"[INFO] Capturing screenshots for {url} (mobile={mobile})")

            await page.screenshot(
                path=str(output_path),
                full_page=False,
            )

            await page.screenshot(
                path=str(full_output_path),
                full_page=True,
            )

            await browser.close()

        print(f"[SUCCESS] Screenshots saved for {url}")

        return (
            f"/static/generated/{filename}",
            f"/static/generated/{full_filename}",
        )


screenshot_service = ScreenshotService()