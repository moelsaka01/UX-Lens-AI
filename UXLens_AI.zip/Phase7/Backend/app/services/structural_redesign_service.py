from __future__ import annotations

from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw

from app.config import settings


class StructuralRedesignService:
    def simulate_transformation(
        self,
        *,
        suggestion: Any,
        scores: Any,
        extracted_signals: Any,
    ) -> dict[str, Any]:
        title = str(getattr(suggestion, "title", "")).lower()

        before = {
            "nav_items": int(getattr(extracted_signals, "nav_item_count", 0) or 0),
            "cta_visibility": int(getattr(scores, "cta_visibility", 0) or 0),
            "attention_focus": int(getattr(scores, "attention_focus", 0) or 0),
        }

        after = dict(before)

        if "navigation" in title or "header" in title or "nav" in title:
            after["nav_items"] = max(6, before["nav_items"] - 10)
            after["attention_focus"] = min(95, before["attention_focus"] + 7)
            after["cta_visibility"] = max(0, min(100, before["cta_visibility"] - 2))

        elif "cta" in title:
            after["cta_visibility"] = min(98, before["cta_visibility"] + 8)
            after["attention_focus"] = min(95, before["attention_focus"] + 3)

        elif "hero" in title or "copy" in title:
            after["attention_focus"] = min(95, before["attention_focus"] + 5)

        else:
            after["attention_focus"] = min(95, before["attention_focus"] + 4)

        deltas = {
            key: int(after[key] - before[key])
            for key in before.keys()
        }

        return {
            "before": before,
            "after": after,
            "deltas": deltas,
        }

    def build_overlay_regions(
        self,
        *,
        extracted_signals: Any,
        suggestion: Any,
        image_width: int,
        image_height: int,
    ) -> list[dict[str, Any]]:
        extra = getattr(extracted_signals, "extra", {}) or {}
        title = str(getattr(suggestion, "title", "")).lower()

        if "dom_regions" in extra and isinstance(extra["dom_regions"], list) and extra["dom_regions"]:
            return [
                self._normalize_region(region, image_width=image_width, image_height=image_height)
                for region in extra["dom_regions"][:6]
            ]

        if "navigation" in title or "header" in title or "nav" in title:
            return [
                {
                    "label": "header_simplification_zone",
                    "x": int(image_width * 0.20),
                    "y": int(image_height * 0.60),
                    "w": int(image_width * 0.40),
                    "h": int(image_height * 0.12),
                    "tone": "accent",
                }
            ]

        if "cta" in title:
            return [
                {
                    "label": "cta_emphasis_zone",
                    "x": int(image_width * 0.38),
                    "y": int(image_height * 0.28),
                    "w": int(image_width * 0.18),
                    "h": int(image_height * 0.10),
                    "tone": "accent",
                }
            ]

        return [
            {
                "label": "focus_zone",
                "x": int(image_width * 0.32),
                "y": int(image_height * 0.30),
                "w": int(image_width * 0.36),
                "h": int(image_height * 0.16),
                "tone": "accent",
            }
        ]

    def generate_overlay_image(
        self,
        *,
        screenshot_static_path: str | None,
        extracted_signals: Any,
        suggestion: Any,
    ) -> str | None:
        source = self._resolve_static_path(screenshot_static_path)
        if source is None or not source.exists():
            return None

        image = Image.open(source).convert("RGBA")
        draw = ImageDraw.Draw(image)

        regions = self.build_overlay_regions(
            extracted_signals=extracted_signals,
            suggestion=suggestion,
            image_width=image.width,
            image_height=image.height,
        )

        overlay_fill = (0, 0, 0, 88)
        image = Image.alpha_composite(
            image,
            Image.new("RGBA", image.size, overlay_fill),
        )
        draw = ImageDraw.Draw(image)

        for region in regions:
            x = int(region["x"])
            y = int(region["y"])
            w = int(region["w"])
            h = int(region["h"])
            draw.rectangle(
                [(x, y), (x + w, y + h)],
                outline=(37, 255, 214, 255),
                width=4,
            )

        output_name = f"{source.stem}_overlay.png"
        output_path = settings.screenshot_dir / output_name
        image.convert("RGB").save(output_path)
        return f"/static/generated/{output_name}"

    def _resolve_static_path(self, static_path: str | None) -> Path | None:
        if not static_path:
            return None
        filename = Path(static_path).name
        candidate = settings.screenshot_dir / filename
        return candidate if candidate.exists() else None

    def _normalize_region(
        self,
        region: dict[str, Any],
        *,
        image_width: int,
        image_height: int,
    ) -> dict[str, Any]:
        return {
            "label": str(region.get("label", "region")),
            "x": max(0, min(image_width - 1, int(region.get("x", 0)))),
            "y": max(0, min(image_height - 1, int(region.get("y", 0)))),
            "w": max(1, min(image_width, int(region.get("w", 1)))),
            "h": max(1, min(image_height, int(region.get("h", 1)))),
            "tone": str(region.get("tone", "accent")),
        }


structural_redesign_service = StructuralRedesignService()