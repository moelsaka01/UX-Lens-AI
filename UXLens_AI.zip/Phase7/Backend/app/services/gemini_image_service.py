from __future__ import annotations

import uuid
from pathlib import Path

from google import genai
from google.genai import types

from app.config import settings


class GeminiImageService:
    def __init__(self) -> None:
        self.api_key = getattr(settings, "gemini_api_key", "") or ""
        self.model = (
            getattr(settings, "gemini_image_model", "gemini-2.5-flash-image")
            or "gemini-2.5-flash-image"
        )

    def available(self) -> bool:
        return bool(self.api_key)

    def generate_image(self, prompt: str, variation_index: int = 0) -> str:
        if not self.available():
            print("[GeminiImageService] GEMINI_API_KEY is missing.")
            return ""

        try:
            client = genai.Client(api_key=self.api_key)

            response = client.models.generate_content(
                model=self.model,
                contents=[
                    types.Content(
                        role="user",
                        parts=[
                            types.Part.from_text(
                                text=(
                                    "Create a realistic, high-quality website redesign preview image. "
                                    "Make it look like a polished modern SaaS or commerce website screenshot. "
                                    "Use clean spacing, realistic typography, real-looking UI sections, and strong visual hierarchy. "
                                    "No browser chrome, no phone frame, no distorted UI, no unreadable fake text blocks. "
                                    f"Redesign brief: {prompt}"
                                )
                            )
                        ],
                    )
                ],
            )

            for candidate in response.candidates or []:
                content = getattr(candidate, "content", None)
                if not content:
                    continue

                for part in content.parts or []:
                    inline_data = getattr(part, "inline_data", None)
                    if inline_data and inline_data.data:
                        filename = f"{uuid.uuid4().hex}.png"
                        output_dir = Path(settings.mockup_dir)
                        output_dir.mkdir(parents=True, exist_ok=True)

                        output_path = output_dir / filename
                        output_path.write_bytes(inline_data.data)

                        print(f"[GeminiImageService] Image saved to {output_path}")
                        return f"/static/generated/mockups/{filename}"

            print("[GeminiImageService] Gemini returned no image data.")
            return ""

        except Exception as exc:
            print(f"[GeminiImageService] Image generation failed: {exc}")
            return ""


gemini_image_service = GeminiImageService()