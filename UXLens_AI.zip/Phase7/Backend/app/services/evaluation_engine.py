from __future__ import annotations

from typing import Any

from app.schemas import ExtractedSignals, FeedbackSummary, LayoutSimilarity, ScoreBlock


class EvaluationEngine:
    def evaluate(
        self,
        *,
        scores: ScoreBlock,
        signals: ExtractedSignals,
        metrics: dict[str, Any],
        findings: list[Any],
        suggestions: list[Any],
        layout_similarity: LayoutSimilarity | None,
        feedback_summary: FeedbackSummary | None = None,
    ) -> dict[str, Any]:
        issue_breakdown = self._build_issue_breakdown(
            scores=scores,
            signals=signals,
            metrics=metrics,
            findings=findings,
            layout_similarity=layout_similarity,
            feedback_summary=feedback_summary,
        )

        priority = max(
            issue_breakdown,
            key=lambda item: item["pressure_score"],
            default={
                "key": "overall_ux",
                "pressure_score": max(0, 100 - scores.ux_score),
                "score": scores.ux_score,
                "reason": "Fallback priority based on overall UX score.",
            },
        )

        confidence = self._compute_confidence(
            scores=scores,
            signals=signals,
            findings=findings,
            suggestions=suggestions,
            layout_similarity=layout_similarity,
            feedback_summary=feedback_summary,
        )

        reasoning = self._build_reasoning(
            priority_issue=priority["key"],
            priority_reason=priority["reason"],
            priority_score=int(priority["pressure_score"]),
            scores=scores,
            signals=signals,
            findings=findings,
            suggestions=suggestions,
            layout_similarity=layout_similarity,
            feedback_summary=feedback_summary,
        )

        return {
            "confidence": round(confidence, 2),
            "priority_issue": priority["key"],
            "priority_score": int(priority["pressure_score"]),
            "priority_reason": priority["reason"],
            "reasoning": reasoning,
            "score_breakdown": {
                item["key"]: {
                    "score": int(item["score"]),
                    "pressure_score": int(item["pressure_score"]),
                    "reason": item["reason"],
                }
                for item in issue_breakdown
            },
            "issue_breakdown": issue_breakdown,
        }

    def _build_issue_breakdown(
        self,
        *,
        scores: ScoreBlock,
        signals: ExtractedSignals,
        metrics: dict[str, Any],
        findings: list[Any],
        layout_similarity: LayoutSimilarity | None,
        feedback_summary: FeedbackSummary | None,
    ) -> list[dict[str, Any]]:
        nav_items = int(signals.nav_item_count or 0)
        cta_count = int(signals.cta_above_fold_count or 0)
        hero_words = int(signals.hero_text_length or 0)
        above_fold_nodes = int(signals.above_fold_nodes or 0)
        avg_paragraph_words = float(signals.avg_paragraph_words or 0.0)
        layout_similarity_score = int(getattr(layout_similarity, "similarity", 0) or 0)

        items = [
            {
                "key": "attention_focus",
                "score": int(scores.attention_focus),
                "pressure_score": max(0, 100 - int(scores.attention_focus)),
                "reason": self._focus_reason(
                    above_fold_nodes=above_fold_nodes,
                    nav_items=nav_items,
                    hero_words=hero_words,
                ),
            },
            {
                "key": "cta_visibility",
                "score": int(scores.cta_visibility),
                "pressure_score": max(0, 100 - int(scores.cta_visibility)),
                "reason": self._cta_reason(
                    cta_count=cta_count,
                    primary_cta_label=signals.primary_cta_label,
                    weighted_cta=float(signals.weighted_cta_above_fold or 0.0),
                ),
            },
            {
                "key": "readability",
                "score": int(scores.readability),
                "pressure_score": max(0, 100 - int(scores.readability)),
                "reason": self._readability_reason(
                    hero_words=hero_words,
                    avg_paragraph_words=avg_paragraph_words,
                    heading_count=int(signals.heading_count or 0),
                ),
            },
            {
                "key": "cognitive_load",
                "score": int(scores.cognitive_load),
                "pressure_score": max(0, 100 - int(scores.cognitive_load)),
                "reason": self._cognitive_reason(
                    nav_items=nav_items,
                    above_fold_nodes=above_fold_nodes,
                    cta_count=cta_count,
                ),
            },
            {
                "key": "layout_similarity",
                "score": layout_similarity_score,
                "pressure_score": max(0, 100 - layout_similarity_score),
                "reason": self._layout_reason(layout_similarity),
            },
        ]

        top_finding_title = str(getattr(findings[0], "title", "") or "").lower() if findings else ""
        positive_feedback = int(getattr(feedback_summary, "positive_signals", 0) or 0) if feedback_summary else 0
        negative_feedback = int(getattr(feedback_summary, "negative_signals", 0) or 0) if feedback_summary else 0
        accepted_suggestions = int(getattr(feedback_summary, "accepted_suggestions", 0) or 0) if feedback_summary else 0
        rejected_suggestions = int(getattr(feedback_summary, "rejected_suggestions", 0) or 0) if feedback_summary else 0

        for item in items:
            key = item["key"]

            if key == "attention_focus":
                if above_fold_nodes > 280:
                    item["pressure_score"] += min(14, (above_fold_nodes - 280) // 10)
                if nav_items > 14:
                    item["pressure_score"] += min(8, nav_items - 14)
                if hero_words > 220:
                    item["pressure_score"] += min(6, (hero_words - 220) // 20 + 1)

            if key == "cta_visibility":
                if cta_count >= 4:
                    item["pressure_score"] += min(12, cta_count - 3)
                if not signals.primary_cta_label:
                    item["pressure_score"] += 8
                if float(signals.weighted_cta_above_fold or 0.0) < 2.0:
                    item["pressure_score"] += 5

            if key == "readability":
                if hero_words > 180:
                    item["pressure_score"] += min(10, (hero_words - 180) // 20 + 1)
                if avg_paragraph_words > 38:
                    item["pressure_score"] += 4
                if int(signals.heading_count or 0) < 2:
                    item["pressure_score"] += 4

            if key == "cognitive_load":
                if nav_items > 12:
                    item["pressure_score"] += min(12, nav_items - 12)
                if above_fold_nodes > 300:
                    item["pressure_score"] += min(8, (above_fold_nodes - 300) // 15 + 1)
                if cta_count > 3:
                    item["pressure_score"] += min(6, cta_count - 3)

            if key == "layout_similarity" and layout_similarity_score < 80:
                item["pressure_score"] += 6

            if key.replace("_", " ") in top_finding_title:
                item["pressure_score"] += 8

            if feedback_summary:
                if negative_feedback > positive_feedback:
                    item["pressure_score"] += min(6, negative_feedback - positive_feedback)
                if rejected_suggestions > accepted_suggestions:
                    item["pressure_score"] += min(4, rejected_suggestions - accepted_suggestions)

            item["pressure_score"] = max(0, min(100, int(item["pressure_score"])))

        return sorted(items, key=lambda item: item["pressure_score"], reverse=True)

    def _focus_reason(
        self,
        *,
        above_fold_nodes: int,
        nav_items: int,
        hero_words: int,
    ) -> str:
        reasons: list[str] = []

        if above_fold_nodes > 320:
            reasons.append(
                f"the opening viewport is structurally dense, with about {above_fold_nodes} visible elements competing at once"
            )
        elif above_fold_nodes > 280:
            reasons.append(
                f"the first screen carries {above_fold_nodes} visible elements, which is heavier than ideal for a clean focal path"
            )

        if nav_items > 16:
            reasons.append(
                f"navigation is unusually prominent at {nav_items} top-level choices, pulling attention away from the core message"
            )
        elif nav_items > 12:
            reasons.append(
                f"{nav_items} visible navigation choices add early branching before the user locks onto the hero path"
            )

        if hero_words > 220:
            reasons.append(
                f"hero copy is long at roughly {hero_words} words, so the value proposition takes too long to resolve"
            )
        elif hero_words > 180:
            reasons.append(
                f"hero copy runs to about {hero_words} words, which slightly slows first-pass comprehension"
            )

        if reasons:
            return "Attention focus is under pressure because " + "; ".join(reasons) + "."

        return "The first screen keeps a fairly direct visual path from message to action."

    def _cta_reason(
        self,
        *,
        cta_count: int,
        primary_cta_label: str,
        weighted_cta: float,
    ) -> str:
        if cta_count >= 4 and not primary_cta_label:
            return (
                f"There are {cta_count} CTA-like actions above the fold, but no single primary action was clearly isolated, "
                "so the next step feels ambiguous."
            )

        if cta_count >= 4 and primary_cta_label:
            return (
                f"The page surfaces {cta_count} CTA-like actions above the fold. Even though '{primary_cta_label}' is present, "
                "it still shares too much attention with nearby actions."
            )

        if not primary_cta_label:
            return "The page does not expose a clearly dominant primary CTA label, so the intended next step is harder to read."

        if weighted_cta < 4.0:
            return (
                f"The primary CTA '{primary_cta_label}' exists, but its visual dominance still looks modest relative to the surrounding interface."
            )

        return f"The primary CTA '{primary_cta_label}' is present, though its dominance can still be sharpened."

    def _readability_reason(
        self,
        *,
        hero_words: int,
        avg_paragraph_words: float,
        heading_count: int,
    ) -> str:
        reasons: list[str] = []

        if hero_words > 180:
            reasons.append(f"the hero carries about {hero_words} words before the user reaches a clean decision moment")
        if avg_paragraph_words > 38:
            reasons.append(f"average paragraph density is {avg_paragraph_words:.1f} words, which is slightly heavy for scanning")
        if heading_count < 2:
            reasons.append("heading structure is thin, which reduces scan anchors for a fast first pass")

        if reasons:
            return "Readability pressure comes from " + "; ".join(reasons) + "."

        return "Copy structure is reasonably concise and supports quick scanning."

    def _cognitive_reason(
        self,
        *,
        nav_items: int,
        above_fold_nodes: int,
        cta_count: int,
    ) -> str:
        reasons: list[str] = []

        if nav_items > 12:
            reasons.append(f"{nav_items} top-level navigation choices")
        if above_fold_nodes > 300:
            reasons.append(f"{above_fold_nodes} visible above-fold elements")
        if cta_count > 3:
            reasons.append(f"{cta_count} competing CTA-like actions")

        if reasons:
            return "Cognitive load rises because the user has to process " + ", ".join(reasons) + " at the same time."

        return "Decision complexity is relatively controlled in the opening screen."

    def _layout_reason(self, layout_similarity: LayoutSimilarity | None) -> str:
        if layout_similarity is None:
            return "No layout similarity signal was available."

        similarity = int(getattr(layout_similarity, "similarity", 0) or 0)
        profile = str(getattr(layout_similarity, "profile", "") or "reference pattern")

        if similarity >= 88:
            return f"The page is already closely aligned with the '{profile}' pattern at {similarity}% similarity."
        if similarity >= 78:
            return f"The page shows partial structural alignment with the '{profile}' pattern at {similarity}% similarity."
        return f"The page is still materially different from the '{profile}' pattern, with similarity at {similarity}%."

    def _compute_confidence(
        self,
        *,
        scores: ScoreBlock,
        signals: ExtractedSignals,
        findings: list[Any],
        suggestions: list[Any],
        layout_similarity: LayoutSimilarity | None,
        feedback_summary: FeedbackSummary | None,
    ) -> float:
        score_values = [
            int(scores.attention_focus),
            int(scores.cta_visibility),
            int(scores.readability),
            int(scores.cognitive_load),
        ]
        avg_score = sum(score_values) / max(1, len(score_values))
        spread = sum(abs(v - avg_score) for v in score_values) / max(1, len(score_values))

        signal_count = sum(
            [
                int(signals.word_count or 0) > 0,
                int(signals.heading_count or 0) > 0,
                int(signals.image_count or 0) > 0,
                int(signals.cta_count or 0) > 0,
                int(signals.above_fold_nodes or 0) > 0,
                int(signals.hero_text_length or 0) > 0,
            ]
        )

        confidence = 0.60
        confidence += min(0.14, signal_count * 0.02)
        confidence += min(0.10, len(findings) * 0.015)
        confidence += min(0.08, len(suggestions) * 0.01)

        if layout_similarity is not None:
            confidence += 0.06

        confidence += max(0.0, 0.10 - min(0.10, spread / 100))
        confidence += 0.03 if int(scores.ux_score) > 0 else 0.0

        if feedback_summary:
            total_events = int(getattr(feedback_summary, "total_events", 0) or 0)
            accepted = int(getattr(feedback_summary, "accepted_suggestions", 0) or 0)
            rejected = int(getattr(feedback_summary, "rejected_suggestions", 0) or 0)

            confidence += min(0.05, total_events * 0.005)

            if accepted > rejected:
                confidence += min(0.03, (accepted - rejected) * 0.01)
            elif rejected > accepted:
                confidence -= min(0.03, (rejected - accepted) * 0.01)

        return max(0.55, min(0.97, confidence))

    def _build_reasoning(
        self,
        *,
        priority_issue: str,
        priority_reason: str,
        priority_score: int,
        scores: ScoreBlock,
        signals: ExtractedSignals,
        findings: list[Any],
        suggestions: list[Any],
        layout_similarity: LayoutSimilarity | None,
        feedback_summary: FeedbackSummary | None,
    ) -> str:
        top_finding = getattr(findings[0], "title", "No major finding") if findings else "No major finding"
        second_finding = getattr(findings[1], "title", "") if len(findings) > 1 else ""
        top_suggestion = getattr(suggestions[0], "title", "No major suggestion") if suggestions else "No major suggestion"
        layout_profile = getattr(layout_similarity, "profile", "reference pattern") if layout_similarity else "reference pattern"
        layout_score = int(getattr(layout_similarity, "similarity", 0) or 0) if layout_similarity else 0

        context_bits: list[str] = []
        if int(signals.nav_item_count or 0) > 12:
            context_bits.append(f"{int(signals.nav_item_count or 0)} nav items")
        if int(signals.cta_above_fold_count or 0) > 0:
            context_bits.append(f"{int(signals.cta_above_fold_count or 0)} above-fold CTA-like actions")
        if int(signals.hero_text_length or 0) > 0:
            context_bits.append(f"about {int(signals.hero_text_length or 0)} hero words")

        context_sentence = ""
        if context_bits:
            context_sentence = "Key structural context includes " + ", ".join(context_bits) + "."

        findings_sentence = f"The strongest surfaced issue is '{top_finding}'."
        if second_finding:
            findings_sentence += f" A secondary issue is '{second_finding}'."

        feedback_sentence = ""
        if feedback_summary and int(getattr(feedback_summary, "total_events", 0) or 0) > 0:
            feedback_sentence = (
                f" Historical feedback exists for this domain, with "
                f"{int(getattr(feedback_summary, 'accepted_suggestions', 0) or 0)} accepted and "
                f"{int(getattr(feedback_summary, 'rejected_suggestions', 0) or 0)} rejected suggestion signals."
            )

        return (
            f"The leading pressure point is '{priority_issue}' with a pressure score of {priority_score}/100. "
            f"{priority_reason} "
            f"{findings_sentence} "
            f"The clearest next move is '{top_suggestion}'. "
            f"Overall UX is {scores.ux_score}/100, and the page aligns with the '{layout_profile}' reference pattern at {layout_score}% similarity. "
            f"{context_sentence}"
            f"{feedback_sentence}"
        ).strip()


evaluation_engine = EvaluationEngine()