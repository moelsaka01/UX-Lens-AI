from __future__ import annotations

from typing import Any

from app.config import settings
from app.schemas import (
    ExtractedSignals,
    Finding,
    LayoutSimilarity,
    RedesignMockup,
    RedesignSuggestion,
    ScoreBlock,
    SuggestionEvidence,
)
from app.services.local_image_service import local_image_service


class RedesignService:
    def generate(
        self,
        *,
        signals: ExtractedSignals,
        scores: ScoreBlock,
        findings: list[Finding],
        archetype: str,
        layout_similarity: LayoutSimilarity | None,
        input_url: str,
        generate_mockups: bool = True,
    ) -> tuple[list[RedesignSuggestion], list[RedesignMockup]]:
        suggestion_bundle = self._build_redesign_suggestions(
            signals=signals,
            scores=scores,
            findings=findings,
            archetype=archetype,
            layout_similarity=layout_similarity,
            input_url=input_url,
        )

        suggestions = [item["suggestion"] for item in suggestion_bundle]

        mockups: list[RedesignMockup] = []
        mockup_health = local_image_service.health()
        can_render_visuals = bool(mockup_health.get("available", False)) and str(
            mockup_health.get("ui_mode", "concepts")
        ) == "visual_previews"

        if generate_mockups and settings.enable_mockup_generation and can_render_visuals:
            mockups = self._build_mockups(
                suggestions=suggestions,
                suggestion_bundle=suggestion_bundle,
                signals=signals,
                scores=scores,
                archetype=archetype,
                layout_similarity=layout_similarity,
                input_url=input_url,
                suggestion_title=None,
                variation_index=0,
            )

        return suggestions, mockups

    def generate_mockups_only(
        self,
        *,
        suggestions: list[RedesignSuggestion],
        signals: ExtractedSignals,
        scores: ScoreBlock,
        archetype: str,
        layout_similarity: LayoutSimilarity | None,
        input_url: str,
        suggestion_title: str | None = None,
        variation_index: int = 0,
        mode: str = "renderer",
    ) -> list[RedesignMockup]:
        if not settings.enable_mockup_generation:
            return []

        mockup_health = local_image_service.health()
        can_render_visuals = bool(mockup_health.get("available", False)) and str(
            mockup_health.get("ui_mode", "concepts")
        ) == "visual_previews"

        if not can_render_visuals:
            return []

        suggestion_bundle = self._rebuild_bundle_from_suggestions(
            suggestions=suggestions,
            signals=signals,
            scores=scores,
            archetype=archetype,
            layout_similarity=layout_similarity,
            input_url=input_url,
        )


        return self._build_mockups(
            suggestions=suggestions,
            suggestion_bundle=suggestion_bundle,
            signals=signals,
            scores=scores,
            archetype=archetype,
            layout_similarity=layout_similarity,
            input_url=input_url,
            suggestion_title=suggestion_title,
            variation_index=variation_index,
            mode=mode,
        )

    def _build_redesign_suggestions(
        self,
        *,
        signals: ExtractedSignals,
        scores: ScoreBlock,
        findings: list[Finding],
        archetype: str,
        layout_similarity: LayoutSimilarity | None,
        input_url: str,
    ) -> list[dict[str, Any]]:
        nav_items = int(signals.nav_item_count or 0)
        hero_words = int(signals.hero_text_length or 0)
        cta_count = int(signals.cta_above_fold_count or 0)
        strong_cta_count = int(signals.strong_cta_above_fold_count or 0)
        sections = int(signals.section_count or 0)
        nodes = int(signals.above_fold_nodes or 0)
        forms = int(signals.form_count or 0)
        images = int(signals.image_count or 0)
        paragraph_count = int(signals.paragraph_count or 0)
        avg_paragraph_words = float(signals.avg_paragraph_words or 0.0)
        primary_cta = (signals.primary_cta_label or "").strip()
        meta_description = (signals.meta_description or "").strip()

        finding_titles = " ".join((f.title or "").lower() for f in findings)
        finding_desc = " ".join((f.description or "").lower() for f in findings)

        profile = (layout_similarity.profile or "").strip() if layout_similarity else ""
        profile_similarity = int(layout_similarity.similarity or 0) if layout_similarity else 0

        items: list[dict[str, Any]] = []
        used_titles: set[str] = set()
        used_families: set[str] = set()

        page_context = self._page_context_line(
            signals=signals,
            scores=scores,
            archetype=archetype,
            profile=profile,
        )

        def add_item(
            *,
            title: str,
            current: str,
            proposed: str,
            impact: str,
            suggestion_type: str,
            expected_outcomes: list[str],
            family: str,
            evidence: list[SuggestionEvidence],
            score: float,
        ) -> None:
            title_key = title.strip().lower()
            if title_key in used_titles:
                return

            if family in used_families:
                return

            bounded_score = round(max(0.0, min(100.0, score)), 2)

            suggestion = RedesignSuggestion(
                title=title,
                current=current,
                proposed=proposed,
                impact=impact,  # type: ignore[arg-type]
                suggestion_type=suggestion_type,  # type: ignore[arg-type]
                expected_outcomes=expected_outcomes[:4],
                evidence=evidence[:6],
                rank_score=bounded_score,
                rank_reasons=self._build_rank_reasons(
                    family=family,
                    evidence=evidence,
                    score=bounded_score,
                ),
                confidence=self._confidence_from_score(bounded_score),
                variant_group=family,
            )

            items.append(
                {
                    "suggestion": suggestion,
                    "family": family,
                    "evidence": evidence[:6],
                    "priority_score": bounded_score,
                }
            )
            used_titles.add(title_key)
            used_families.add(family)

        cta_pressure = (
            max(0.0, 86.0 - float(scores.cta_visibility))
            + max(0.0, float(cta_count - 1) * 8.0)
            + max(0.0, 10.0 if not primary_cta else 0.0)
            + max(0.0, float(strong_cta_count - 2) * 4.0)
        )

        primary_cta_context = (
            ", and no clearly dominant primary CTA label was detected"
            if not primary_cta
            else f", with '{primary_cta}' competing for attention"
        )

        if scores.cta_visibility < 84 or not primary_cta or cta_count > 2 or "cta" in finding_titles:
            add_item(
                title="Clarify the primary CTA",
                current=(
                    f"{page_context} The conversion path is not visually decisive yet: "
                    f"the page shows {cta_count} CTA-like actions above the fold"
                    f"{primary_cta_context}."
                ),
                proposed=(
                    "Create one unmistakable primary action with stronger visual dominance, cleaner surrounding whitespace, "
                    "and fewer adjacent competing choices so the next step becomes obvious within the first scan."
                ),
                impact="High",
                suggestion_type="cta",
                expected_outcomes=[
                    "Stronger primary action visibility",
                    "Lower action competition",
                    "Faster decision path",
                    "Higher conversion clarity",
                ],
                family="cta_dominance",
                evidence=[
                    self._evidence(
                        evidence_id="cta_visibility",
                        label="CTA visibility score",
                        source="scores",
                        metric_key="cta_visibility",
                        value=scores.cta_visibility,
                        operator="<",
                        rationale="Low CTA visibility weakens action hierarchy.",
                    ),
                    self._evidence(
                        evidence_id="cta_count",
                        label="Above-fold CTA count",
                        source="signals",
                        metric_key="cta_above_fold_count",
                        value=cta_count,
                        operator=">",
                        rationale="Too many above-fold actions dilute primary intent.",
                    ),
                    self._evidence(
                        evidence_id="primary_cta",
                        label="Primary CTA label",
                        source="signals",
                        metric_key="primary_cta_label",
                        value=primary_cta or "none",
                        operator="context",
                        rationale="Primary CTA extraction informs action clarity.",
                    ),
                ],
                score=cta_pressure,
            )

        focus_pressure = (
            max(0.0, 88.0 - float(scores.attention_focus))
            + max(0.0, float(nodes - 220) / 3.5)
            + max(0.0, float(nav_items - 10) * 1.8)
            + max(0.0, float(hero_words - 140) / 8.0)
        )

        if scores.attention_focus < 84 or nodes > 260 or "competing" in finding_titles or "competing" in finding_desc:
            add_item(
                title="Reduce first-screen competition",
                current=(
                    f"{page_context} The opening viewport is carrying too many simultaneous scan targets, "
                    f"with {nodes} visible nodes, {nav_items} nav items, and about {hero_words} hero words competing for early attention."
                ),
                proposed=(
                    "Remove or defer secondary accents, compress parallel decision points, and shape a more linear eye path "
                    "from value proposition to proof to action."
                ),
                impact="High",
                suggestion_type="layout",
                expected_outcomes=[
                    "Cleaner focal path",
                    "Lower visual friction",
                    "Faster visual orientation",
                    "Better hero-to-CTA flow",
                ],
                family="attention_focus",
                evidence=[
                    self._evidence(
                        evidence_id="attention_focus",
                        label="Attention focus score",
                        source="scores",
                        metric_key="attention_focus",
                        value=scores.attention_focus,
                        operator="<",
                        rationale="Low focus suggests competing visual priorities.",
                    ),
                    self._evidence(
                        evidence_id="above_fold_nodes",
                        label="Above-fold visible nodes",
                        source="signals",
                        metric_key="above_fold_nodes",
                        value=nodes,
                        operator=">",
                        rationale="Dense first screens often reduce focal clarity.",
                    ),
                    self._evidence(
                        evidence_id="hero_words",
                        label="Hero text length",
                        source="signals",
                        metric_key="hero_text_length",
                        value=hero_words,
                        operator="context",
                        rationale="Longer hero copy can amplify early attention split.",
                    ),
                ],
                score=focus_pressure,
            )

        copy_pressure = (
            max(0.0, 92.0 - float(scores.readability))
            + max(0.0, float(hero_words - 110) / 2.6)
            + max(0.0, float(avg_paragraph_words - 28.0) * 1.4)
        )

        if hero_words > 180 or scores.readability < 90 or "hero" in finding_titles or "message overload" in finding_titles:
            add_item(
                title="Compress hero messaging",
                current=(
                    f"{page_context} The first message block is heavier than it needs to be, "
                    f"with about {hero_words} above-fold words and average paragraph density around {avg_paragraph_words:.1f} words."
                ),
                proposed=(
                    "Sharpen the opening message into one clear promise, one concise supporting line, and a more immediate CTA connection "
                    "so the value lands before the user has to parse supporting detail."
                ),
                impact="Medium",
                suggestion_type="hero",
                expected_outcomes=[
                    "Faster message absorption",
                    "Cleaner hero rhythm",
                    "Better scan efficiency",
                ],
                family="hero_message",
                evidence=[
                    self._evidence(
                        evidence_id="hero_words",
                        label="Hero text length",
                        source="signals",
                        metric_key="hero_text_length",
                        value=hero_words,
                        operator=">",
                        rationale="Long hero copy slows comprehension.",
                    ),
                    self._evidence(
                        evidence_id="readability",
                        label="Readability score",
                        source="scores",
                        metric_key="readability",
                        value=scores.readability,
                        operator="<",
                        rationale="Lower readability often correlates with heavy message load.",
                    ),
                    self._evidence(
                        evidence_id="meta_description",
                        label="Meta description presence",
                        source="signals",
                        metric_key="meta_description",
                        value="yes" if meta_description else "no",
                        operator="context",
                        rationale="Available message metadata helps assess copy density.",
                    ),
                ],
                score=copy_pressure,
            )

        nav_pressure = (
            max(0.0, float(nav_items - 8) * 4.5)
            + max(0.0, 86.0 - float(scores.attention_focus)) * 0.4
        )

        if nav_items > 12 and archetype in {"commerce", "marketing", "saas"}:
            add_item(
                title="Tighten navigation hierarchy",
                current=(
                    f"{page_context} The header is exposing {nav_items} top-level choices early in the journey, "
                    "which weakens hero support and increases decision branching before the main offer settles."
                ),
                proposed=(
                    "Keep only the highest-priority routes visible in the main header and collapse lower-priority destinations "
                    "into secondary navigation or menus."
                ),
                impact="Medium" if nav_items <= 18 else "High",
                suggestion_type="navigation",
                expected_outcomes=[
                    "Cleaner next-step hierarchy",
                    "Lower decision friction",
                    "Better hero support",
                ],
                family="navigation_simplification",
                evidence=[
                    self._evidence(
                        evidence_id="nav_items",
                        label="Top-level nav items",
                        source="signals",
                        metric_key="nav_item_count",
                        value=nav_items,
                        operator=">",
                        rationale="Higher nav density increases choice overhead.",
                    ),
                    self._evidence(
                        evidence_id="archetype",
                        label="Detected archetype",
                        source="signals",
                        metric_key="detected_type",
                        value=archetype,
                        operator="context",
                        rationale="Navigation simplification matters most for marketing-like flows.",
                    ),
                    self._evidence(
                        evidence_id="layout_profile",
                        label="Layout profile context",
                        source="layout_similarity",
                        metric_key="profile",
                        value=profile or "none",
                        operator="context",
                        rationale="Reference layout helps contextualize header simplification.",
                    ),
                ],
                score=nav_pressure,
            )

        pacing_pressure = (
            max(0.0, float(sections - 6) * 4.0)
            + max(0.0, float(paragraph_count - 10) * 0.8)
            + max(0.0, float(avg_paragraph_words - 30.0) * 1.2)
        )

        if sections > 8 or ("content" in finding_titles and archetype in {"marketing", "saas", "commerce"}):
            add_item(
                title="Increase content rhythm",
                current=(
                    f"{page_context} The page is introducing {sections} visible sections and {paragraph_count} paragraphs, "
                    "which can make the experience feel sequenced but not intentionally paced."
                ),
                proposed=(
                    "Group related sections more aggressively, tighten transitions between proof and action zones, "
                    "and create stronger pacing contrast between dense information areas and decision moments."
                ),
                impact="Medium",
                suggestion_type="content",
                expected_outcomes=[
                    "Better section pacing",
                    "Clearer information grouping",
                    "Stronger reading rhythm",
                ],
                family="content_pacing",
                evidence=[
                    self._evidence(
                        evidence_id="sections",
                        label="Visible sections",
                        source="signals",
                        metric_key="section_count",
                        value=sections,
                        operator=">",
                        rationale="Too many sections can fragment reading flow.",
                    ),
                    self._evidence(
                        evidence_id="paragraph_count",
                        label="Paragraph count",
                        source="signals",
                        metric_key="paragraph_count",
                        value=paragraph_count,
                        operator="context",
                        rationale="Paragraph count helps estimate pacing density.",
                    ),
                    self._evidence(
                        evidence_id="avg_paragraph_words",
                        label="Average paragraph words",
                        source="signals",
                        metric_key="avg_paragraph_words",
                        value=round(avg_paragraph_words, 1),
                        operator="context",
                        rationale="Longer paragraph rhythm can increase content heaviness.",
                    ),
                ],
                score=pacing_pressure,
            )

        clutter_pressure = (
            max(0.0, 88.0 - float(scores.cognitive_load))
            + max(0.0, float(nodes - 250) / 3.0)
            + max(0.0, float(images - 8) * 1.2)
        )

        if scores.cognitive_load < 84 or nodes > 320:
            add_item(
                title="Lower visual clutter density",
                current=(
                    f"{page_context} The opening layout carries a heavy scan field with {nodes} visible nodes and {images} images, "
                    "which increases perceptual load before users can prioritize the next step."
                ),
                proposed=(
                    "Reduce decorative or low-priority modules near the top, simplify repeated card patterns, "
                    "and let one main story dominate the first decision moment."
                ),
                impact="Medium",
                suggestion_type="layout",
                expected_outcomes=[
                    "Lower cognitive pressure",
                    "Cleaner first impression",
                    "Faster scan path",
                ],
                family="clutter_reduction",
                evidence=[
                    self._evidence(
                        evidence_id="cognitive_load",
                        label="Cognitive load score",
                        source="scores",
                        metric_key="cognitive_load",
                        value=scores.cognitive_load,
                        operator="<",
                        rationale="Lower cognitive-load scores indicate heavier visual burden.",
                    ),
                    self._evidence(
                        evidence_id="nodes",
                        label="Above-fold nodes",
                        source="signals",
                        metric_key="above_fold_nodes",
                        value=nodes,
                        operator=">",
                        rationale="High visible-node density increases clutter risk.",
                    ),
                    self._evidence(
                        evidence_id="images",
                        label="Image count",
                        source="signals",
                        metric_key="image_count",
                        value=images,
                        operator="context",
                        rationale="Image-heavy pages often need more disciplined visual grouping.",
                    ),
                ],
                score=clutter_pressure,
            )

        form_pressure = (
            max(0.0, float(forms) * 10.0)
            + max(0.0, 85.0 - float(scores.cta_visibility)) * 0.9
            + max(0.0, 86.0 - float(scores.attention_focus)) * 0.5
        )

        if forms > 0 and archetype in {"saas", "marketing"}:
            add_item(
                title="Shorten the conversion path around forms",
                current=(
                    f"{page_context} The page introduces form-based commitment while the surrounding structure may still be asking the user "
                    "to process too much context before feeling ready to submit."
                ),
                proposed=(
                    "Reframe the form entry point with stronger local proof, clearer value reinforcement, "
                    "and lower visual pressure around the submission decision."
                ),
                impact="Medium",
                suggestion_type="cta",
                expected_outcomes=[
                    "Better conversion readiness",
                    "Lower submission anxiety",
                    "Stronger value-to-form continuity",
                ],
                family="form_conversion_path",
                evidence=[
                    self._evidence(
                        evidence_id="forms",
                        label="Form count",
                        source="signals",
                        metric_key="form_count",
                        value=forms,
                        operator=">",
                        rationale="Form presence changes the required trust and friction balance.",
                    ),
                    self._evidence(
                        evidence_id="cta_visibility",
                        label="CTA visibility score",
                        source="scores",
                        metric_key="cta_visibility",
                        value=scores.cta_visibility,
                        operator="context",
                        rationale="CTA clarity affects the confidence of form-entry decisions.",
                    ),
                    self._evidence(
                        evidence_id="primary_cta",
                        label="Primary CTA label",
                        source="signals",
                        metric_key="primary_cta_label",
                        value=primary_cta or "none",
                        operator="context",
                        rationale="CTA label informs conversion-path framing.",
                    ),
                ],
                score=form_pressure,
            )

        proof_pressure = (
            max(0.0, float(strong_cta_count) * 4.0)
            + max(0.0, float(profile_similarity - 70) * 0.25)
            + 18.0
        )

        if archetype in {"saas", "marketing", "commerce"} and scores.readability >= 90 and scores.attention_focus >= 84:
            add_item(
                title="Strengthen proof placement",
                current=(
                    f"{page_context} The page structure is reasonably controlled already, but the strongest trust and proof moments "
                    "can still move closer to action decisions."
                ),
                proposed=(
                    "Pull customer proof, trust indicators, or product validation closer to the hero and primary CTA path "
                    "so confidence builds exactly where decisions happen."
                ),
                impact="Medium",
                suggestion_type="content",
                expected_outcomes=[
                    "Higher trust density",
                    "Better conversion support",
                    "Stronger purchase confidence",
                ],
                family="proof_placement",
                evidence=[
                    self._evidence(
                        evidence_id="readability",
                        label="Readability score",
                        source="scores",
                        metric_key="readability",
                        value=scores.readability,
                        operator="context",
                        rationale="Readable pages can often convert better with improved proof placement.",
                    ),
                    self._evidence(
                        evidence_id="focus",
                        label="Attention focus score",
                        source="scores",
                        metric_key="attention_focus",
                        value=scores.attention_focus,
                        operator="context",
                        rationale="Good focus provides a strong base for tighter proof placement.",
                    ),
                    self._evidence(
                        evidence_id="strong_ctas",
                        label="Strong CTA count",
                        source="signals",
                        metric_key="strong_cta_above_fold_count",
                        value=strong_cta_count,
                        operator="context",
                        rationale="Action strength helps determine where proof should reinforce intent.",
                    ),
                ],
                score=proof_pressure,
            )

        if not items:
            add_item(
                title="Polish the current structure",
                current=(
                    f"{page_context} The current layout is already reasonably controlled and conversion-oriented, "
                    "so the main opportunity is refinement rather than structural overhaul."
                ),
                proposed=(
                    "Refine spacing rhythm, CTA emphasis, proof placement, and information grouping without changing the core information architecture."
                ),
                impact="Low",
                suggestion_type="layout",
                expected_outcomes=[
                    "Cleaner spacing rhythm",
                    "Better proof placement",
                    "Incremental UX uplift",
                ],
                family="hierarchy_polish",
                evidence=[
                    self._evidence(
                        evidence_id="ux_score",
                        label="UX score",
                        source="scores",
                        metric_key="ux_score",
                        value=scores.ux_score,
                        operator="context",
                        rationale="High baseline quality suggests refinement rather than overhaul.",
                    ),
                    self._evidence(
                        evidence_id="focus",
                        label="Attention focus score",
                        source="scores",
                        metric_key="attention_focus",
                        value=scores.attention_focus,
                        operator="context",
                        rationale="Good focus supports lighter-touch refinements.",
                    ),
                    self._evidence(
                        evidence_id="cta_visibility",
                        label="CTA visibility score",
                        source="scores",
                        metric_key="cta_visibility",
                        value=scores.cta_visibility,
                        operator="context",
                        rationale="CTA strength helps determine whether polish is sufficient.",
                    ),
                ],
                score=18.0,
            )

        items.sort(key=lambda item: item["priority_score"], reverse=True)
        return items[:6]

    def _rebuild_bundle_from_suggestions(
        self,
        *,
        suggestions: list[RedesignSuggestion],
        signals: ExtractedSignals,
        scores: ScoreBlock,
        archetype: str,
        layout_similarity: LayoutSimilarity | None,
        input_url: str,
    ) -> list[dict[str, Any]]:
        base_bundle = self._build_redesign_suggestions(
            signals=signals,
            scores=scores,
            findings=[],
            archetype=archetype,
            layout_similarity=layout_similarity,
            input_url=input_url,
        )

        evidence_by_title = {
            item["suggestion"].title: {
                "family": item.get("family", "general"),
                "evidence": item.get("evidence", []),
                "priority_score": item.get("priority_score", 0.0),
            }
            for item in base_bundle
        }

        rebuilt: list[dict[str, Any]] = []
        for suggestion in suggestions:
            meta = evidence_by_title.get(
                suggestion.title,
                {
                    "family": str(suggestion.variant_group or suggestion.suggestion_type or "general"),
                    "evidence": list(suggestion.evidence or []),
                    "priority_score": float(suggestion.rank_score or 0.0),
                },
            )
            rebuilt.append(
                {
                    "suggestion": suggestion,
                    "family": meta["family"],
                    "evidence": meta["evidence"],
                    "priority_score": meta["priority_score"],
                }
            )

        return rebuilt

    def _build_mockups(
        self,
        *,
        suggestions: list[RedesignSuggestion],
        suggestion_bundle: list[dict[str, Any]],
        signals: ExtractedSignals,
        scores: ScoreBlock,
        archetype: str,
        layout_similarity: LayoutSimilarity | None,
        input_url: str,
        suggestion_title: str | None = None,
        variation_index: int = 0,
        mode: str = "renderer",
    ) -> list[RedesignMockup]:
        mockups: list[RedesignMockup] = []

        bundle_by_title = {
            item["suggestion"].title.strip().lower(): item
            for item in suggestion_bundle
        }

        filtered_suggestions = suggestions
        if suggestion_title:
            normalized_title = suggestion_title.strip().lower()
            filtered_suggestions = [
                item for item in suggestions if str(item.title).strip().lower() == normalized_title
            ]

        if not filtered_suggestions:
            return []

        max_mockups = 1 if suggestion_title else max(1, int(getattr(settings, "mockup_count", 1)))

        for local_idx, suggestion in enumerate(filtered_suggestions[:max_mockups]):
            effective_variation_index = variation_index + local_idx
            bundle_item = bundle_by_title.get(suggestion.title.strip().lower(), {})
            evidence = bundle_item.get("evidence", [])
            family = bundle_item.get("family", "general")

            prompt = self._build_mockup_prompt(
                suggestion=suggestion,
                evidence=evidence,
                family=family,
                signals=signals,
                scores=scores,
                archetype=archetype,
                layout_similarity=layout_similarity,
                input_url=input_url,
                variation_index=effective_variation_index,
            )

            image_url = self._generate_image(
                prompt,
                variation_index=effective_variation_index,
                mode=mode,
            )

            rationale = self._build_mockup_rationale(
                suggestion=suggestion,
                evidence=evidence,
                family=family,
                image_url=image_url,
                variation_index=effective_variation_index,
            )

            if not image_url:
                health = local_image_service.health()
                if not health.get("available", False):
                    rationale = (
                        "Visual preview generation is unavailable. "
                        f"Reason: {health.get('reason') or health.get('error') or 'unknown local image pipeline error'}."
                    )
                else:
                    rationale = (
                        "Visual preview generation was attempted, but no image file was returned. "
                        "Check backend logs for the exact generation error."
                    )

            mode = "visual_preview" if image_url else "concept"

            mockups.append(
                RedesignMockup(
                    title=suggestion.title,
                    prompt=prompt,
                    image_url=image_url,
                    rationale=rationale,
                    mode=mode,
                    variation_index=effective_variation_index,
                )
            )

        return mockups

    def _build_mockup_prompt(
        self,
        *,
        suggestion: RedesignSuggestion,
        evidence: list[SuggestionEvidence],
        family: str,
        signals: ExtractedSignals,
        scores: ScoreBlock,
        archetype: str,
        layout_similarity: LayoutSimilarity | None,
        input_url: str,
        variation_index: int = 0,
    ) -> str:
        profile = (
            layout_similarity.profile
            if layout_similarity and layout_similarity.profile
            else f"{archetype} landing page"
        )

        nav_hint = "reduced top navigation" if (signals.nav_item_count or 0) > 10 else "minimal top navigation"
        cta_hint = "dominant primary CTA" if scores.cta_visibility < 85 else "clear premium CTA"
        hero_hint = "tight concise hero copy" if (signals.hero_text_length or 0) > 120 else "balanced hero copy"
        density_hint = (
            "reduced above-the-fold clutter"
            if (signals.above_fold_nodes or 0) > 260
            else "clean focused first screen"
        )

        family_hint = self._family_visual_hint(family)
        variation_hint = self._variation_hint(variation_index)

        evidence_hint = (
            ", ".join(f"{item.label}: {item.value}" for item in evidence[:2])
            if evidence
            else "layout-aware redesign"
        )

        prompt_parts = [
            f"{archetype} website redesign",
            f"inspired by {profile}",
            f"goal: {suggestion.proposed}",
            f"current issue: {suggestion.current}",
            f"evidence cues: {evidence_hint}",
            family_hint,
            cta_hint,
            nav_hint,
            hero_hint,
            density_hint,
            variation_hint,
            "clean modern web UI",
            "premium landing page",
            "strong visual hierarchy",
            "realistic website screenshot",
            "no device frame",
            "no browser chrome",
            "full-page product design",
            "credible spacing system",
            "conversion-focused composition",
        ]

        prompt = ", ".join(part.strip() for part in prompt_parts if part and part.strip())
        return self._truncate_prompt(prompt)

    def _family_visual_hint(self, family: str) -> str:
        mapping = {
            "cta_dominance": "strong hero-to-CTA emphasis with minimal competing actions",
            "attention_focus": "clean focal path with restrained secondary accents",
            "hero_message": "concise hero with tighter copy rhythm and stronger message hierarchy",
            "navigation_simplification": "lighter header and more disciplined navigation exposure",
            "content_pacing": "clearer section pacing and grouped information rhythm",
            "clutter_reduction": "simplified module density and calmer first-screen composition",
            "form_conversion_path": "conversion-supportive form framing with stronger reassurance placement",
            "proof_placement": "trust indicators and product proof placed closer to decision moments",
            "hierarchy_polish": "subtle premium hierarchy refinements without structural overhaul",
        }
        return mapping.get(family, "high-clarity redesign direction")

    def _variation_hint(self, variation_index: int) -> str:
        variation_styles = [
            "premium structured layout direction",
            "slightly more minimal and spacious layout direction",
            "slightly bolder hierarchy and CTA emphasis",
            "slightly stronger proof and trust placement",
            "slightly more editorial rhythm and spacing",
        ]
        return variation_styles[variation_index % len(variation_styles)]

    def _truncate_prompt(self, prompt: str) -> str:
        max_words = max(12, int(getattr(settings, "mockup_prompt_max_words", 42)))
        words = prompt.split()
        if len(words) <= max_words:
            return prompt
        return " ".join(words[:max_words])

    def _build_mockup_rationale(
        self,
        *,
        suggestion: RedesignSuggestion,
        evidence: list[SuggestionEvidence],
        family: str,
        image_url: str,
        variation_index: int = 0,
    ) -> str:
        impact = str(suggestion.impact or "").strip()
        evidence_text = "; ".join(f"{item.label}: {item.value}" for item in evidence[:2]) if evidence else ""
        family_text = family.replace("_", " ")

        if image_url:
            parts: list[str] = []
            if impact:
                parts.append(f"{impact} impact direction.")
            parts.append(f"Built from the {family_text} redesign family.")
            if evidence_text:
                parts.append(f"Evidence used: {evidence_text}.")
            if variation_index > 0:
                parts.append(f"Variation {variation_index + 1} generated from the same redesign direction.")
            return " ".join(parts)

        return "Generation attempted without a returned image."

    def _build_rank_reasons(
        self,
        *,
        family: str,
        evidence: list[SuggestionEvidence],
        score: float,
    ) -> list[str]:
        reasons = [f"Prioritized under the {family.replace('_', ' ')} family."]
        if evidence:
            reasons.extend(f"Supported by {item.label.lower()}." for item in evidence[:2])
        reasons.append(f"Priority score computed at {round(score, 2)}.")
        return reasons[:5]

    def _confidence_from_score(self, score: float) -> float:
        normalized = max(0.45, min(0.97, 0.45 + (float(score) / 100.0)))
        return round(normalized, 3)

    def _page_context_line(
        self,
        *,
        signals: ExtractedSignals,
        scores: ScoreBlock,
        archetype: str,
        profile: str,
    ) -> str:
        profile_text = profile or f"{archetype} reference pattern"
        return (
            f"This {archetype} page is currently closer to a {profile_text.lower()} structure, "
            f"with UX {int(scores.ux_score)}/100, focus {int(scores.attention_focus)}/100, "
            f"CTA visibility {int(scores.cta_visibility)}/100, and readability {int(scores.readability)}/100."
        )

    def _evidence(
        self,
        *,
        evidence_id: str,
        label: str,
        source: str,
        metric_key: str,
        value: Any,
        operator: str,
        rationale: str,
    ) -> SuggestionEvidence:
        return SuggestionEvidence(
            evidence_id=evidence_id,
            label=label,
            source=source,  # type: ignore[arg-type]
            metric_key=metric_key,
            value=value,
            operator=operator,
            rationale=rationale,
        )

    def _generate_image(self, prompt: str, variation_index: int = 0, mode: str = "renderer") -> str:
        return local_image_service.generate_mockup(
            prompt,
            variation_index=variation_index,
            mode=mode,
        )

redesign_service = RedesignService()