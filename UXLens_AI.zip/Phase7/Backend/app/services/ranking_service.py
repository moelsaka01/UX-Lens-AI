from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from app.schemas import (
    ABTestScoring,
    ABVariantScore,
    BenchmarkMatch,
    EvaluationBlock,
    ExtractedSignals,
    FeedbackSummary,
    LayoutSimilarity,
    RankingDiagnostics,
    RankingFeatureSnapshot,
    RankingWeightSet,
    RedesignSuggestion,
    ScoreBlock,
    Suggestion,
    SuggestionEvidence,
)
from app.services.learning_model_service import learning_model_service
from app.services.storage_service import storage_service


WEIGHT_KEYS = [
    "ux_weight",
    "attention_focus_weight",
    "cta_visibility_weight",
    "readability_weight",
    "cognitive_load_weight",
    "novelty_weight",
    "confidence_weight",
    "business_alignment_weight",
    "evidence_strength_weight",
]


class RankingService:
    def rank_suggestions(
        self,
        *,
        suggestions: list[Suggestion],
        signals: ExtractedSignals,
        scores: ScoreBlock,
        findings: list[Any],
        layout_similarity: LayoutSimilarity | None,
        benchmark_match: BenchmarkMatch | None,
        evaluation: EvaluationBlock | dict[str, Any] | None,
        feedback_summary: FeedbackSummary | None,
        workspace_id: int | None = None,
    ) -> list[Suggestion]:
        if not suggestions:
            return []

        weights = self._resolve_weights(workspace_id=workspace_id)
        scored_rows: list[dict[str, Any]] = []

        for item in suggestions:
            evidence: list[SuggestionEvidence] = list(item.evidence or [])
            reasons: list[str] = []
            title_lower = str(item.title or "").lower()
            impact_label = str(item.impact or "Medium")

            ux_gap = max(0.0, 100.0 - float(scores.ux_score))
            focus_gap = max(0.0, 100.0 - float(scores.attention_focus))
            cta_gap = max(0.0, 100.0 - float(scores.cta_visibility))
            readability_gap = max(0.0, 100.0 - float(scores.readability))
            cognitive_gap = max(0.0, 100.0 - float(scores.cognitive_load))
            evaluation_confidence = float(self._obj_get(evaluation, "confidence", 0.0) or 0.0)

            feature_map: dict[str, float] = {
                "ux_score": ux_gap,
                "attention_focus": focus_gap,
                "cta_visibility": cta_gap,
                "readability": readability_gap,
                "cognitive_load": cognitive_gap,
            }

            novelty = 1.0
            business_alignment = 1.0
            feedback_adjustment = 0.0
            context_boost = 0.0

            if "navigation" in title_lower or "nav" in title_lower:
                nav_items = float(signals.nav_item_count or 0)
                evidence.append(
                    SuggestionEvidence(
                        evidence_id="nav-density",
                        label="Navigation density",
                        source="signals",
                        metric_key="nav_item_count",
                        value=int(nav_items),
                        operator=">",
                        rationale="High nav density increases first-screen choice overload.",
                    )
                )
                nav_pressure = min(100.0, max(0.0, (nav_items - 8.0) * 5.0))
                feature_map["attention_focus"] = max(feature_map["attention_focus"], nav_pressure)
                business_alignment += 0.18
                context_boost += min(8.0, max(0.0, nav_items - 10.0))
                reasons.append(f"Boosted by navigation overload at {int(nav_items)} visible nav items.")

            if "primary action" in title_lower or "cta" in title_lower:
                evidence.append(
                    SuggestionEvidence(
                        evidence_id="cta-visibility",
                        label="CTA visibility",
                        source="scores",
                        metric_key="cta_visibility",
                        value=scores.cta_visibility,
                        operator="<",
                        rationale="Weak CTA visibility makes action hierarchy less obvious.",
                    )
                )
                feature_map["cta_visibility"] = max(feature_map["cta_visibility"], cta_gap)
                business_alignment += 0.22
                context_boost += min(10.0, cta_gap / 3.0)
                reasons.append(f"Boosted by weaker CTA visibility score of {int(scores.cta_visibility)}/100.")

            if "hero copy" in title_lower or "dense body copy" in title_lower or "messaging" in title_lower:
                hero_words = float(signals.hero_text_length or 0)
                evidence.append(
                    SuggestionEvidence(
                        evidence_id="hero-copy",
                        label="Hero text length",
                        source="signals",
                        metric_key="hero_text_length",
                        value=int(hero_words),
                        operator=">",
                        rationale="Long hero copy slows early comprehension.",
                    )
                )
                copy_pressure = min(100.0, max(0.0, (hero_words - 60.0) * 0.7))
                feature_map["readability"] = max(feature_map["readability"], copy_pressure)
                context_boost += min(8.0, max(0.0, hero_words - 120.0) / 12.0)
                reasons.append(f"Boosted by long copy load at about {int(hero_words)} hero words.")

            if (
                "noise" in title_lower
                or "section pacing" in title_lower
                or "competition" in title_lower
                or "clutter" in title_lower
            ):
                node_count = float(signals.above_fold_nodes or 0)
                evidence.append(
                    SuggestionEvidence(
                        evidence_id="viewport-density",
                        label="Above-fold node density",
                        source="signals",
                        metric_key="above_fold_nodes",
                        value=int(node_count),
                        operator=">",
                        rationale="A dense scan field reduces focus and clarity.",
                    )
                )
                density_pressure = min(100.0, max(0.0, (node_count - 160.0) / 2.0))
                feature_map["attention_focus"] = max(feature_map["attention_focus"], density_pressure)
                feature_map["cognitive_load"] = max(feature_map["cognitive_load"], density_pressure * 0.9)
                context_boost += min(8.0, max(0.0, node_count - 220.0) / 18.0)
                reasons.append(f"Boosted by dense first-screen scan field at {int(node_count)} visible nodes.")

            if findings:
                top_finding_title = str(getattr(findings[0], "title", "") or "")
                if top_finding_title:
                    evidence.append(
                        SuggestionEvidence(
                            evidence_id="top-finding",
                            label="Top finding",
                            source="findings",
                            metric_key="title",
                            value=top_finding_title,
                            operator="supports",
                            rationale="Top finding contributes to suggestion priority.",
                        )
                    )
                    if self._finding_supports_suggestion(
                        title_lower=title_lower,
                        finding_title=top_finding_title,
                    ):
                        context_boost += 6.0
                        reasons.append(f"Strongly aligned with top finding '{top_finding_title}'.")

            if layout_similarity is not None:
                evidence.append(
                    SuggestionEvidence(
                        evidence_id="layout-profile",
                        label="Layout similarity profile",
                        source="layout_similarity",
                        metric_key="profile",
                        value=layout_similarity.profile,
                        operator="context",
                        rationale="Layout archetype helps contextualize redesign direction.",
                    )
                )
                similarity = float(layout_similarity.similarity or 0)
                if similarity < 82:
                    context_boost += min(6.0, (82.0 - similarity) / 4.0)
                    reasons.append(
                        f"Layout similarity is only {int(similarity)}/100, so benchmark-directed redesign is more valuable."
                    )

            if benchmark_match is not None:
                evidence.append(
                    SuggestionEvidence(
                        evidence_id="benchmark-match",
                        label="Benchmark match",
                        source="benchmark_match",
                        metric_key="label",
                        value=benchmark_match.label,
                        operator="context",
                        rationale="Best-fit benchmark informs expected direction.",
                    )
                )
                benchmark_similarity = float(benchmark_match.similarity or 0)
                if benchmark_similarity < 85:
                    context_boost += min(5.0, (85.0 - benchmark_similarity) / 5.0)

            family_key = self._infer_family_key(item=item)

            if feedback_summary is not None:
                feedback_adjustment, feedback_reasons = self._feedback_adjustment(
                    family_key=family_key,
                    feedback_summary=feedback_summary,
                )
                reasons.extend(feedback_reasons)

                accepted = float(feedback_summary.accepted_suggestions or 0)
                rejected = float(feedback_summary.rejected_suggestions or 0)
                positives = float(feedback_summary.positive_signals or 0)
                negatives = float(feedback_summary.negative_signals or 0)

                evaluation_confidence += min(0.10, accepted * 0.01 + positives * 0.005)
                evaluation_confidence -= min(0.06, rejected * 0.006 + negatives * 0.003)
                novelty += min(0.4, rejected * 0.04)
                business_alignment += min(0.25, accepted * 0.015)

            evaluation_confidence = max(0.0, min(0.99, evaluation_confidence))
            evidence_strength = float(len(evidence))

            feature_map["novelty"] = novelty * 10.0
            feature_map["confidence"] = evaluation_confidence * 100.0
            feature_map["business_alignment"] = business_alignment * 10.0
            feature_map["evidence_strength"] = evidence_strength * 5.0
            feature_map["context_boost"] = context_boost
            feature_map["feedback_adjustment"] = feedback_adjustment
            feature_map["impact_prior"] = self._impact_prior(impact_label)

            raw_rank_score = (
                feature_map["ux_score"] * weights.ux_weight
                + feature_map["attention_focus"] * weights.attention_focus_weight
                + feature_map["cta_visibility"] * weights.cta_visibility_weight
                + feature_map["readability"] * weights.readability_weight
                + feature_map["cognitive_load"] * weights.cognitive_load_weight
                + feature_map["novelty"] * weights.novelty_weight
                + feature_map["confidence"] * weights.confidence_weight
                + feature_map["business_alignment"] * weights.business_alignment_weight
                + feature_map["evidence_strength"] * weights.evidence_strength_weight
                + feature_map["context_boost"]
                + feature_map["feedback_adjustment"]
                + feature_map["impact_prior"]
            )

            ml_score = learning_model_service.predict_score(item)
            if ml_score is not None:
                raw_rank_score = (raw_rank_score * 0.65) + (ml_score * 0.35)
                feature_map["ml_ranker_score"] = float(ml_score)
                reasons.append(f"ML ranker blended score: {round(ml_score, 2)}/100.")
            else:
                feature_map["ml_ranker_score"] = 0.0

            reasons.append(f"Weighted with ranking profile {weights.version}.")
            reasons.append(f"Raw ranking score computed at {round(raw_rank_score, 2)}.")

            scored_rows.append(
                {
                    "item": item,
                    "evidence": evidence[:8],
                    "reasons": reasons[:8],
                    "feature_map": feature_map,
                    "raw_rank_score": round(raw_rank_score, 2),
                }
            )

        normalized_scores = self._normalize_scores(
            [float(row["raw_rank_score"]) for row in scored_rows]
        )

        ranked: list[Suggestion] = []

        for row, normalized in zip(scored_rows, normalized_scores):
            item = row["item"]
            reasons = list(row["reasons"])
            reasons.append(f"Normalized impact score: {int(round(normalized))}/100.")

            ranked.append(
                Suggestion(
                    title=item.title,
                    impact=self._impact_from_score(normalized, fallback=item.impact),
                    description=item.description,
                    evidence=row["evidence"][:6],
                    rank_score=round(normalized, 2),
                    rank_reasons=reasons[:6],
                    dedupe_key=item.dedupe_key,
                )
            )

        ranked.sort(key=lambda item: item.rank_score, reverse=True)
        return ranked

    def build_ranking_diagnostics(
        self,
        *,
        suggestions: list[Suggestion],
        workspace_id: int | None = None,
    ) -> RankingDiagnostics:
        weights = self._resolve_weights(workspace_id=workspace_id)
        ml_available = learning_model_service.available()

        snapshots: list[RankingFeatureSnapshot] = []
        for idx, item in enumerate(suggestions):
            ml_score = learning_model_service.predict_score(item) if ml_available else None

            snapshots.append(
                RankingFeatureSnapshot(
                    suggestion_title=item.title,
                    features={
                        "impact_score": float(item.rank_score),
                        "evidence_count": float(len(item.evidence or [])),
                        "impact_high": 1.0 if item.impact == "High" else 0.0,
                        "impact_medium": 1.0 if item.impact == "Medium" else 0.0,
                        "impact_low": 1.0 if item.impact == "Low" else 0.0,
                        "ml_ranker_score": float(ml_score or 0.0),
                    },
                    weighted_score=float(item.rank_score),
                    chosen=idx == 0,
                )
            )

        learned_from_feedback = weights.source in {"learned", "hybrid"} or ml_available

        return RankingDiagnostics(
            model_name="adaptive_ml_hybrid_ranker_v4" if ml_available else "adaptive_impact_ranker_v3",
            model_type="hybrid",
            weights=weights,
            feature_snapshots=snapshots,
            training_samples=0,
            learned_from_feedback=learned_from_feedback,
        )

    def enrich_redesign_suggestions(
        self,
        *,
        redesign_suggestions: list[RedesignSuggestion],
        suggestions: list[Suggestion],
    ) -> list[RedesignSuggestion]:
        if not redesign_suggestions:
            return redesign_suggestions

        suggestion_map = {item.title: item for item in suggestions}
        enriched: list[RedesignSuggestion] = []

        for item in redesign_suggestions:
            linked = suggestion_map.get(getattr(item, "title", ""), None)
            if linked is None:
                enriched.append(item)
                continue

            enriched.append(
                item.model_copy(
                    update={
                        "impact": linked.impact,
                        "evidence": linked.evidence,
                        "rank_score": linked.rank_score,
                        "rank_reasons": linked.rank_reasons,
                        "confidence": self._confidence_from_impact_score(linked.rank_score),
                        "variant_group": item.variant_group or str(item.suggestion_type or "layout"),
                    }
                )
            )

        return enriched

    def build_ab_test_scoring(
        self,
        *,
        redesign_suggestions: list[RedesignSuggestion],
        scores: ScoreBlock,
        evaluation: EvaluationBlock | dict[str, Any] | None,
    ) -> ABTestScoring:
        if not redesign_suggestions:
            return ABTestScoring(
                available=False,
                scoring_type="heuristic",
                winner_variant_id="",
                baseline_variant_id="baseline",
                variants=[],
                primary_metric="predicted_conversion",
                summary="No redesign variants were available for A/B scoring.",
            )

        variants: list[ABVariantScore] = []
        confidence = float(self._obj_get(evaluation, "confidence", 0.0) or 0.0)

        baseline_ctr = max(0.01, scores.cta_visibility / 200.0)
        baseline_conversion = max(0.01, scores.ux_score / 250.0)

        variants.append(
            ABVariantScore(
                variant_id="baseline",
                label="Current experience",
                predicted_ux=float(scores.ux_score),
                predicted_ctr=round(baseline_ctr, 4),
                predicted_conversion=round(baseline_conversion, 4),
                predicted_bounce_reduction=0.0,
                confidence=round(confidence, 3),
                rationale="Baseline predicted from current page scoring.",
            )
        )

        for idx, item in enumerate(redesign_suggestions[:5], start=1):
            impact = str(getattr(item, "impact", "Medium")).lower()
            rank_score = float(getattr(item, "rank_score", 0.0) or 0.0)

            impact_base = 3.0 if impact == "low" else 7.0 if impact == "medium" else 11.0
            score_uplift = min(10.0, rank_score / 10.0)
            uplift = impact_base + score_uplift

            predicted_ux = min(99.0, float(scores.ux_score) + uplift)
            predicted_ctr = min(0.95, baseline_ctr + (uplift / 220.0))
            predicted_conversion = min(0.95, baseline_conversion + (uplift / 260.0))
            predicted_bounce_reduction = round(min(0.40, uplift / 100.0), 4)

            variants.append(
                ABVariantScore(
                    variant_id=f"variant_{idx}",
                    label=getattr(item, "title", f"Variant {idx}"),
                    predicted_ux=round(predicted_ux, 2),
                    predicted_ctr=round(predicted_ctr, 4),
                    predicted_conversion=round(predicted_conversion, 4),
                    predicted_bounce_reduction=predicted_bounce_reduction,
                    confidence=round(min(0.97, max(0.45, confidence + min(0.18, rank_score / 500.0))), 3),
                    rationale="Predicted uplift estimated from redesign impact score and recommendation strength.",
                )
            )

        winner = max(variants, key=lambda item: item.predicted_conversion)

        return ABTestScoring(
            available=True,
            scoring_type="hybrid",
            winner_variant_id=winner.variant_id,
            baseline_variant_id="baseline",
            variants=variants,
            primary_metric="predicted_conversion",
            summary=(
                f"Highest predicted redesign winner is '{winner.label}' based on normalized impact scoring "
                f"and heuristic uplift estimation."
            ),
        )

    def _resolve_weights(self, *, workspace_id: int | None) -> RankingWeightSet:
        try:
            stored = storage_service.get_ranking_weights(workspace_id=workspace_id, version="v1")
            if stored is not None:
                return self._normalize_weight_set(stored)

            return self._default_weights()
        except Exception as exc:
            print(f"[WARN] Failed to resolve ranking weights: {exc}")
            return self._default_weights()

    def _default_weights(self) -> RankingWeightSet:
        return RankingWeightSet(
            version="v1",
            source="static",
            ux_weight=0.28,
            attention_focus_weight=0.22,
            cta_visibility_weight=0.22,
            readability_weight=0.10,
            cognitive_load_weight=0.10,
            novelty_weight=0.02,
            confidence_weight=0.03,
            business_alignment_weight=0.02,
            evidence_strength_weight=0.01,
            updated_at=datetime.now(timezone.utc).isoformat(),
        )

    def _normalize_weight_set(self, weights: RankingWeightSet) -> RankingWeightSet:
        data = weights.model_dump()
        total = sum(float(data.get(key, 0.0) or 0.0) for key in WEIGHT_KEYS)

        if total <= 0:
            return self._default_weights()

        for key in WEIGHT_KEYS:
            data[key] = round(float(data.get(key, 0.0) or 0.0) / total, 6)

        data["updated_at"] = data.get("updated_at") or datetime.now(timezone.utc).isoformat()
        return RankingWeightSet.model_validate(data)

    def _normalize_scores(self, raw_scores: list[float]) -> list[float]:
        if not raw_scores:
            return []

        cleaned = [float(score) for score in raw_scores]
        min_score = min(cleaned)
        max_score = max(cleaned)

        if max_score - min_score < 1e-9:
            return [72.0 for _ in cleaned]

        normalized: list[float] = []
        for score in cleaned:
            scaled = 55.0 + ((score - min_score) / (max_score - min_score)) * 40.0
            normalized.append(round(max(0.0, min(100.0, scaled)), 2))

        return normalized

    def _impact_from_score(self, score: float, fallback: str = "Medium") -> str:
        if score >= 80:
            return "High"
        if score >= 62:
            return "Medium"
        if fallback in {"High", "Medium", "Low"}:
            return fallback
        return "Low"

    def _confidence_from_impact_score(self, score: float) -> float:
        normalized = 0.45 + (max(0.0, min(100.0, float(score))) / 100.0) * 0.45
        return round(min(0.97, max(0.45, normalized)), 3)

    def _impact_prior(self, impact: str) -> float:
        text = str(impact or "").strip().lower()
        if text == "high":
            return 6.0
        if text == "medium":
            return 3.0
        return 0.0

    def _infer_family_key(self, item: Suggestion) -> str:
        dedupe_key = str(item.dedupe_key or "").strip().lower()
        if dedupe_key:
            return dedupe_key

        title_lower = str(item.title or "").strip().lower()
        if "navigation" in title_lower or "nav" in title_lower:
            return "navigation"
        if "cta" in title_lower or "primary action" in title_lower:
            return "cta"
        if "hero" in title_lower or "copy" in title_lower or "messaging" in title_lower:
            return "copy"
        if "noise" in title_lower or "clutter" in title_lower or "competition" in title_lower:
            return "layout_density"

        return title_lower.replace(" ", "_") or "general"

    def _feedback_adjustment(
        self,
        *,
        family_key: str,
        feedback_summary: FeedbackSummary,
    ) -> tuple[float, list[str]]:
        adjustment = 0.0
        reasons: list[str] = []

        accepted = float(feedback_summary.accepted_suggestions or 0)
        rejected = float(feedback_summary.rejected_suggestions or 0)
        positives = float(feedback_summary.positive_signals or 0)
        negatives = float(feedback_summary.negative_signals or 0)

        if accepted > 0:
            boost = min(4.0, accepted * 0.6)
            adjustment += boost
            reasons.append(f"Feedback boost applied from {int(accepted)} accepted suggestions.")

        if positives > negatives and positives > 0:
            adjustment += min(2.0, (positives - negatives) * 0.25)

        if rejected > accepted and rejected > 0:
            penalty = min(3.0, (rejected - accepted) * 0.5)
            adjustment -= penalty
            reasons.append(f"Feedback penalty applied from {int(rejected)} rejected suggestions.")

        preferred_variants = feedback_summary.preferred_variants or {}
        if preferred_variants:
            family_hits = 0
            for key, count in preferred_variants.items():
                normalized = str(key or "").lower()
                if family_key in normalized or normalized in family_key:
                    family_hits += int(count or 0)

            if family_hits > 0:
                preferred_boost = min(5.0, family_hits * 0.9)
                adjustment += preferred_boost
                reasons.append(
                    f"Preference boost applied because related variants were preferred {family_hits} time(s)."
                )

        return adjustment, reasons[:3]

    def _finding_supports_suggestion(self, *, title_lower: str, finding_title: str) -> bool:
        finding_lower = str(finding_title or "").lower()

        pairs = [
            (("navigation", "nav"), ("navigation", "nav")),
            (("cta", "primary action"), ("cta", "action")),
            (("hero", "copy", "messaging"), ("hero", "message", "readability", "copy")),
            (("noise", "competition", "clutter"), ("competing", "dense", "scan field", "noise")),
        ]

        for suggestion_terms, finding_terms in pairs:
            if any(term in title_lower for term in suggestion_terms) and any(
                term in finding_lower for term in finding_terms
            ):
                return True

        return False

    def _obj_get(self, value: Any, key: str, default: Any = None) -> Any:
        if value is None:
            return default
        if isinstance(value, dict):
            return value.get(key, default)
        return getattr(value, key, default)


ranking_service = RankingService()