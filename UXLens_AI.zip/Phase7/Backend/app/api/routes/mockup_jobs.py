from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.services.mockup_job_service import mockup_job_service

router = APIRouter(prefix="/api/mockups", tags=["mockups"])


class MockupJobStartRequest(BaseModel):
    report: dict[str, Any]
    suggestion_title: str | None = None
    variation_index: int = Field(default=0, ge=0)


@router.post("/start")
async def start_mockup_job(payload: MockupJobStartRequest) -> dict[str, Any]:
    return await mockup_job_service.start_job(
        report=payload.report,
        suggestion_title=payload.suggestion_title,
        variation_index=payload.variation_index,
    )


@router.get("/status/{job_id}")
async def get_mockup_job_status(job_id: str) -> dict[str, Any]:
    job = mockup_job_service.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Mockup job not found.")
    return job