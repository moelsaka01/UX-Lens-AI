from __future__ import annotations

import threading
from collections import OrderedDict
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
from PIL import Image
from transformers import CLIPModel, CLIPProcessor

from app.config import settings
from app.schemas import CLIPMatch, LayoutSimilarity
from app.services.pattern_library import PATTERN_LIBRARY


class CLIPService:
    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._initialized = False
        self._available = False
        self._init_error: str | None = None

        requested_device = str(getattr(settings, "clip_device", "cpu") or "cpu").lower()
        self._device = self._resolve_device(requested_device)

        self._processor: CLIPProcessor | None = None
        self._model: CLIPModel | None = None
        self._pattern_embeddings: torch.Tensor | None = None
        self._pattern_rows: list[dict[str, Any]] = []

        self._image_embedding_cache: OrderedDict[str, torch.Tensor] = OrderedDict()
        self._image_cache_limit = 16

    def _resolve_device(self, requested_device: str) -> str:
        if requested_device == "cuda" and not torch.cuda.is_available():
            return "cpu"
        return requested_device

    def _init(self) -> None:
        if self._initialized:
            return

        with self._lock:
            if self._initialized:
                return

            try:
                self._processor = CLIPProcessor.from_pretrained(settings.clip_model_name)
                self._model = CLIPModel.from_pretrained(settings.clip_model_name)
                self._model.eval()
                self._model.to(self._device)

                self._pattern_rows = [
                    row
                    for row in list(PATTERN_LIBRARY)
                    if isinstance(row, dict)
                    and row.get("prompt")
                    and row.get("profile")
                    and row.get("category")
                ]

                prompts = [str(row["prompt"]) for row in self._pattern_rows]
                self._pattern_embeddings = self._encode_texts(prompts)

                self._available = True
                self._init_error = None

            except Exception as exc:
                self._available = False
                self._init_error = str(exc)
                self._processor = None
                self._model = None
                self._pattern_embeddings = None
                self._pattern_rows = []

            finally:
                self._initialized = True

    def health(self) -> dict[str, Any]:
        self._init()
        return {
            "available": self._available,
            "model": settings.clip_model_name,
            "device": self._device,
            "requested_device": str(getattr(settings, "clip_device", "cpu") or "cpu"),
            "pattern_count": len(self._pattern_rows),
            "cache_size": len(self._image_embedding_cache),
            "init_error": self._init_error,
        }

    def is_available(self) -> bool:
        self._init()
        return self._available

    def compute_layout_similarity(self, image_path: str | None, archetype: str) -> LayoutSimilarity:
        self._init()

        if (
            not image_path
            or not self._available
            or self._model is None
            or self._processor is None
            or self._pattern_embeddings is None
            or not self._pattern_rows
        ):
            return self._fallback_similarity(archetype)

        try:
            path = Path(image_path)
            if not path.exists():
                return self._fallback_similarity(archetype)

            image_embedding = self._encode_image(path)

            candidate_rows, candidate_embeddings = self._candidate_pattern_subset(archetype)
            if not candidate_rows or candidate_embeddings is None:
                return self._fallback_similarity(archetype)

            similarities = F.cosine_similarity(image_embedding, candidate_embeddings, dim=1)

            scored: list[tuple[float, dict[str, Any]]] = []
            for score, row in zip(similarities.tolist(), candidate_rows):
                total_score = self._blend_similarity_score(
                    raw_score=float(score),
                    row=row,
                    archetype=archetype,
                )
                scored.append((total_score, row))
                

            scored.sort(key=lambda item: item[0], reverse=True)
            top_k = max(1, int(getattr(settings, "clip_top_k", 3) or 3))
            top_scored = scored[:top_k]

            if not top_scored:
                return self._fallback_similarity(archetype)

            best_score, best_row = top_scored[0]

            top_matches = [
                CLIPMatch(
                    profile=str(row.get("profile", "Unknown pattern")),
                    category=str(row.get("category", archetype)),
                    similarity=self._to_percentage(score),
                    rationale=str(
                        row.get("rationale")
                        or row.get("prompt")
                        or "Matched by visual-semantic similarity."
                    ),
                )
                for score, row in top_scored
            ]

            competing_profiles = ", ".join(
                f"{match.profile} ({match.similarity}%)"
                for match in top_matches[1:3]
            )

            summary = (
                f"The screenshot most closely aligns with {str(best_row['profile']).lower()} "
                f"based on CLIP image-text similarity against benchmark layout profiles."
            )

            rationale = (
                f"Top match: {best_row['profile']} in category '{best_row['category']}'. "
                f"This suggests the page structure, visual rhythm, hierarchy, and composition are closest "
                f"to that benchmark family."
            )

            if competing_profiles:
                rationale += f" Nearby competing matches were {competing_profiles}."

            return LayoutSimilarity(
                profile=str(best_row["profile"]),
                similarity=self._to_percentage(best_score),
                summary=summary,
                rationale=rationale,
                top_matches=top_matches,
            )

        except Exception as exc:
            print(f"[CLIPService] CLIP similarity failed for {image_path}: {exc}")
            return self._fallback_similarity(archetype)

    def _candidate_pattern_subset(self, archetype: str) -> tuple[list[dict[str, Any]], torch.Tensor | None]:
        assert self._pattern_embeddings is not None

        preferred_indices: list[int] = []
        secondary_indices: list[int] = []

        for idx, row in enumerate(self._pattern_rows):
            row_category = str(row.get("category", "")).lower()
            row_profile = str(row.get("profile", "")).lower()

            if row_category == archetype:
                preferred_indices.append(idx)
            elif archetype and archetype in row_profile:
                preferred_indices.append(idx)
            else:
                secondary_indices.append(idx)

        selected_indices = preferred_indices + secondary_indices[: max(4, int(getattr(settings, "clip_top_k", 3) or 3) * 2)]
        if not selected_indices:
            return self._pattern_rows, self._pattern_embeddings

        rows = [self._pattern_rows[idx] for idx in selected_indices]
        embeddings = self._pattern_embeddings[selected_indices]
        return rows, embeddings

    def _blend_similarity_score(self, raw_score: float, row: dict[str, Any], archetype: str) -> float:
        category = str(row.get("category", "")).lower()
        profile = str(row.get("profile", "")).lower()
        prompt = str(row.get("prompt", "")).lower()

        category_bonus = 0.04 if category == archetype else 0.0
        profile_bonus = 0.015 if archetype and archetype in profile else 0.0
        prompt_bonus = 0.01 if archetype and archetype in prompt else 0.0

        premium_bonus = 0.0
        if archetype in {"marketing", "saas"} and any(term in profile for term in ["hero", "product", "enterprise", "proof"]):
            premium_bonus += 0.01
        if archetype == "commerce" and any(term in profile for term in ["consumer", "hardware", "showcase", "marketplace"]):
            premium_bonus += 0.012
        if archetype == "docs" and "documentation" in profile:
            premium_bonus += 0.012
        if archetype == "content" and "editorial" in profile:
            premium_bonus += 0.012
        if archetype == "dashboard" and "dashboard" in profile:
            premium_bonus += 0.012

        return raw_score + category_bonus + profile_bonus + prompt_bonus + premium_bonus

    def _encode_texts(self, texts: list[str]) -> torch.Tensor:
        assert self._processor is not None
        assert self._model is not None

        inputs = self._processor(
            text=texts,
            padding=True,
            truncation=True,
            return_tensors="pt",
        )
        inputs = {k: v.to(self._device) for k, v in inputs.items()}

        with torch.no_grad():
            feats = self._model.get_text_features(**inputs)
            feats = F.normalize(feats, p=2, dim=1)

        return feats

    def _encode_image(self, image_path: Path) -> torch.Tensor:
        assert self._processor is not None
        assert self._model is not None

        cache_key = str(image_path.resolve())
        cached = self._image_embedding_cache.get(cache_key)
        if cached is not None:
            self._image_embedding_cache.move_to_end(cache_key)
            return cached

        image = Image.open(image_path).convert("RGB")
        inputs = self._processor(images=image, return_tensors="pt")
        inputs = {k: v.to(self._device) for k, v in inputs.items()}

        with torch.no_grad():
            feats = self._model.get_image_features(**inputs)
            feats = F.normalize(feats, p=2, dim=1)

        self._image_embedding_cache[cache_key] = feats
        self._image_embedding_cache.move_to_end(cache_key)

        while len(self._image_embedding_cache) > self._image_cache_limit:
            self._image_embedding_cache.popitem(last=False)

        return feats

    def _to_percentage(self, score: float) -> int:
        normalized = max(0.0, min(1.0, (score + 1.0) / 2.0))
        boosted = 55.0 + (normalized * 43.0)
        return int(round(max(40.0, min(98.0, boosted))))

    def _fallback_similarity(self, archetype: str) -> LayoutSimilarity:
        profile_map = {
            "saas": "SaaS hero with proof-driven sections",
            "marketing": "Enterprise product marketing page",
            "commerce": "Consumer hardware showcase page",
            "content": "Editorial content-first layout",
            "docs": "Documentation index layout",
            "dashboard": "Product dashboard shell",
        }

        alternates = {
            "saas": [
                CLIPMatch(
                    profile="SaaS hero with proof-driven sections",
                    category="saas",
                    similarity=74,
                    rationale="Heuristic fallback based on page archetype.",
                ),
                CLIPMatch(
                    profile="Enterprise product landing page",
                    category="marketing",
                    similarity=70,
                    rationale="Secondary fallback benchmark.",
                ),
                CLIPMatch(
                    profile="Documentation-aware product layout",
                    category="docs",
                    similarity=66,
                    rationale="Weaker fallback benchmark.",
                ),
            ],
            "marketing": [
                CLIPMatch(
                    profile="Enterprise product marketing page",
                    category="marketing",
                    similarity=74,
                    rationale="Heuristic fallback based on page archetype.",
                ),
                CLIPMatch(
                    profile="SaaS hero with proof-driven sections",
                    category="saas",
                    similarity=71,
                    rationale="Secondary fallback benchmark.",
                ),
                CLIPMatch(
                    profile="Consumer hardware showcase page",
                    category="commerce",
                    similarity=67,
                    rationale="Weaker fallback benchmark.",
                ),
            ],
            "commerce": [
                CLIPMatch(
                    profile="Consumer hardware showcase page",
                    category="commerce",
                    similarity=74,
                    rationale="Heuristic fallback based on page archetype.",
                ),
                CLIPMatch(
                    profile="Enterprise product marketing page",
                    category="marketing",
                    similarity=69,
                    rationale="Secondary fallback benchmark.",
                ),
                CLIPMatch(
                    profile="Marketplace discovery layout",
                    category="commerce",
                    similarity=67,
                    rationale="Weaker fallback benchmark.",
                ),
            ],
            "content": [
                CLIPMatch(
                    profile="Editorial content-first layout",
                    category="content",
                    similarity=74,
                    rationale="Heuristic fallback based on page archetype.",
                ),
                CLIPMatch(
                    profile="Documentation index layout",
                    category="docs",
                    similarity=69,
                    rationale="Secondary fallback benchmark.",
                ),
                CLIPMatch(
                    profile="Enterprise product marketing page",
                    category="marketing",
                    similarity=64,
                    rationale="Weaker fallback benchmark.",
                ),
            ],
            "docs": [
                CLIPMatch(
                    profile="Documentation index layout",
                    category="docs",
                    similarity=74,
                    rationale="Heuristic fallback based on page archetype.",
                ),
                CLIPMatch(
                    profile="Product dashboard shell",
                    category="dashboard",
                    similarity=69,
                    rationale="Secondary fallback benchmark.",
                ),
                CLIPMatch(
                    profile="Editorial content-first layout",
                    category="content",
                    similarity=66,
                    rationale="Weaker fallback benchmark.",
                ),
            ],
            "dashboard": [
                CLIPMatch(
                    profile="Product dashboard shell",
                    category="dashboard",
                    similarity=74,
                    rationale="Heuristic fallback based on page archetype.",
                ),
                CLIPMatch(
                    profile="Documentation index layout",
                    category="docs",
                    similarity=68,
                    rationale="Secondary fallback benchmark.",
                ),
                CLIPMatch(
                    profile="SaaS hero with proof-driven sections",
                    category="saas",
                    similarity=63,
                    rationale="Weaker fallback benchmark.",
                ),
            ],
        }

        profile = profile_map.get(archetype, "Modern landing page")
        top_matches = alternates.get(
            archetype,
            [
                CLIPMatch(
                    profile=profile,
                    category=archetype,
                    similarity=74,
                    rationale="Heuristic fallback only.",
                )
            ],
        )

        return LayoutSimilarity(
            profile=profile,
            similarity=74,
            summary="CLIP similarity was unavailable, so a heuristic fallback layout profile was used.",
            rationale=(
                "The backend could not compute CLIP similarity at runtime, "
                "so the result was approximated from the inferred page archetype."
            ),
            top_matches=top_matches,
        )


clip_service = CLIPService()