from __future__ import annotations

import logging
import os
import threading
from typing import Any

import chromadb
from chromadb.config import Settings


class EmbeddingService:
    def __init__(self) -> None:
        self.persist_dir = os.getenv("CHROMA_PERSIST_DIR", "/app/data/chroma")
        self.collection_name = os.getenv("CHROMA_COLLECTION_NAME", "ui_pattern_profiles")
        self.client: chromadb.ClientAPI | None = None
        self.collection: Any | None = None
        self.vector_enabled = False
        self.seeded = False
        self.init_error: str | None = None
        self._lock = threading.Lock()
        self._silence_chroma_telemetry_logs()
        self._init_vector_store()

    def _silence_chroma_telemetry_logs(self) -> None:
        os.environ.setdefault("ANONYMIZED_TELEMETRY", "False")
        os.environ.setdefault("CHROMA_TELEMETRY", "False")

        noisy_loggers = [
            "chromadb",
            "chromadb.telemetry",
            "chromadb.telemetry.product",
            "chromadb.telemetry.product.posthog",
            "chromadb.telemetry.opentelemetry",
            "chromadb.api.segment",
        ]
        for name in noisy_loggers:
            logger = logging.getLogger(name)
            logger.setLevel(logging.CRITICAL)
            logger.propagate = False
            logger.handlers.clear()

    def _init_vector_store(self) -> None:
        try:
            os.makedirs(self.persist_dir, exist_ok=True)
            self.client = chromadb.PersistentClient(
                path=self.persist_dir,
                settings=Settings(anonymized_telemetry=False),
            )
            self.collection = self.client.get_or_create_collection(
                name=self.collection_name,
                metadata={"description": "UI/UX benchmark and pattern profiles"},
            )
            self.vector_enabled = True
            self.init_error = None
            print("[EmbeddingService] Chroma initialized successfully.")
        except Exception as exc:
            self.client = None
            self.collection = None
            self.vector_enabled = False
            self.seeded = False
            self.init_error = str(exc)
            print(f"[EmbeddingService] Vector store init failed: {exc}")

    def _seed_documents(self) -> list[dict[str, Any]]:
        return [
            {
                "id": "cta_prominence_best_practice",
                "document": (
                    "High-converting product pages use one dominant primary call-to-action "
                    "with strong contrast, clear spacing, and minimal nearby competition."
                ),
                "metadata": {
                    "category": "cta_prominence",
                    "label": "CTA Prominence",
                    "benchmark_score": 86,
                    "source": "internal_profile",
                    "pattern_family": "best_practice",
                },
            },
            {
                "id": "attention_focus_best_practice",
                "document": (
                    "Strong visual hierarchy reduces attention diffusion by emphasizing one focal area, "
                    "limiting competing highlights, and guiding the eye toward the primary action."
                ),
                "metadata": {
                    "category": "attention_focus",
                    "label": "Attention Focus",
                    "benchmark_score": 89,
                    "source": "internal_profile",
                    "pattern_family": "best_practice",
                },
            },
            {
                "id": "readability_best_practice",
                "document": (
                    "Readable landing pages keep copy concise, use scannable headings, preserve whitespace, "
                    "and maintain strong text contrast across hero and content sections."
                ),
                "metadata": {
                    "category": "readability",
                    "label": "Readability",
                    "benchmark_score": 91,
                    "source": "internal_profile",
                    "pattern_family": "best_practice",
                },
            },
            {
                "id": "hero_clarity_best_practice",
                "document": (
                    "Effective hero sections communicate value proposition quickly with one clear headline, "
                    "supporting text, and a visible next step."
                ),
                "metadata": {
                    "category": "hero_clarity",
                    "label": "Hero Clarity",
                    "benchmark_score": 88,
                    "source": "internal_profile",
                    "pattern_family": "best_practice",
                },
            },
            {
                "id": "cognitive_load_best_practice",
                "document": (
                    "Pages with lower cognitive load reduce visual clutter, avoid too many parallel options, "
                    "and sequence information progressively from primary to secondary content."
                ),
                "metadata": {
                    "category": "cognitive_load",
                    "label": "Cognitive Load",
                    "benchmark_score": 87,
                    "source": "internal_profile",
                    "pattern_family": "best_practice",
                },
            },
            {
                "id": "enterprise_saas_pattern",
                "document": (
                    "Top enterprise SaaS pages use concise value framing, trust indicators, product visuals, "
                    "clean spacing, and one obvious CTA above the fold."
                ),
                "metadata": {
                    "category": "saas",
                    "label": "Enterprise SaaS Pattern",
                    "benchmark_score": 90,
                    "source": "internal_profile",
                    "pattern_family": "saas_marketing",
                },
            },
            {
                "id": "marketplace_pattern",
                "document": (
                    "Strong marketplace pages prioritize search, category discovery, price visibility, "
                    "product grouping, merchandising blocks, and shopping flow clarity while minimizing overload."
                ),
                "metadata": {
                    "category": "commerce",
                    "label": "Marketplace Pattern",
                    "benchmark_score": 85,
                    "source": "internal_profile",
                    "pattern_family": "commerce_marketplace",
                },
            },
            {
                "id": "consumer_hardware_pattern",
                "document": (
                    "High-performing consumer hardware launch pages use flagship product imagery, a dominant hero, "
                    "tight product-first copy hierarchy, premium branding, and one strong purchase or learn-more path."
                ),
                "metadata": {
                    "category": "commerce",
                    "label": "Consumer Hardware Pattern",
                    "benchmark_score": 91,
                    "source": "internal_profile",
                    "pattern_family": "commerce_hardware",
                },
            },
            {
                "id": "enterprise_product_marketing_page",
                "document": (
                    "Strong enterprise-style product marketing pages use a premium hero, restrained copy, "
                    "clean nav, brand-led presentation, product proof, and a focused CTA path."
                ),
                "metadata": {
                    "category": "marketing",
                    "label": "Enterprise Product Marketing Page",
                    "benchmark_score": 90,
                    "source": "internal_profile",
                    "pattern_family": "brand_marketing",
                },
            },
            {
                "id": "search_homepage_pattern",
                "document": (
                    "Strong search homepage design minimizes distractions, makes the main input dominant, "
                    "and keeps the primary task obvious within one glance."
                ),
                "metadata": {
                    "category": "search",
                    "label": "Search Homepage Pattern",
                    "benchmark_score": 92,
                    "source": "internal_profile",
                    "pattern_family": "search_home",
                },
            },
            {
                "id": "ai_product_landing_pattern",
                "document": (
                    "Strong AI product pages communicate product capability quickly, show a focused hero, "
                    "support trust with visual demos, and keep the first action highly visible."
                ),
                "metadata": {
                    "category": "marketing",
                    "label": "AI Product Landing Pattern",
                    "benchmark_score": 90,
                    "source": "internal_profile",
                    "pattern_family": "ai_marketing",
                },
            },
            {
                "id": "docs_index_pattern",
                "document": (
                    "Strong documentation index pages prioritize findability, clear navigation grouping, "
                    "dense but readable structure, and minimal CTA distraction."
                ),
                "metadata": {
                    "category": "docs",
                    "label": "Documentation Index Pattern",
                    "benchmark_score": 88,
                    "source": "internal_profile",
                    "pattern_family": "docs_index",
                },
            },
            {
                "id": "editorial_content_pattern",
                "document": (
                    "Strong editorial pages prioritize readability, restrained navigation, clean typography, "
                    "and clear visual pacing through headings and section rhythm."
                ),
                "metadata": {
                    "category": "content",
                    "label": "Editorial Content Pattern",
                    "benchmark_score": 89,
                    "source": "internal_profile",
                    "pattern_family": "editorial_content",
                },
            },
            {
                "id": "portal_homepage_pattern",
                "document": (
                    "Large portal homepages prioritize content discovery, multiple content streams, dense navigation, "
                    "high information throughput, real-time updates, broad topic coverage, and multi-path exploration."
                ),
                "metadata": {
                    "category": "portal",
                    "label": "Portal Homepage Pattern",
                    "benchmark_score": 72,
                    "source": "internal_profile",
                    "pattern_family": "portal_homepage",
                },
            },
            {
                "id": "news_homepage_pattern",
                "document": (
                    "Large news homepages prioritize breaking stories, editorial hierarchy, real-time updates, "
                    "headline scanning, topic density, image-led story blocks, and fast information discovery."
                ),
                "metadata": {
                    "category": "news",
                    "label": "News Homepage Pattern",
                    "benchmark_score": 76,
                    "source": "internal_profile",
                    "pattern_family": "news_homepage",
                },
            },
            {
                "id": "content_aggregator_pattern",
                "document": (
                    "Content aggregation platforms combine news, finance, entertainment, search, trending topics, "
                    "recommendations, and high-density discovery modules across one homepage."
                ),
                "metadata": {
                    "category": "portal",
                    "label": "Content Aggregator Pattern",
                    "benchmark_score": 70,
                    "source": "internal_profile",
                    "pattern_family": "content_aggregator",
                },
            },
        ]

    def _seed_collection(self) -> None:
        if not self.vector_enabled or self.collection is None:
            return

        existing_count = self.collection.count()
        if existing_count > 0:
            self.seeded = True
            return

        docs = self._seed_documents()
        self.collection.add(
            ids=[item["id"] for item in docs],
            documents=[item["document"] for item in docs],
            metadatas=[item["metadata"] for item in docs],
        )
        self.seeded = True
        print("[EmbeddingService] Seeded Chroma collection successfully.")

    def ensure_seeded(self) -> bool:
        if not self.vector_enabled:
            return False
        if self.seeded:
            return True

        with self._lock:
            if self.seeded:
                return True
            try:
                self._seed_collection()
                return self.seeded
            except Exception as exc:
                self.seeded = False
                self.vector_enabled = False
                self.init_error = str(exc)
                print(f"[EmbeddingService] Seeding failed, disabling vector retrieval: {exc}")
                return False

    def retrieve_similar_patterns(self, query_text: Any, n_results: int = 3) -> list[dict[str, Any]]:
        if query_text is None:
            return []

        query_text = str(query_text).strip()
        if not query_text or not self.ensure_seeded() or self.collection is None:
            return []

        try:
            results = self.collection.query(query_texts=[query_text], n_results=max(1, n_results))
            ids = results.get("ids", [[]])
            documents = results.get("documents", [[]])
            metadatas = results.get("metadatas", [[]])
            distances = results.get("distances", [[]])

            response: list[dict[str, Any]] = []
            for idx, doc_id in enumerate(ids[0] if ids else []):
                response.append(
                    {
                        "id": doc_id,
                        "document": documents[0][idx] if documents and documents[0] else "",
                        "metadata": metadatas[0][idx] if metadatas and metadatas[0] else {},
                        "distance": distances[0][idx] if distances and distances[0] else None,
                    }
                )
            return response
        except Exception as exc:
            print(f"[EmbeddingService] Retrieval failed: {exc}")
            return []

    def hybrid_profile_match(
        self,
        query_text: Any,
        metric_scores: dict[str, Any] | None = None,
        n_results: int = 3,
    ) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        query_text_str = str(query_text or "").strip()
        metric_scores = metric_scores or {}

        inferred_archetype = self._infer_archetype_from_query(query_text_str.lower())
        raw = self.retrieve_similar_patterns(query_text=query_text_str, n_results=max(6, n_results))
        fallback = self._fallback_profile(inferred_archetype, metric_scores, query_text_str.lower())

        if not raw:
            return fallback, []

        retrieved_profiles: list[dict[str, Any]] = []
        for item in raw:
            md = item.get("metadata", {}) or {}
            label = str(md.get("label", item.get("id", "Benchmark Profile")))
            category = str(md.get("category", "pattern_family"))
            distance = item.get("distance")

            base_similarity = self._distance_to_similarity(distance, md.get("benchmark_score", 80))
            reranked_similarity = self._apply_metric_rerank(
                base_similarity=base_similarity,
                category=category,
                profile_label=label,
                metric_scores=metric_scores,
                inferred_archetype=inferred_archetype,
                query_text=query_text_str.lower(),
            )

            retrieved_profiles.append(
                {
                    "profile": label,
                    "similarity": reranked_similarity,
                    "rationale": item.get("document", ""),
                    "category": category,
                }
            )

        retrieved_profiles.sort(key=lambda x: x["similarity"], reverse=True)
        match = retrieved_profiles[0] if retrieved_profiles else fallback
        return match, retrieved_profiles[:n_results]

    def _distance_to_similarity(self, distance: Any, benchmark_score: Any) -> int:
        benchmark_score = int(benchmark_score) if str(benchmark_score).isdigit() else 80
        if isinstance(distance, (int, float)):
            rough = 100 - (float(distance) * 35.0)
            blended = (rough * 0.65) + (benchmark_score * 0.35)
            return int(round(max(45, min(98, blended))))
        return int(round(max(45, min(98, benchmark_score))))

    def _infer_archetype_from_query(self, query_text: str) -> str:
        news_terms = [
            "news",
            "breaking",
            "headlines",
            "politics",
            "world",
            "finance",
            "sports",
            "weather",
            "entertainment",
            "trending",
            "latest",
            "live",
        ]

        portal_terms = [
            "yahoo",
            "homepage",
            "portal",
            "mail",
            "finance",
            "sports",
            "entertainment",
            "search",
            "trending",
            "content aggregator",
        ]

        if any(term in query_text for term in portal_terms) and any(term in query_text for term in news_terms):
            return "portal"

        if any(term in query_text for term in news_terms):
            return "news"

        if any(term in query_text for term in ["pricing", "enterprise", "request demo", "book demo", "saas", "platform"]):
            return "saas"

        if any(term in query_text for term in ["docs", "documentation", "api", "guide"]):
            return "docs"

        if any(term in query_text for term in ["blog", "article", "editorial"]):
            return "content"

        hardware_terms = [
            "iphone",
            "ipad",
            "mac",
            "macbook",
            "watch",
            "airpods",
            "vision",
            "hardware",
            "device",
            "flagship",
            "apple",
        ]
        if any(term in query_text for term in hardware_terms):
            return "commerce"

        marketplace_terms = [
            "shop",
            "buy",
            "store",
            "cart",
            "category",
            "categories",
            "filters",
            "deals",
            "price",
            "prices",
        ]
        if any(term in query_text for term in marketplace_terms):
            return "commerce"

        return "marketing"

    def _profile_keyword_bias(self, query_text: str, profile_label: str) -> float:
        q = query_text.lower()
        label = profile_label.lower()
        bias = 0.0

        hardware_terms = [
            "iphone",
            "ipad",
            "mac",
            "macbook",
            "watch",
            "airpods",
            "vision",
            "flagship",
            "device",
            "apple",
        ]
        marketplace_terms = ["search", "category", "categories", "cart", "filters", "deals", "price", "prices"]

        looks_hardware = any(term in q for term in hardware_terms)
        looks_marketplace = any(term in q for term in marketplace_terms)

        if looks_hardware:
            if "consumer hardware pattern" in label:
                bias += 10.0
            if "enterprise product marketing page" in label:
                bias += 6.0
            if "marketplace pattern" in label:
                bias -= 10.0

        if looks_marketplace:
            if "marketplace pattern" in label:
                bias += 8.0
            if "consumer hardware pattern" in label:
                bias -= 2.0

        if "apple" in q:
            if "consumer hardware pattern" in label:
                bias += 7.0
            if "enterprise product marketing page" in label:
                bias += 4.0
            if "marketplace pattern" in label:
                bias -= 6.0

        return bias

    def _apply_metric_rerank(
        self,
        *,
        base_similarity: int,
        category: str,
        profile_label: str,
        metric_scores: dict[str, Any],
        inferred_archetype: str,
        query_text: str,
    ) -> int:
        similarity = float(base_similarity)

        ux_score = float(metric_scores.get("ux_score", 0) or 0)
        cta_visibility = float(metric_scores.get("cta_visibility", 0) or 0)
        readability = float(metric_scores.get("readability", 0) or 0)
        attention_focus = float(metric_scores.get("attention_focus", 0) or 0)
        cognitive_load = float(metric_scores.get("cognitive_load", 0) or 0)

        if category == inferred_archetype:
            similarity += 4.0
        else:
            similarity -= 1.5

        if category in {"commerce", "saas", "marketing"} and cta_visibility >= 85:
            similarity += 2.0
        if category in {"docs", "content"} and readability >= 90:
            similarity += 2.0
        if category in {"attention_focus", "hero_clarity"} and attention_focus >= 85:
            similarity += 1.5
        if category == "cognitive_load" and cognitive_load >= 85:
            similarity += 1.5
        if ux_score >= 90:
            similarity += 1.0

        similarity += self._profile_keyword_bias(query_text=query_text, profile_label=profile_label)

        label_lower = profile_label.lower()

        if "marketplace pattern" in label_lower:
            if "apple" in query_text or any(
                term in query_text for term in ["iphone", "ipad", "mac", "macbook", "watch", "airpods", "vision"]
            ):
                similarity -= 5.0

        if "consumer hardware pattern" in label_lower:
            if attention_focus >= 84 and cta_visibility >= 84:
                similarity += 2.5

        if "enterprise product marketing page" in label_lower:
            if attention_focus >= 84 and readability >= 88:
                similarity += 1.5

        visual_entropy = float(metric_scores.get("visual_entropy", 0) or 0)
        visual_clutter = float(metric_scores.get("visual_clutter", 0) or 0)
        layout_busyness = float(metric_scores.get("layout_busyness", 0) or 0)

        if "portal homepage pattern" in label_lower:
            if visual_entropy >= 55 or visual_clutter >= 55 or layout_busyness >= 55:
                similarity += 8.0
            if "yahoo" in query_text:
                similarity += 8.0
            if inferred_archetype == "portal":
                similarity += 6.0

        if "news homepage pattern" in label_lower:
            if any(term in query_text for term in ["news", "breaking", "headlines", "latest", "live"]):
                similarity += 8.0
            if visual_entropy >= 55 or layout_busyness >= 55:
                similarity += 5.0
            if inferred_archetype == "news":
                similarity += 6.0

        if "editorial content pattern" in label_lower:
            if visual_entropy >= 55 or visual_clutter >= 55 or layout_busyness >= 55:
                similarity -= 6.0
            if "yahoo" in query_text:
                similarity -= 8.0

        return int(round(max(45, min(98, similarity))))

    def _fallback_profile(
        self,
        archetype: str,
        metric_scores: dict[str, Any],
        query_text: str,
    ) -> dict[str, Any]:
        if "apple" in query_text or any(
            term in query_text for term in ["iphone", "ipad", "mac", "macbook", "watch", "airpods", "vision"]
        ):
            profile = "Consumer Hardware Pattern"
            category = "commerce"
        else:
            profile_map = {
                "saas": "Enterprise SaaS Pattern",
                "commerce": "Consumer Hardware Pattern",
                "docs": "Documentation Index Pattern",
                "content": "Editorial Content Pattern",
                "news": "News Homepage Pattern",
                "portal": "Portal Homepage Pattern",
                "marketing": "Enterprise Product Marketing Page",
            }
            profile = profile_map.get(archetype, "Enterprise Product Marketing Page")
            category = archetype

        ux_score = int(float(metric_scores.get("ux_score", 78) or 78))
        similarity = max(55, min(88, ux_score))

        return {
            "profile": profile,
            "similarity": similarity,
            "rationale": (
                "Vector retrieval was unavailable, so a benchmark profile was selected "
                "from the inferred page archetype and lexical page cues."
            ),
            "category": category,
        }


embedding_service = EmbeddingService()