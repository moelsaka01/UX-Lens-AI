from __future__ import annotations

from collections import OrderedDict
from pathlib import Path
from typing import Any

import numpy as np
from PIL import Image, ImageFilter

from app.config import settings

try:
    import cv2  # type: ignore
except Exception:  # pragma: no cover
    cv2 = None

try:
    import pytesseract  # type: ignore
except Exception:  # pragma: no cover
    pytesseract = None


class VisualAnalysisService:
    def __init__(self) -> None:
        self._analysis_cache: OrderedDict[str, dict[str, Any]] = OrderedDict()
        self._cache_limit = 24

    def to_local_path(self, static_path: str | None) -> Path | None:
        if not static_path:
            return None
        filename = Path(static_path).name
        path = settings.screenshot_dir / filename
        return path if path.exists() else None

    def analyze(self, static_path: str | None, tag: str) -> dict[str, Any]:
        path = self.to_local_path(static_path)
        if path is None:
            return self._empty()

        cache_key = f"{path.resolve()}::{tag}"
        cached = self._analysis_cache.get(cache_key)
        if cached is not None:
            self._analysis_cache.move_to_end(cache_key)
            return dict(cached)

        try:
            if cv2 is None:
                result = self._analyze_pillow(path, tag)
            else:
                result = self._analyze_cv(path, tag)
        except Exception as exc:
            print(f"[VisualAnalysisService] Analysis failed for {path.name}: {exc}")
            result = self._empty()

        self._analysis_cache[cache_key] = dict(result)
        self._analysis_cache.move_to_end(cache_key)
        while len(self._analysis_cache) > self._cache_limit:
            self._analysis_cache.popitem(last=False)

        return result

    def _empty(self) -> dict[str, Any]:
        return {
            "heatmap": None,
            "brightness": 0,
            "contrast": 0,
            "edge_density": 0,
            "whitespace_ratio": 0,
            "colorfulness": 0,
            "text_block_ratio": 0,
            "ocr_excerpt": "",
            "saliency_peak_x": 0,
            "saliency_peak_y": 0,
            "saliency_spread": 0,
            "visual_complexity": 0,
            "scan_intensity": 0,
            "hero_center_bias": 0,
            "analysis_mode": "empty",
            "ocr_available": bool(pytesseract is not None),
            "cv_available": bool(cv2 is not None),
        }

    def _compute_saliency(self, gray: np.ndarray) -> np.ndarray:
        if cv2 is not None and hasattr(cv2, "saliency"):
            try:
                saliency = cv2.saliency.StaticSaliencyFineGrained_create()
                success, sal_map = saliency.computeSaliency(gray)
                if success:
                    return (sal_map * 255).astype(np.uint8)
            except Exception:
                pass

        if cv2 is None:
            return gray

        resized = cv2.resize(gray, (64, 64))
        img_float = np.float32(resized)
        dft = cv2.dft(img_float, flags=cv2.DFT_COMPLEX_OUTPUT)
        magnitude, angle = cv2.cartToPolar(dft[:, :, 0], dft[:, :, 1])
        log_ampl = np.log(magnitude + 1e-9)
        avg = cv2.blur(log_ampl, (3, 3))
        spectral = np.exp(log_ampl - avg)
        real, imag = cv2.polarToCart(spectral, angle)
        combined = np.dstack([real, imag])
        inv = cv2.idft(combined)
        sal = cv2.magnitude(inv[:, :, 0], inv[:, :, 1])
        sal = cv2.GaussianBlur(sal ** 2, (9, 9), 0)
        sal = cv2.normalize(sal, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        return cv2.resize(sal, (gray.shape[1], gray.shape[0]))

    def _saliency_stats(self, sal: np.ndarray) -> tuple[int, int, int]:
        y, x = np.unravel_index(np.argmax(sal), sal.shape)
        mask = sal > np.percentile(sal, 80)
        spread = int(mask.mean() * 100)
        peak_x = int((x / max(1, sal.shape[1] - 1)) * 100)
        peak_y = int((y / max(1, sal.shape[0] - 1)) * 100)
        return peak_x, peak_y, spread

    def _hero_center_bias(self, peak_x: int, peak_y: int) -> int:
        center_x = 50
        center_y = 24
        distance = abs(peak_x - center_x) + abs(peak_y - center_y)
        return max(0, min(100, 100 - distance))

    def _visual_complexity(
        self,
        *,
        edge_density: int,
        text_block_ratio: int,
        colorfulness: int,
        whitespace_ratio: int,
    ) -> int:
        complexity = (
            (edge_density * 0.34)
            + (text_block_ratio * 0.24)
            + (colorfulness * 0.20)
            + ((100 - whitespace_ratio) * 0.22)
        )
        return int(max(0, min(100, round(complexity))))

    def _scan_intensity(
        self,
        *,
        saliency_spread: int,
        edge_density: int,
        text_block_ratio: int,
    ) -> int:
        score = (saliency_spread * 0.45) + (edge_density * 0.30) + (text_block_ratio * 0.25)
        return int(max(0, min(100, round(score))))

    def _extract_ocr_excerpt(self, path: Path, gray_arr: np.ndarray | None = None) -> str:
        if pytesseract is None:
            return ""

        try:
            if gray_arr is not None:
                arr = gray_arr
            else:
                with Image.open(path) as img:
                    arr = np.array(img.convert("L"))

            h, w = arr.shape[:2]
            crop_h = max(1, min(h, int(h * 0.45)))
            crop = arr[:crop_h, :]

            pil = Image.fromarray(crop)
            text = pytesseract.image_to_string(pil)
            text = " ".join(text.split())
            return text[:320]
        except Exception:
            return ""

    def _analyze_cv(self, path: Path, tag: str) -> dict[str, Any]:
        image = cv2.imread(str(path))
        if image is None:
            return self._analyze_pillow(path, tag)

        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

        brightness = int(np.mean(gray) / 255 * 100)
        contrast = int(min(100, (np.std(gray) / 128) * 100))

        edges = cv2.Canny(gray, 80, 180)
        edge_density = int((edges > 0).mean() * 100)
        whitespace_ratio = int((gray > 235).mean() * 100)

        rg = np.abs(rgb[:, :, 0].astype(float) - rgb[:, :, 1].astype(float))
        yb = np.abs(
            0.5 * (rgb[:, :, 0].astype(float) + rgb[:, :, 1].astype(float)) - rgb[:, :, 2].astype(float)
        )
        colorfulness = int(min(100, np.sqrt(rg.std() ** 2 + yb.std() ** 2) * 1.3))

        _, text_mask = cv2.threshold(gray, 180, 255, cv2.THRESH_BINARY_INV)
        kernel = np.ones((3, 15), np.uint8)
        text_mask = cv2.morphologyEx(text_mask, cv2.MORPH_CLOSE, kernel, iterations=1)
        text_block_ratio = int((text_mask > 0).mean() * 100)

        sal = self._compute_saliency(gray)
        peak_x, peak_y, spread = self._saliency_stats(sal)

        visual_complexity = self._visual_complexity(
            edge_density=edge_density,
            text_block_ratio=text_block_ratio,
            colorfulness=colorfulness,
            whitespace_ratio=whitespace_ratio,
        )
        scan_intensity = self._scan_intensity(
            saliency_spread=spread,
            edge_density=edge_density,
            text_block_ratio=text_block_ratio,
        )
        hero_center_bias = self._hero_center_bias(peak_x, peak_y)

        heatmap_url = None
        try:
            heat = cv2.applyColorMap(sal, cv2.COLORMAP_JET)
            overlay = cv2.addWeighted(image, 0.50, heat, 0.50, 0)
            heatmap_path = settings.screenshot_dir / f"{path.stem}_{tag}_heatmap.png"
            ok = cv2.imwrite(str(heatmap_path), overlay)
            if ok:
                heatmap_url = f"/static/generated/{heatmap_path.name}"
        except Exception as exc:
            print(f"[VisualAnalysisService] CV heatmap generation failed for {path.name}: {exc}")

        return {
            "heatmap": heatmap_url,
            "brightness": brightness,
            "contrast": contrast,
            "edge_density": edge_density,
            "whitespace_ratio": whitespace_ratio,
            "colorfulness": colorfulness,
            "text_block_ratio": text_block_ratio,
            "ocr_excerpt": self._extract_ocr_excerpt(path, gray),
            "saliency_peak_x": peak_x,
            "saliency_peak_y": peak_y,
            "saliency_spread": spread,
            "visual_complexity": visual_complexity,
            "scan_intensity": scan_intensity,
            "hero_center_bias": hero_center_bias,
            "analysis_mode": "opencv",
            "ocr_available": bool(pytesseract is not None),
            "cv_available": True,
        }

    def _analyze_pillow(self, path: Path, tag: str) -> dict[str, Any]:
        with Image.open(path) as opened:
            image = opened.convert("RGB")

        gray = image.convert("L")
        arr = np.array(gray)

        brightness = int(arr.mean() / 255 * 100)
        contrast = int(min(100, (arr.std() / 128) * 100))

        edge_img = gray.filter(ImageFilter.FIND_EDGES)
        edge_arr = np.array(edge_img)
        edge_density = int((edge_arr > 32).mean() * 100)
        whitespace_ratio = int((arr > 235).mean() * 100)

        rgb = np.array(image)
        rg = np.abs(rgb[:, :, 0].astype(float) - rgb[:, :, 1].astype(float))
        yb = np.abs(
            0.5 * (rgb[:, :, 0].astype(float) + rgb[:, :, 1].astype(float)) - rgb[:, :, 2].astype(float)
        )
        colorfulness = int(min(100, np.sqrt(rg.std() ** 2 + yb.std() ** 2) * 1.3))

        dark_mask = (255 - arr > 75).astype(np.uint8)
        text_block_ratio = int(dark_mask.mean() * 100)

        focus = edge_img.filter(ImageFilter.GaussianBlur(radius=8))
        sal = np.array(focus)
        y, x = np.unravel_index(np.argmax(sal), sal.shape)
        peak_x = int((x / max(1, sal.shape[1] - 1)) * 100)
        peak_y = int((y / max(1, sal.shape[0] - 1)) * 100)
        spread = int((sal > np.percentile(sal, 80)).mean() * 100)

        visual_complexity = self._visual_complexity(
            edge_density=edge_density,
            text_block_ratio=text_block_ratio,
            colorfulness=colorfulness,
            whitespace_ratio=whitespace_ratio,
        )
        scan_intensity = self._scan_intensity(
            saliency_spread=spread,
            edge_density=edge_density,
            text_block_ratio=text_block_ratio,
        )
        hero_center_bias = self._hero_center_bias(peak_x, peak_y)

        heatmap_url = None
        try:
            heatmap_path = settings.screenshot_dir / f"{path.stem}_{tag}_heatmap.png"
            overlay = image.copy().convert("RGBA")
            heat = Image.fromarray(sal).convert("L").resize(image.size)
            glow = Image.new("RGBA", image.size, (255, 0, 0, 0))
            glow.putalpha(heat)
            glow = glow.filter(ImageFilter.GaussianBlur(radius=18))
            composed = Image.alpha_composite(overlay, glow)
            composed.convert("RGB").save(heatmap_path)
            heatmap_url = f"/static/generated/{heatmap_path.name}"
        except Exception as exc:
            print(f"[VisualAnalysisService] Pillow heatmap generation failed for {path.name}: {exc}")

        return {
            "heatmap": heatmap_url,
            "brightness": brightness,
            "contrast": contrast,
            "edge_density": edge_density,
            "whitespace_ratio": whitespace_ratio,
            "colorfulness": colorfulness,
            "text_block_ratio": text_block_ratio,
            "ocr_excerpt": self._extract_ocr_excerpt(path, arr),
            "saliency_peak_x": peak_x,
            "saliency_peak_y": peak_y,
            "saliency_spread": spread,
            "visual_complexity": visual_complexity,
            "scan_intensity": scan_intensity,
            "hero_center_bias": hero_center_bias,
            "analysis_mode": "pillow",
            "ocr_available": bool(pytesseract is not None),
            "cv_available": False,
        }


visual_analysis_service = VisualAnalysisService()